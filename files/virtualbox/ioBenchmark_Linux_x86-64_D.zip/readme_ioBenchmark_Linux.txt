The I/O disk performance utility is used to test the performance of disk.  This utility measures the i/o (MB/sec) from the operating system perspective. A good number would be above 300MB/sec for writes and 350MB/sec for reads.  Typically most elapsed time performance problems we see are because the IO subsystem was not setup properly for optimal read and write performance.  This will measure a single read and write sequentially and not in parallel.  If these numbers look good we should then try to run parallel instances of this utility.  Doing multiple reads and writes in parallel.  This will measure how the effect of running parallel I/Os on the same disk subsystem.  In an ideal case, the I/O performance for a single read or write would be about the same for running multiple reads and writes in parallel. 

>tar -xvf ioBenchmark_Linux_x86-64_D.tar 
>ioBenchmark.sh    
usage: ./ioBenchmark.sh <path> [<size in GB>]
***The first argument to the script is the path to the file system that is either being read from or written to. 
The second argument is the size in GB of the file that will be created. This test will at one point generate up to 4 of these sized files at once. The customer should ensure that he has 4 x that amount of space available for testing. In the case above you need to make sure the customer has 20 gig of space free for the test. 
All of the files will be deleted when the script exits. 

