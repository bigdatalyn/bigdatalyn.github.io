
FILE_PATH="."
FILE_SIZE=5
LOGFILE="ioBenchmark.log"

run_tests()
{
    WRITER="$1"
    READER="$2"
    BD=$3
    chmod a+x "$WRITER"
    chmod a+x "$READER"

    ###########################################################################
    # 1 writer
    echo "Testing write speed using $FILE_PATH ..."
    ./${WRITER} "${FILE_PATH}/ioBenchmark1.dat" $FILE_SIZE 4096 write${BD}
    echo

    ###########################################################################
    # 1 reader
    echo "Testing read speed using $FILE_PATH ..."
    ./${READER} "${FILE_PATH}/ioBenchmark1.dat" $FILE_SIZE 4096 read${BD}
    echo

    ###########################################################################
    # 1 writer, 1 reader - parallel
    echo "Testing concurrent read/write speed using $FILE_PATH ..."
    ./${WRITER} "${FILE_PATH}/ioBenchmark2.dat" $FILE_SIZE 4096 write${BD} &
    ./${READER} "${FILE_PATH}/ioBenchmark1.dat" $FILE_SIZE 4096 read${BD} &
    wait
    echo

    ###########################################################################
    # 2 writer - parallel
    echo "Testing concurrent write speed using $FILE_PATH ..."
    ./${WRITER} "${FILE_PATH}/ioBenchmark3.dat" $FILE_SIZE 4096 write${BD}1 &
    ./${WRITER} "${FILE_PATH}/ioBenchmark4.dat" $FILE_SIZE 4096 write${BD}2 &
    wait
    echo

    ###########################################################################
    # 2 reader - parallel
    echo "Testing concurrent read speed using $FILE_PATH ..."
    ./${READER} "${FILE_PATH}/ioBenchmark1.dat" $FILE_SIZE 4096 read${BD}1 &
    ./${READER} "${FILE_PATH}/ioBenchmark2.dat" $FILE_SIZE 4096 read${BD}2 &
    wait
    echo

    ###########################################################################
    # 2 writer, 2 reader - parallel
    echo "Testing concurrent read/write speed using $FILE_PATH ..."
    ./${WRITER} "${FILE_PATH}/ioBenchmark1.dat" $FILE_SIZE 4096 write${BD}1 &
    ./${WRITER} "${FILE_PATH}/ioBenchmark2.dat" $FILE_SIZE 4096 write${BD}2 &
    ./${READER} "${FILE_PATH}/ioBenchmark3.dat" $FILE_SIZE 4096 read${BD}1 &
    ./${READER} "${FILE_PATH}/ioBenchmark4.dat" $FILE_SIZE 4096 read${BD}2 &
    wait
    echo

    rm -f "${FILE_PATH}/ioBenchmark1.dat" 2> /dev/null
    rm -f "${FILE_PATH}/ioBenchmark2.dat" 2> /dev/null
    rm -f "${FILE_PATH}/ioBenchmark3.dat" 2> /dev/null
    rm -f "${FILE_PATH}/ioBenchmark4.dat" 2> /dev/null
}

# Process arguments
if [ "$1" = "" ]
then
    echo "usage: $0 <path> [<size in GB>]"
    echo
    exit
else
    FILE_PATH="$1"
fi

if [ "$2" != "" ]
then
    FILE_SIZE=$2
fi

# Run tests, appending all output to $LOGFILE
{
found_tests=0

if [ `ls ioWriterD* 2>/dev/null | wc -l` -eq 1 ]
then
    found_tests=1
    WRITER=`ls ioWriterD* 2>/dev/null`
    READER=`ls ioReaderD* 2>/dev/null`
    run_tests "$WRITER" "$READER" "D"
fi

if [ `ls ioWriterB* 2>/dev/null | wc -l` -eq 1 ]
then
    found_tests=1
    WRITER=`ls ioWriterB* 2>/dev/null`
    READER=`ls ioReaderB* 2>/dev/null`
    run_tests "$WRITER" "$READER" "B"
fi

if [ $found_tests -eq 0 -a `ls ioWriter* 2>/dev/null | wc -l` -eq 1 ]
then
    WRITER=`ls ioWriter* 2>/dev/null`
    READER=`ls ioReader* 2>/dev/null`
    run_tests "$WRITER" "$READER"
fi

} | tee -a "$LOGFILE"
