# =====================================
# description: Oracle Cloud MS Cluster
# author: ionut.neubauer@oracle.com
# date: 13-Feb-2018
# version: 1.1
# =====================================

from simplecrypt import decrypt
from simplecrypt import DecryptionException
from binascii import unhexlify
from time import sleep
import json
import requests
import sys
import os
import subprocess
from datetime import datetime


def error_log(message):
    error_log = open(os.path.dirname(sys.argv[0]) + '\error.log', 'a+b')
    error_log.write(str(datetime.now().strftime('%Y-%B-%d %H:%M:%S')) + ' ---> ' + message + '\n')
    error_log.close()


def no_variable():
    status_list = []
    list = ['username', 'password', 'endpoint', 'idd', 'node1_name', 'node2_name', 'route1_name', 'route2_name', 'ipAddressPrefix1', 'ipAddressPrefix2', 'nextHopVnicSet1', 'nextHopVnicSet2']
    for i in list:
        if not str(settings[i]):
            print '!!! EMPTY ' + i + ' !!!'
            error_log('!!! EMPTY ' + i + ' !!!')
            status_list.append('nok')
        else:
            status_list.append('ok')
    if 'nok' in status_list:
        sleep(2)
        sys.exit()
    else:
        pass

try:
    file = open(os.path.dirname(sys.argv[0]) + '\settings.json', 'rb')
    settings = json.load(file)
    file.close()
except IOError:
    print '\n!!! No settings.json file !!!'
    error_log('No settings.json file')
    sleep(2)
    sys.exit()

try:
    key = open('C:\\Users\\Default\\AppData\\Local\\Microsoft\\Windows\\14858021EE65', 'rb')
except IOError:
    print '\n!!! No KEY for decryption !!!'
    error_log('No KEY for decryption')
    sleep(2)
    sys.exit()

no_variable()

username = str(settings['username'])
try:
    password = str(decrypt(key, unhexlify(settings['password'])))
except DecryptionException as e:
    print 'Private KEY has changed'
    error_log('Private KEY has changed')
    sleep(2)
    sys.exit()
endpoint = str(settings['endpoint'])
idd = str(settings['idd'])
cluster_name = "Cluster Group"
cluster_name_len = int(len(cluster_name.split(" ")))
if not settings['cluster_name_sql']:
    cluster_name_sql = ""
else:
    cluster_name_sql = str(settings['cluster_name_sql'].split()[0])
cluster_name_sql_len = int(len(settings['cluster_name_sql'].split(" ")))
node1_name = str(settings['node1_name'])
node2_name = str(settings['node2_name'])
route1_name = str(settings['route1_name'])
route2_name = str(settings['route2_name'])
ipAddressPrefix1 = str(settings['ipAddressPrefix1'])
ipAddressPrefix2 = str(settings['ipAddressPrefix2'])
nextHopVnicSet1 = str(settings['nextHopVnicSet1'])
nextHopVnicSet2 = str(settings['nextHopVnicSet2'])

history_nodes = []
history_nodes_sql = []

payload = {"user": 'Compute-' + idd + '/' + username, "password": password}
headers = {"Content-Type": "application/oracle-compute-v3+json"}

s = requests.Session()

try:
    message = s.post('https://' + endpoint + '/authenticate/', headers=headers, data=json.dumps(payload))
    if message.status_code != 204:
        print 'Incorrect username or password or privileges'
        error_log('Incorrect username or password or privileges')
        sleep(2)
        sys.exit()
except requests.exceptions.ConnectionError as e:
    print e
    error_log(str(e))
    sleep(2)
    sys.exit()

def authenticate(new_encrypted_password):
    password = decrypt(open('C:\\Users\\Default\\AppData\\Local\\Microsoft\\Windows\\14858021EE65', 'rb'), unhexlify(new_encrypted_password))
    payload = {"user": 'Compute-' + idd + '/' + username, "password": password}
    message = s.post('https://' + endpoint + '/authenticate/', headers=headers, data=json.dumps(payload))
    if message.status_code == 401:
        print 'Incorrect username or password'
        error_log('Incorrect username or password')
        sleep(2)
        return 'nok'
    return 'ok'

def change_route(object, ipAddressPrefix, nextHopVnicSet):
    attr = {"name": object, "ipAddressPrefix": ipAddressPrefix, "nextHopVnicSet": get_object_vnicsets(nextHopVnicSet)}
    x = s.put('https://' + endpoint + '/network/v1/route' + object, headers=headers, data=json.dumps(attr))
    print json.dumps(x.json(), indent=4, sort_keys=True)
    error_log(json.dumps(x.json()))


def get_object_routes(route_name):
    x = s.get('https://' + endpoint + '/network/v1/route/' + 'Compute-' + idd + '/', headers=headers)
    result = json.loads(json.dumps(x.json(), indent=4, sort_keys=True))
    for i in result['result']:
        if str(route_name) in str(i['name']):
            return i['name']


def get_object_vnicsets(vnicset):
    x = s.get('https://' + endpoint + '/network/v1/vnicset/' + 'Compute-' + idd + '/', headers=headers)
    result = json.loads(json.dumps(x.json(), indent=4, sort_keys=True))
    for i in result['result']:
        if str(vnicset) in str(i['name']):
            return i['name']


def first_contact_cluster_sql():
    if not cluster_name_sql:
        pass
    else:
        global history_nodes_sql
        x = subprocess.Popen(['C:\Windows\\sysnative\WindowsPowerShell\\v1.0\\powershell.exe','Get-ClusterGroup'], shell=True, stdout=subprocess.PIPE)
        text = x.communicate()[0].decode('utf-8')
        for y in text.splitlines():
            if y.startswith(cluster_name_sql):
                z = str(y.split()[cluster_name_sql_len])
                if z == node1_name or z == node2_name:
                    print 'New MASTER SQL NODE detected --> ' + z
                    error_log('New MASTER SQL NODE detected --> ' + z)
                    if z == node1_name:
                        change_route(get_object_routes(route2_name), ipAddressPrefix2, get_object_vnicsets(nextHopVnicSet1))
                    elif z == node2_name:
                        change_route(get_object_routes(route2_name), ipAddressPrefix2, get_object_vnicsets(nextHopVnicSet2))
                    history_nodes_sql.append(z)
                else:
                    print 'Invalid SQL NODE'
                    error_log('Invalid SQL NODE')
                    sleep(2)
                    sys.exit()


def cluster_sql():
    if not cluster_name_sql:
        pass
    else:
        global history_nodes_sql
        x = subprocess.Popen(['C:\Windows\\sysnative\WindowsPowerShell\\v1.0\\powershell.exe','Get-ClusterGroup'], shell=True, stdout=subprocess.PIPE)
        text = x.communicate()[0].decode('utf-8')
        for y in text.splitlines():
            if y.startswith(cluster_name_sql):
                z = str(y.split()[cluster_name_sql_len])
                if z == history_nodes_sql[-1]:
                    print 'Nothing to change on OPC, ' + z + ' is the MASTER SQL NODE'
                else:
                    if z == node1_name or z == node2_name:
                        print 'New MASTER SQL NODE detected --> ' + z
                        error_log('New MASTER SQL NODE detected --> ' + z)
                        if z == node1_name:
                            change_route(get_object_routes(route2_name), ipAddressPrefix2, get_object_vnicsets(nextHopVnicSet1))
                        elif z == node2_name:
                            change_route(get_object_routes(route2_name), ipAddressPrefix2, get_object_vnicsets(nextHopVnicSet2))
                        history_nodes_sql.append(z)
                    else:
                        print 'Invalid SQL NODE'
                        error_log('Invalid SQL NODE')
                        sleep(2)
                        sys.exit()
                if len(history_nodes_sql) > 3:
                    history_nodes_sql = history_nodes_sql[-3:]



def first_contact():
    x = subprocess.Popen(['C:\Windows\\sysnative\WindowsPowerShell\\v1.0\\powershell.exe','Get-ClusterGroup'], shell=True, stdout=subprocess.PIPE)
    text = x.communicate()[0].decode('utf-8')
    for y in text.splitlines():
        if y.startswith(cluster_name):
            z = str(y.split()[cluster_name_len])
            if z == node1_name or z == node2_name:
                print 'New MASTER NODE detected --> ' + z
                error_log('New MASTER NODE detected --> ' + z)
                if z == node1_name:
                    change_route(get_object_routes(route1_name), ipAddressPrefix1, get_object_vnicsets(nextHopVnicSet1))
                    first_contact_cluster_sql()
                elif z == node2_name:
                    change_route(get_object_routes(route1_name), ipAddressPrefix1, get_object_vnicsets(nextHopVnicSet2))
                    first_contact_cluster_sql()
                history_nodes.append(z)
            else:
                print 'Invalid NODE'
                error_log('Invalid NODE')
                sleep(2)
                sys.exit()

first_contact()

while True:
    cluster_sql()
    x = subprocess.Popen(['C:\Windows\\sysnative\WindowsPowerShell\\v1.0\\powershell.exe','Get-ClusterGroup'], shell=True, stdout=subprocess.PIPE)
    text = x.communicate()[0].decode('utf-8')
    for y in text.splitlines():
        if y.startswith(cluster_name):
            z = str(y.split()[cluster_name_len])
            if z == history_nodes[-1]:
                print 'Nothing to change on OPC, ' + z + ' is the MASTER NODE'
            else:
                if z == node1_name or z == node2_name:
                    print 'New MASTER NODE detected --> ' + z
                    error_log('New MASTER NODE detected --> ' + z)
                else:
                    print 'Invalid NODE'
                    error_log('Invalid NODE')
                    continue
                if z == node1_name:
                    file = open(os.path.dirname(sys.argv[0]) + '\settings.json', 'rb')
                    settings = json.load(file)
                    file.close()
                    password = settings['password']
                    if authenticate(password) == 'ok':
                        change_route(get_object_routes(route1_name), ipAddressPrefix1, get_object_vnicsets(nextHopVnicSet1))
                    else:
                        continue
                elif z == node2_name:
                    file = open(os.path.dirname(sys.argv[0]) + '\settings.json', 'rb')
                    settings = json.load(file)
                    file.close()
                    password = settings['password']
                    if authenticate(password) == 'ok':
                        change_route(get_object_routes(route1_name), ipAddressPrefix1, get_object_vnicsets(nextHopVnicSet2))
                    else:
                        continue
                if len(history_nodes) > 3:
                    history_nodes = history_nodes[-3:]
                history_nodes.append(z)

    sleep(1)
