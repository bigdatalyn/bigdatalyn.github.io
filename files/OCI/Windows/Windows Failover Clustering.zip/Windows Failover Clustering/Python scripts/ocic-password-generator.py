﻿# =====================================
# description: Oracle Cloud MS Cluster
# author: ionut.neubauer@oracle.com
# date: 12-Jun-2017
# version: 1.0
# =====================================

from simplecrypt import encrypt
from getpass import getpass
import sys
from time import sleep
import json
from binascii import hexlify


get_password = getpass('Write the new password and press ENTER: ')
if not get_password:
    print '!!! EMPTY PASSWORD !!!'
    sleep(2)
    sys.exit()

try:
    key = open('C:\\Users\\Default\\AppData\\Local\\Microsoft\\Windows\\14858021EE65', 'rb')
except IOError:
    print '\n!!!No KEY for encryption!!!'
    sleep(2)
    sys.exit()

try:
    open('settings.json','rb')
except IOError:
    print '\n!!!No settings.json file!!!'
    sleep(2)
    sys.exit()


def status():
    for i in range(101):
        sys.stdout.write("Encryption progress: %d%%   \r" % i)
        sleep(0.01)
        sys.stdout.flush()
    print '\nDone...'


def encrypt_password():
    password = encrypt(key, get_password)
    password = hexlify(password)

    file = open('settings.json', 'rb')
    settings = json.load(file)

    settings['password'] = password

    file = open('settings.json', 'wb')

    json.dump(settings, file, indent=4)

    file.close()


encrypt_password()
status()

key.close()

sleep(2)
