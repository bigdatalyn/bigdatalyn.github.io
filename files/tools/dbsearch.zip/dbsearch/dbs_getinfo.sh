#!/bin/ksh
#
#DB-SEARCH v1 - File DBS should contain a list of system/password@SID
#
for i in `cat ./DBS`
do
if test -z ${i}
then
	echo "File ./DBS is incorrect"
else
	sid=`echo $i|cut -f2 -d'@'`
	echo Getting info on database $sid
	sqlplus ${i} @sql/dbs_search >/dev/null <<!

!
fi
mv *.out out 
done
ls -ltr out/*.out
