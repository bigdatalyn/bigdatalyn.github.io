#!/bin/ksh
#
# This script analyze all DBS_SEARCH log output to facilitate a DB inventory
# Output file is ./dbs.csv
#(c)05/2020-Oracle Corporation-Benoit@OSC
#
lg='./csv/dbs.csv'
cat ./sql/LINE >$lg
for fl in `ls ./out/*.out`
do
	echo -e "Processing $fl \n"
	((i=1))
	res=(a b c d e f g h i j k l m n o p q r s t u v w x y z)
	for nm in `cat ./sql/HEADER`
	do
		if (($i==7))
		then
			#Find Line number for size
			lns=`cat $fl|grep -n "SIZE_GB"|cut -f1 -d:`
			if test -z "$lns"
			then
				((lng=1))
				res[$i]="N/A"
			else
				((lng=2+$lns))
				res[$i]="`cat $fl|head -${lng}|tail -1|awk '{print $2}'`"
			fi
		else
			res[$i]="`cat $fl|grep $nm|grep -v '!'|awk {'print $2'}`"
		fi
	((j=$i))
	((i++))
	done
	echo -e "${res[1]},${res[2]},${res[3]},${res[4]},${res[5]},${res[6]},${res[7]}">>$lg
done
nc=`cat $lg|grep -v HOSTS|wc -l`
echo Processing Done
echo Log file $lg contains $nc environments details
date
