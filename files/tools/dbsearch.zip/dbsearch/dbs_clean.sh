rm -f out/*
rm -f csv/*
