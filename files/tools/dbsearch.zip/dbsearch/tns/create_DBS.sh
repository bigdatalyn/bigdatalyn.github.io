#!/bin/ksh
cat tnsnames.*|grep "="|grep -v "("|sed "s/ =//g">./DBSID
rm -f ./DBS 1>/dev/null 2>&1
dbpwd=`cat ./DBPWD`
for i in `cat ./DBSID`
do
	echo ${dbpwd}"@"${i}>>./DBS
done
cp DBS ..
