define SQL_TOP_N = 100
define CAPTURE_HOST_NAMES = 'YES'

-- DB_SEARCH TOOL START (c)Oracle 2020-OSC
-- Last n days of data to capture. Default is 1 and is fine
define NUM_DAYS = 1

-- DO  NOT CHANGE ANYTHING BELOW THIS LINE

define DATE_BEGIN = '2000-01-01'
define DATE_END   = '2040-01-01'

set define '&'
set concat '~'
set colsep " "
SET UNDERLINE '-'
set pagesize 50000
SET ARRAYSIZE 5000
REPHEADER OFF
REPFOOTER OFF


define AWR_SEARCH_VER = 1.0.7


set termout off
alter session set optimizer_dynamic_sampling=4;
alter session set workarea_size_policy = manual;
alter session set sort_area_size = 268435456;
alter session set NLS_LENGTH_SEMANTICS=BYTE;
alter session set cursor_sharing = exact;
alter session set NLS_DATE_FORMAT = 'yyyy-mm-dd HH24:mi:ss';
alter session set NLS_TIMESTAMP_FORMAT = 'yyyy-mm-dd HH24:mi:ss';
set termout on

set timing off

set serveroutput on
set verify off

prompt 
prompt AWR-Search from Benoit@OSC -  Version &AWR_SEARCH_VER
prompt The purpose of this script is to gather a compact database inventory
prompt
define DIAG_PACK_LICENSE = 'YES'



whenever sqlerror exit
set serveroutput on
begin
    if upper('&DIAG_PACK_LICENSE') = 'YES' then
		null;
	else
        dbms_output.put_line('This script will now exit.');
        execute immediate 'bogus statement to force exit';
    end if;
end;
/

whenever sqlerror continue


column cnt_dbid_1 new_value CNT_DBID noprint
SELECT count(DISTINCT dbid) cnt_dbid_1
FROM dba_hist_database_instance;
 --where rownum = 1;


define DBID = ' ' 
column :DBID_1 new_value DBID noprint
variable DBID_1 varchar2(30)

define DB_VERSION = 0
column :DB_VERSION_1 new_value DB_VERSION noprint
variable DB_VERSION_1 number



set feedback off
declare
	version_gte_11_2	varchar2(30);
	l_sql				varchar2(32767);
	l_variables	        varchar2(1000) := ' ';
	l_block_size		number;
begin
	:DB_VERSION_1 :=  dbms_db_version.version + (dbms_db_version.release / 10);
	dbms_output.put_line('Database IDs in this Repository:');
	
	
	
	for c1 in (select distinct dbid,db_name FROM dba_hist_database_instance order by db_name)
	loop
		dbms_output.put_line(rpad(c1.dbid,35)||c1.db_name);
	end loop; --c1
		
	if to_number(&CNT_DBID) > 1 then
		:DBID_1 := ' ';
	else
		
		SELECT DISTINCT dbid into :DBID_1
					 FROM dba_hist_database_instance
					where rownum = 1;
		

	end if;
	
	--l_variables := l_variables||'ver_gte_11_2:TRUE';
	
	if :DB_VERSION_1  >= 11.2 then
		l_variables := l_variables||'ver_gte_11_2:TRUE';
	else
		l_variables := l_variables||'ver_gte_11_2:FALSE';
	end if;
	
	if :DB_VERSION_1  >= 11.1 then
		l_variables := l_variables||',ver_gte_11_1:TRUE';
	else
		l_variables := l_variables||',ver_gte_11_1:FALSE';
	end if;
	
	--alter session set plsql_ccflags = 'debug_flag:true';
	l_sql := q'[alter session set plsql_ccflags =']'||l_variables||q'[']';
	
	
	
	execute immediate l_sql;
end;
/

select :DBID_1 from dual;
select :DB_VERSION_1 from dual;



accept DBID2 CHAR prompt 'Which dbid would you like to use? [&DBID] '

column DBID_2 new_value DBID noprint
select case when length('&DBID2') > 3 then '&DBID2' else '&DBID' end DBID_2 from dual;


whenever sqlerror exit
set serveroutput on
begin
    if length('&DBID') > 4 then
		null;
	else
        dbms_output.put_line('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
        dbms_output.put_line('You must choose a database ID.');
        dbms_output.put_line('This script will now exit.');
		dbms_output.put_line('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
        execute immediate 'bogus statement to force exit';
    end if;
end;
/

whenever sqlerror continue




declare
  l_stat_rows number := 1;
  l_last_analyzed_days number:= 0;
  l_last_analyzed_threshold constant number:= 60;
  l_actual_rows number;
  l_pct_change number := 0;
begin
  select nvl(NUM_ROWS,1) nrows,round(sysdate - S.LAST_ANALYZED) last_analyzed_days 
		 into l_stat_rows,l_last_analyzed_days from sys.DBA_TAB_STATISTICS s where owner = 'SYS' and table_name = 'WRM$_SNAPSHOT';
  
  select count(*) num_rows into l_actual_rows from sys.dba_hist_snapshot;
    
  if l_stat_rows is null or l_stat_rows < 1 then
    l_stat_rows := 1;
  end if;
  --dbms_output.put_line('Stats: '||l_stat_rows);
  --dbms_output.put_line('Actual: '||l_actual_rows);
  
  l_pct_change := abs(round((l_actual_rows-l_stat_rows)/l_stat_rows,3))*100;
  --dbms_output.put_line('% Change: '||l_pct_change);
  
  if l_pct_change >= 30 or l_last_analyzed_days > l_last_analyzed_threshold then
    dbms_output.put_line(' ');
	dbms_output.put_line('*******************************************************************************');
	dbms_output.put_line('****************************** WARNING !!! ************************************');
    dbms_output.put_line('It appears that statistics on the SYS schema may be invalid.');
	if l_last_analyzed_days > l_last_analyzed_threshold then
		dbms_output.put_line(q'!Statistics haven't been collect for !'||l_last_analyzed_days||q'! days!');
	end if;
    dbms_output.put_line('This can have serious, negative performance implications for this script ');
    dbms_output.put_line('as well as AWR, ASH, and ADDM. Please review My Oracle Support Doc ID 457926.1');
    dbms_output.put_line('for details on gathering stats on SYS objects.');
    dbms_output.put_line('****************************** WARNING !!! ************************************');
	dbms_output.put_line('*******************************************************************************');
    
  end if;
  
end;
/


prompt




REM set heading off

select '&DBID' a from dual;

column db_name1 new_value DBNAME
prompt Will export AWR data for the following Database:

SELECT dbid,db_name db_name1
FROM dba_hist_database_instance
where dbid = '&DBID'
and rownum = 1;


define T_WAITED_MICRO_COL = 'TIME_WAITED_MICRO' 
column :T_WAITED_MICRO_COL_1 new_value T_WAITED_MICRO_COL noprint
variable T_WAITED_MICRO_COL_1 varchar2(30)

begin
	if :DB_VERSION_1  >= 11.1 then
		:T_WAITED_MICRO_COL_1 := 'TIME_WAITED_MICRO_FG';
	else
		:T_WAITED_MICRO_COL_1 := 'TIME_WAITED_MICRO';
	end if;

end;
/

select :T_WAITED_MICRO_COL_1 from dual;

define DB_BLOCK_SIZE = 0
column :DB_BLOCK_SIZE_1 new_value DB_BLOCK_SIZE noprint
variable DB_BLOCK_SIZE_1 number



set feedback off
begin

	:DB_BLOCK_SIZE_1 := 0;

	for c1 in (
		with inst as (
		select min(instance_number) inst_num
		  from dba_hist_snapshot
		  where dbid = &DBID
			)
		SELECT VALUE the_block_size
			FROM DBA_HIST_PARAMETER
			WHERE dbid = &DBID
			and PARAMETER_NAME = 'db_block_size'
			AND snap_id = (SELECT MAX(snap_id) FROM dba_hist_osstat WHERE dbid = &DBID AND instance_number = (select inst_num from inst))
		   AND instance_number = (select inst_num from inst))
	loop
		:DB_BLOCK_SIZE_1 := c1.the_block_size;
	end loop; --c1
	
	if :DB_BLOCK_SIZE_1 = 0 then
		:DB_BLOCK_SIZE_1 := 8192;
	end if;


end;
/

select :DB_BLOCK_SIZE_1 from dual;

--column snap_min1 new_value SNAP_ID_MIN noprint
column snap_min1 new_value SNAP_ID_MIN

--SELECT min(snap_id) - 1 snap_min1
--  FROM dba_hist_snapshot
--  WHERE dbid = &DBID 
--    and begin_interval_time > (
--		SELECT max(begin_interval_time) - &NUM_DAYS
--		  FROM dba_hist_snapshot 
--		  where dbid = &DBID);

SELECT min(snap_id) - 1 snap_min1
  FROM dba_hist_snapshot
  WHERE dbid = &DBID 
    and (
			(
			'&DATE_BEGIN' = '2000-01-01'
			and
			begin_interval_time > (
			SELECT max(begin_interval_time) - &NUM_DAYS
			  FROM dba_hist_snapshot 
			  where dbid = &DBID)
			 )
		or
			('&DATE_BEGIN' != '2000-01-01'
			 and
			 begin_interval_time >= trunc(to_date('&DATE_BEGIN','YYYY-MM-DD'))
			)
		)
	 ;
		  
		  
select 'foo' from dual where '&DATE_BEGIN' = '2000-01-01';
		  
column snap_max1 new_value SNAP_ID_MAX noprint
SELECT max(snap_id) snap_max1
  FROM dba_hist_snapshot
  WHERE dbid = &DBID
  and begin_interval_time < trunc(to_date('&DATE_END','YYYY-MM-DD'))+1 
  and ('&DATE_BEGIN' = '2000-01-01'
	   or
		   (
		   '&DATE_BEGIN' != '2000-01-01'
			 and
			 begin_interval_time >= trunc(to_date('&DATE_BEGIN','YYYY-MM-DD'))
		   )
	   );

prompt
rem prompt &SNAP_ID_MIN
rem prompt &SNAP_ID_MAX
rem prompt &NUM_DAYS

whenever sqlerror exit
set serveroutput on
begin
    if length('&DBID') > 4 then
		null;
	else
        dbms_output.put_line('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
        dbms_output.put_line('You must choose a database ID.');
        dbms_output.put_line('This script will now exit.');
		dbms_output.put_line('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
        execute immediate 'bogus statement to force exit';
    end if;
end;
/

whenever sqlerror continue


whenever sqlerror exit
set serveroutput on
declare
	l_snapshot_count number := 0;
begin
	for c1 in (SELECT count(*) cnt
				 FROM dba_hist_snapshot
				WHERE dbid = &DBID)
	loop
		l_snapshot_count := c1.cnt;
	end loop; --c1



    if l_snapshot_count > 2 then
		null;
	else
        dbms_output.put_line('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
        dbms_output.put_line('There is no AWR data for this DBID');
        dbms_output.put_line('This script will now exit.');
		dbms_output.put_line('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
        execute immediate 'bogus statement to force exit';
    end if;
end;
/

whenever sqlerror continue


whenever sqlerror exit
set serveroutput on

begin
	--if length(&SNAP_ID_MIN) > 0 and  length(&SNAP_ID_MAX) > 0  then
	--dbms_output.put_line('foo'|| REGEXP_REPLACE('&SNAP_ID_MIN','[[:space:]]','')||'bar');
	--if ('&SNAP_ID_MIN') != ''  then
	if length(REGEXP_REPLACE('&SNAP_ID_MIN','[[:space:]]','')) > 0 and
	   length(REGEXP_REPLACE('&SNAP_ID_MAX','[[:space:]]','')) > 0 then
		null;
	else
        dbms_output.put_line('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
        dbms_output.put_line('The chosen date range doesn''t contain any data.');
        dbms_output.put_line('This script will now exit.');
		dbms_output.put_line('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
        execute immediate 'bogus statement to force exit';
    end if;
end;
/


whenever sqlerror continue


 
column FILE_NAME new_value SPOOL_FILE_NAME noprint
select 'awr-hist-'||'&DBID'||'-'||'&DBNAME'||'-'||ltrim('&SNAP_ID_MIN')||'-'||ltrim('&SNAP_ID_MAX')||'.out' FILE_NAME from dual;

set timing on
TIMING START full_capture_script
spool &SPOOL_FILE_NAME


-- ##############################################################################################
REPHEADER ON
REPFOOTER ON 

set linesize 1000 
set numwidth 10
set wrap off
set heading on
set trimspool on
set feedback off




set serveroutput on
DECLARE
    l_pad_length number :=60;
	l_hosts	varchar2(4000);
	l_dbid	number;
BEGIN


    dbms_output.put_line('~~BEGIN-OS-INFORMATION~~');
    dbms_output.put_line(rpad('STAT_NAME',l_pad_length)||' '||'STAT_VALUE');
    dbms_output.put_line(rpad('-',l_pad_length,'-')||' '||rpad('-',l_pad_length,'-'));
    
    FOR c1 IN (
			with inst as (
		select min(instance_number) inst_num
		  from dba_hist_snapshot
		  where dbid = &DBID
			and snap_id BETWEEN to_number(&SNAP_ID_MIN) and to_number(&SNAP_ID_MAX))
	SELECT 
                      CASE WHEN stat_name = 'PHYSICAL_MEMORY_BYTES' THEN 'PHYSICAL_MEMORY_GB' ELSE stat_name END stat_name,
                      CASE WHEN stat_name IN ('PHYSICAL_MEMORY_BYTES') THEN round(VALUE/1024/1024/1024,2) ELSE VALUE END stat_value
                  FROM dba_hist_osstat 
                 WHERE dbid = &DBID 
                   AND snap_id = (SELECT MAX(snap_id) FROM dba_hist_osstat WHERE dbid = &DBID AND instance_number = (select inst_num from inst))
				   AND instance_number = (select inst_num from inst)
                   AND (stat_name LIKE 'NUM_CPU%'
                   OR stat_name IN ('PHYSICAL_MEMORY_BYTES')))
    loop
        dbms_output.put_line(rpad(c1.stat_name,l_pad_length)||' '||c1.stat_value);
    end loop; --c1
    
	for c1 in (SELECT CPU_COUNT,CPU_CORE_COUNT,CPU_SOCKET_COUNT
				 FROM DBA_CPU_USAGE_STATISTICS 
				where dbid = &DBID
				  and TIMESTAMP = (select max(TIMESTAMP) from DBA_CPU_USAGE_STATISTICS where dbid = &DBID )
				  AND ROWNUM = 1)
	loop
		dbms_output.put_line(rpad('!CPU_COUNT',l_pad_length)||' '||c1.CPU_COUNT);
		dbms_output.put_line(rpad('!CPU_CORE_COUNT',l_pad_length)||' '||c1.CPU_CORE_COUNT);
		dbms_output.put_line(rpad('!CPU_SOCKET_COUNT',l_pad_length)||' '||c1.CPU_SOCKET_COUNT);
	end loop;
	
	for c1 in (SELECT distinct platform_name FROM sys.GV_$DATABASE 
				where dbid = &DBID
				and rownum = 1)
	loop
		dbms_output.put_line(rpad('!PLATFORM_NAME',l_pad_length)||' '||c1.platform_name);
	end loop;

	
	
	FOR c2 IN (SELECT 
						$IF $$VER_GTE_11_2 $THEN
							REPLACE(platform_name,' ','_') platform_name,
						$ELSE
							'None' platform_name,
						$END
						VERSION,db_name,DBID FROM dba_hist_database_instance 
						WHERE dbid = &DBID  
						and startup_time = (select max(startup_time) from dba_hist_database_instance WHERE dbid = &DBID )
						AND ROWNUM = 1)
    loop
        dbms_output.put_line(rpad('PLATFORM_NAME',l_pad_length)||' '||c2.platform_name);
        dbms_output.put_line(rpad('VERSION',l_pad_length)||' '||c2.VERSION);
        dbms_output.put_line(rpad('DB_NAME',l_pad_length)||' '||c2.db_name);
        dbms_output.put_line(rpad('DBID',l_pad_length)||' '||c2.DBID);
    end loop; --c2
    
    FOR c3 IN (SELECT count(distinct s.instance_number) instances
			     FROM dba_hist_database_instance i,dba_hist_snapshot s
				WHERE i.dbid = s.dbid
				  and i.dbid = &DBID
				  AND s.snap_id BETWEEN &SNAP_ID_MIN AND &SNAP_ID_MAX)
    loop
        dbms_output.put_line(rpad('INSTANCES',l_pad_length)||' '||c3.instances);
    end loop; --c3           
	
	
	FOR c4 IN (SELECT distinct regexp_replace(host_name,'^([[:alnum:]]+)\..*$','\1')  host_name 
			     FROM dba_hist_database_instance i,dba_hist_snapshot s
				WHERE i.dbid = s.dbid
				  and i.dbid = &DBID
                  and s.startup_time = i.startup_time
				  AND s.snap_id BETWEEN &SNAP_ID_MIN AND &SNAP_ID_MAX
			    order by 1)
    loop
		if '&CAPTURE_HOST_NAMES' = 'YES' then
			l_hosts := l_hosts || c4.host_name ||',';	
		end if;
	end loop; --c4
	l_hosts := rtrim(l_hosts,',');
	dbms_output.put_line(rpad('HOSTS',l_pad_length)||' '||l_hosts);
	

	FOR c5 IN (SELECT REGEXP_REPLACE(sys_context('USERENV', 'MODULE'),'^(.+?)@.+$','\1') module FROM DUAL)
    loop
        dbms_output.put_line(rpad('MODULE',l_pad_length)||' '||c5.module);
    end loop; --c5  
	
	
	
	dbms_output.put_line(rpad('AWR_SEARCH_VER',l_pad_length)||' &AWR_SEARCH_VER');
	dbms_output.put_line('~~END-OS-INFORMATION~~');
END;
/

prompt 
prompt 




-- ##############################################################################################

REPHEADER PAGE LEFT '~~BEGIN-MEMORY~~'
REPFOOTER PAGE LEFT '~~END-MEMORY~~'

SELECT snap_id,
    instance_number,
    MAX (DECODE (stat_name, 'SGA', stat_value, NULL)) "SGA",
    MAX (DECODE (stat_name, 'PGA', stat_value, NULL)) "PGA",
    MAX (DECODE (stat_name, 'SGA', stat_value, NULL)) + MAX (DECODE (stat_name, 'PGA', stat_value,
    NULL)) "TOTAL"
   FROM
    (SELECT snap_id,
        instance_number,
        ROUND (SUM (bytes) / 1024 / 1024 / 1024, 1) stat_value,
        MAX ('SGA') stat_name
       FROM dba_hist_sgastat
      WHERE dbid = &DBID
        AND snap_id BETWEEN &SNAP_ID_MIN AND &SNAP_ID_MAX
   GROUP BY snap_id,
        instance_number
  UNION ALL
     SELECT snap_id,
        instance_number,
        ROUND (value / 1024 / 1024 / 1024, 1) stat_value,
        'PGA' stat_name
       FROM dba_hist_pgastat
      WHERE dbid = &DBID
        AND snap_id BETWEEN &SNAP_ID_MIN AND &SNAP_ID_MAX
        AND NAME = 'total PGA allocated'
    )
GROUP BY snap_id,
    instance_number
ORDER BY snap_id,
    instance_number;

prompt 
prompt 




-- ##############################################################################################


 
REPHEADER PAGE LEFT '~~BEGIN-SIZE-ON-DISK~~'
REPFOOTER PAGE LEFT '~~END-SIZE-ON-DISK~~'
 WITH ts_info as (
select dbid, ts#, tsname, max(block_size) block_size
from dba_hist_datafile
where dbid = &DBID
group by dbid, ts#, tsname),
-- Get the maximum snaphsot id for each day from dba_hist_snapshot
snap_info as (
select dbid,to_char(trunc(end_interval_time,'DD'),'MM/DD/YY') dd, max(s.snap_id) snap_id
FROM dba_hist_snapshot s
where s.snap_id between &SNAP_ID_MIN and &SNAP_ID_MAX
and dbid = &DBID
--where s.end_interval_time > to_date(:start_time,'MMDDYYYY')
--and s.end_interval_time < to_date(:end_time,'MMDDYYYY')
group by dbid,trunc(end_interval_time,'DD'))
-- Sum up the sizes of all the tablespaces for the last snapshot of each day
select s.snap_id, round(sum(tablespace_size*f.block_size)/1024/1024/1024,2) size_gb
from dba_hist_tbspc_space_usage sp,
ts_info f,
snap_info s
WHERE s.dbid = sp.dbid
AND s.dbid = &DBID
 and s.snap_id between &SNAP_ID_MIN and &SNAP_ID_MAX
and s.snap_id = sp.snap_id
and sp.dbid = f.dbid
AND sp.tablespace_id = f.ts#
GROUP BY  s.snap_id,s.dd, s.dbid
order by  s.snap_id;

prompt 
prompt   
-- ##############################################################################################

REPHEADER PAGE LEFT '~~BEGIN-OSSTAT~~'
REPFOOTER PAGE LEFT '~~END-OSSTAT~~'


SELECT snap_id,
  INSTANCE_NUMBER,
  MAX(DECODE(STAT_NAME,'LOAD', round(value,1),NULL)) "load",
  MAX(DECODE(STAT_NAME,'NUM_CPUS', value,NULL)) "cpus",
  MAX(DECODE(STAT_NAME,'NUM_CPU_CORES', value,NULL)) "cores",
  MAX(DECODE(STAT_NAME,'NUM_CPU_SOCKETS', value,NULL)) "sockets",
  MAX(DECODE(STAT_NAME,'PHYSICAL_MEMORY_BYTES', ROUND(value/1024/1024),NULL)) "mem_gb",
  MAX(DECODE(STAT_NAME,'FREE_MEMORY_BYTES', ROUND(value    /1024/1024),NULL)) "mem_free_gb",
  MAX(DECODE(STAT_NAME,'IDLE_TIME', value,NULL)) "idle",
  MAX(DECODE(STAT_NAME,'BUSY_TIME', value,NULL)) "busy",
  MAX(DECODE(STAT_NAME,'USER_TIME', value,NULL)) "user",
  MAX(DECODE(STAT_NAME,'SYS_TIME', value,NULL)) "sys",
  MAX(DECODE(STAT_NAME,'IOWAIT_TIME', value,NULL)) "iowait",
  MAX(DECODE(STAT_NAME,'NICE_TIME', value,NULL)) "nice",
  MAX(DECODE(STAT_NAME,'OS_CPU_WAIT_TIME', value,NULL)) "cpu_wait",
  MAX(DECODE(STAT_NAME,'RSRC_MGR_CPU_WAIT_TIME', value,NULL)) "rsrc_mgr_wait",
  MAX(DECODE(STAT_NAME,'VM_IN_BYTES', value,NULL)) "vm_in",
  MAX(DECODE(STAT_NAME,'VM_OUT_BYTES', value,NULL)) "vm_out",
  MAX(DECODE(STAT_NAME,'cpu_count', value,NULL)) "cpu_count"
FROM
  (SELECT snap_id,
    INSTANCE_NUMBER,
    STAT_NAME,
    value
  FROM DBA_HIST_OSSTAT
    where dbid = &DBID
      and snap_id between &SNAP_ID_MIN and &SNAP_ID_MAX
  union all
  SELECT SNAP_ID,
  INSTANCE_NUMBER,
  PARAMETER_NAME STAT_NAME,
  to_number(VALUE) value
 FROM DBA_HIST_PARAMETER 
where dbid = &DBID
  and snap_id between &SNAP_ID_MIN and &SNAP_ID_MAX
  and PARAMETER_NAME = 'cpu_count'
  )
GROUP BY snap_id,
  INSTANCE_NUMBER
ORDER BY snap_id,
  INSTANCE_NUMBER;


prompt 
prompt   
-- ##############################################################################################




REPHEADER PAGE LEFT '~~BEGIN-MAIN-METRICS~~'
REPFOOTER PAGE LEFT '~~END-MAIN-METRICS~~'

 select snap_id "snap",num_interval "dur_m", end_time "end",inst "inst",
  max(decode(metric_name,'Host CPU Utilization (%)',					average,null)) "os_cpu",
  max(decode(metric_name,'Host CPU Utilization (%)',					maxval,null)) "os_cpu_max",
  max(decode(metric_name,'Host CPU Utilization (%)',					STANDARD_DEVIATION,null)) "os_cpu_sd",
  max(decode(metric_name,'Database Wait Time Ratio',                   round(average,1),null)) "db_wait_ratio",
max(decode(metric_name,'Database CPU Time Ratio',                   round(average,1),null)) "db_cpu_ratio",
max(decode(metric_name,'CPU Usage Per Sec',                   round(average/100,3),null)) "cpu_per_s",
max(decode(metric_name,'CPU Usage Per Sec',                   round(STANDARD_DEVIATION/100,3),null)) "cpu_per_s_sd",
max(decode(metric_name,'Host CPU Usage Per Sec',                   round(average/100,3),null)) "h_cpu_per_s",
max(decode(metric_name,'Host CPU Usage Per Sec',                   round(STANDARD_DEVIATION/100,3),null)) "h_cpu_per_s_sd",
max(decode(metric_name,'Average Active Sessions',                   average,null)) "aas",
max(decode(metric_name,'Average Active Sessions',                   STANDARD_DEVIATION,null)) "aas_sd",
max(decode(metric_name,'Average Active Sessions',                   maxval,null)) "aas_max",
max(decode(metric_name,'Database Time Per Sec',					average,null)) "db_time",
max(decode(metric_name,'Database Time Per Sec',					STANDARD_DEVIATION,null)) "db_time_sd",
max(decode(metric_name,'SQL Service Response Time',                   average,null)) "sql_res_t_cs",
max(decode(metric_name,'Background Time Per Sec',                   average,null)) "bkgd_t_per_s",
max(decode(metric_name,'Logons Per Sec',                            average,null)) "logons_s",
max(decode(metric_name,'Current Logons Count',                      average,null)) "logons_total",
max(decode(metric_name,'Executions Per Sec',                        average,null)) "exec_s",
max(decode(metric_name,'Hard Parse Count Per Sec',                  average,null)) "hard_p_s",
max(decode(metric_name,'Logical Reads Per Sec',                     average,null)) "l_reads_s",
max(decode(metric_name,'User Commits Per Sec',                      average,null)) "commits_s",
max(decode(metric_name,'Physical Read Total Bytes Per Sec',         round((average)/1024/1024,1),null)) "read_mb_s",
max(decode(metric_name,'Physical Read Total Bytes Per Sec',         round((maxval)/1024/1024,1),null)) "read_mb_s_max",
max(decode(metric_name,'Physical Read Total IO Requests Per Sec',   average,null)) "read_iops",
max(decode(metric_name,'Physical Read Total IO Requests Per Sec',   maxval,null)) "read_iops_max",
max(decode(metric_name,'Physical Reads Per Sec',  			average,null)) "read_bks",
max(decode(metric_name,'Physical Reads Direct Per Sec',  			average,null)) "read_bks_direct",
max(decode(metric_name,'Physical Write Total Bytes Per Sec',        round((average)/1024/1024,1),null)) "write_mb_s",
max(decode(metric_name,'Physical Write Total Bytes Per Sec',        round((maxval)/1024/1024,1),null)) "write_mb_s_max",
max(decode(metric_name,'Physical Write Total IO Requests Per Sec',  average,null)) "write_iops",
max(decode(metric_name,'Physical Write Total IO Requests Per Sec',  maxval,null)) "write_iops_max",
max(decode(metric_name,'Physical Writes Per Sec',  			average,null)) "write_bks",
max(decode(metric_name,'Physical Writes Direct Per Sec',  			average,null)) "write_bks_direct",
max(decode(metric_name,'Redo Generated Per Sec',                    round((average)/1024/1024,1),null)) "redo_mb_s",
max(decode(metric_name,'DB Block Gets Per Sec',                     average,null)) "db_block_gets_s",
max(decode(metric_name,'DB Block Changes Per Sec',                   average,null)) "db_block_changes_s",
max(decode(metric_name,'GC CR Block Received Per Second',            average,null)) "gc_cr_rec_s",
max(decode(metric_name,'GC Current Block Received Per Second',       average,null)) "gc_cu_rec_s",
max(decode(metric_name,'Global Cache Average CR Get Time',           average,null)) "gc_cr_get_cs",
max(decode(metric_name,'Global Cache Average Current Get Time',      average,null)) "gc_cu_get_cs",
max(decode(metric_name,'Global Cache Blocks Corrupted',              average,null)) "gc_bk_corrupted",
max(decode(metric_name,'Global Cache Blocks Lost',                   average,null)) "gc_bk_lost",
max(decode(metric_name,'Active Parallel Sessions',                   average,null)) "px_sess",
max(decode(metric_name,'Active Serial Sessions',                     average,null)) "se_sess",
max(decode(metric_name,'Average Synchronous Single-Block Read Latency', average,null)) "s_blk_r_lat",
max(decode(metric_name,'Cell Physical IO Interconnect Bytes',         round((average)/1024/1024,1),null)) "cell_io_int_mb",
max(decode(metric_name,'Cell Physical IO Interconnect Bytes',         round((maxval)/1024/1024,1),null)) "cell_io_int_mb_max"
  from(
  select  snap_id,num_interval,to_char(end_time,'YY/MM/DD HH24:MI') end_time,instance_number inst,metric_name,round(average,1) average,
  round(maxval,1) maxval,round(standard_deviation,1) standard_deviation
 from dba_hist_sysmetric_summary
where dbid = &DBID
 and snap_id between &SNAP_ID_MIN and &SNAP_ID_MAX
 --and snap_id = 920
 --and instance_number = 4
 and metric_name in ('Host CPU Utilization (%)','CPU Usage Per Sec','Host CPU Usage Per Sec','Average Active Sessions','Database Time Per Sec',
 'Executions Per Sec','Hard Parse Count Per Sec','Logical Reads Per Sec','Logons Per Sec',
 'Physical Read Total Bytes Per Sec','Physical Read Total IO Requests Per Sec','Physical Reads Per Sec','Physical Write Total Bytes Per Sec',
 'Redo Generated Per Sec','User Commits Per Sec','Current Logons Count','DB Block Gets Per Sec','DB Block Changes Per Sec',
 'Database Wait Time Ratio','Database CPU Time Ratio','SQL Service Response Time','Background Time Per Sec',
 'Physical Write Total IO Requests Per Sec','Physical Writes Per Sec','Physical Writes Direct Per Sec','Physical Writes Direct Lobs Per Sec',
 'Physical Reads Direct Per Sec','Physical Reads Direct Lobs Per Sec',
 'GC CR Block Received Per Second','GC Current Block Received Per Second','Global Cache Average CR Get Time','Global Cache Average Current Get Time',
 'Global Cache Blocks Corrupted','Global Cache Blocks Lost',
 'Active Parallel Sessions','Active Serial Sessions','Average Synchronous Single-Block Read Latency','Cell Physical IO Interconnect Bytes'
    )
 )
 group by snap_id,num_interval, end_time,inst
 order by snap_id, end_time,inst;
 
 

prompt 
prompt 

  
  
REPHEADER OFF
REPFOOTER OFF
TIMING STOP 
spool off

ALTER SESSION SET WORKAREA_SIZE_POLICY = AUTO;
quit;
