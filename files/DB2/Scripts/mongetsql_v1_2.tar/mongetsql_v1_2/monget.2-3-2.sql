SELECT 
 GET_TIMESTAMP,
 sum(TOTAL_RQST_TIME) as TotalReqTime,
 sum(CLIENT_IDLE_WAIT_TIME) as ClientIdleWait,
 case when sum(TOTAL_RQST_TIME) < 100 then null else
  cast(float(sum(CLIENT_IDLE_WAIT_TIME))/sum(TOTAL_RQST_TIME) as decimal(10,2)) end
    as Ratio_of_CientWait,
 case when sum(TOTAL_RQST_TIME) < 100 then null else
  cast(100.0 * sum(TOTAL_WAIT_TIME)/sum(TOTAL_RQST_TIME) as decimal(4,1)) end
    as "WaitTime_ReqTime",
 case when sum(TOTAL_WAIT_TIME) < 100 then null else
      cast(100.0*sum(LOCK_WAIT_TIME)/sum(TOTAL_WAIT_TIME) as decimal(4,1)) end
          as LockWaitPct,
 case when sum(TOTAL_WAIT_TIME) < 100 then null else
      cast(100.0*sum(POOL_READ_TIME+POOL_WRITE_TIME)/sum(TOTAL_WAIT_TIME) as decimal(4,1)) end
          as PoolIOPct,
 case when sum(TOTAL_WAIT_TIME) < 100 then null else
      cast(100.0*sum(DIRECT_READ_TIME+DIRECT_WRITE_TIME)/sum(TOTAL_WAIT_TIME) as decimal(4,1)) end
          as DirectIOPCT,
 case when sum(TOTAL_WAIT_TIME) < 100 then null else
      cast(100.0*sum(LOG_DISK_WAIT_TIME)/sum(TOTAL_WAIT_TIME) as decimal(4,1)) end
          as LogDiskWaitPct,
 case when sum(TOTAL_WAIT_TIME) < 100 then null else
      cast(100.0*sum(TCPIP_RECV_WAIT_TIME+TCPIP_SEND_WAIT_TIME)/sum(TOTAL_WAIT_TIME) as decimal(4,1)) end
          as  TCPIPWaitPct,
 case when sum(TOTAL_WAIT_TIME) < 100 then null else
      cast(100.0*sum(IPC_RECV_WAIT_TIME+IPC_SEND_WAIT_TIME)/sum(TOTAL_WAIT_TIME) as decimal(4,1)) end
          as  IPCWaitPct,
 case when sum(TOTAL_WAIT_TIME) < 100 then null else
      cast(100.0*sum(FCM_RECV_WAIT_TIME+FCM_SEND_WAIT_TIME)/sum(TOTAL_WAIT_TIME) as decimal(4,1)) end
          as  FCMWaitPct
FROM
  MONDELTA.MONGET_WORKLOAD_DATA
GROUP BY GET_TIMESTAMP;
