SELECT
  GET_TIMESTAMP,
  member,
  substr(bp_name,1,15) as bp_name,
  POOL_DATA_L_READS,
  POOL_DATA_P_READS,
  POOL_INDEX_L_READS,
  POOL_INDEX_P_READS,
  case when POOL_DATA_L_READS < 1000 then null else
  cast (100*(float(POOL_DATA_L_READS - POOL_DATA_P_READS)) / POOL_DATA_L_READS as decimal(4,1)) end
    as DataHit,
  case when POOL_INDEX_L_READS < 1000 then null else
  cast (100*(float(POOL_INDEX_L_READS - POOL_INDEX_P_READS)) / POOL_INDEX_L_READS as decimal(4,1)) end
    as IndexHit,
  case when POOL_TEMP_DATA_L_READS < 1000 then null else
  cast (100*(float(POOL_TEMP_DATA_L_READS - POOL_TEMP_DATA_P_READS)) / POOL_TEMP_DATA_L_READS as decimal(4,1)) end
    as TempDataHit,
  case when POOL_TEMP_INDEX_L_READS < 1000 then null else
  cast (100*(float(POOL_TEMP_INDEX_L_READS - POOL_TEMP_INDEX_P_READS)) / POOL_TEMP_INDEX_L_READS as decimal(4,1)) end
    as TempIndexHit,
  case when POOL_DATA_P_READS+POOL_TEMP_DATA_P_READS
                +POOL_INDEX_P_READS+POOL_TEMP_INDEX_P_READS < 1000 then null else
  cast(100*(1.0-(float(POOL_DATA_P_READS+POOL_TEMP_DATA_P_READS+POOL_INDEX_P_READS+POOL_TEMP_INDEX_P_READS)
                      - float(POOL_ASYNC_DATA_READS+POOL_ASYNC_INDEX_READS)) /
                        float(POOL_DATA_P_READS+POOL_TEMP_DATA_P_READS+POOL_INDEX_P_READS+POOL_TEMP_INDEX_P_READS))
                      as decimal(4,1)) end
  as PrefetchRatio,
  case when POOL_ASYNC_INDEX_READS+POOL_ASYNC_DATA_READS < 1000 then null else
  cast(100*float(UNREAD_PREFETCH_PAGES)/float(POOL_ASYNC_INDEX_READS+POOL_ASYNC_DATA_READS) as decimal(4,1)) end
  as Prefetch_unread
  from MONDELTA.MONGET_BUFFERPOOL_DATA where bp_name not like 'IBMSYSTEMBP%';
