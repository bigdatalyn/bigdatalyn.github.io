SELECT
 GET_TIMESTAMP,
 sum(TOTAL_ACT_TIME) as TOTAL_ACT_TIME,
 sum(ACT_COMPLETED_TOTAL) as ACT_COMPLETED_TOTAL,

 case when sum(ACT_COMPLETED_TOTAL) < 100 then null else
 cast( float(sum(TOTAL_ACT_TIME))   / sum(ACT_COMPLETED_TOTAL) as decimal(6,2)) end
  as ACT_TIME_AVG,

 case when sum(TOTAL_ACT_TIME) < 100 then null else
  cast(100*float(sum(TOTAL_ACT_WAIT_TIME))/(sum(TOTAL_ACT_TIME)) as decimal(4,2)) end
    as WaitTime_percent

FROM
  MONDELTA.MONGET_WORKLOAD_DATA
GROUP BY GET_TIMESTAMP
;
