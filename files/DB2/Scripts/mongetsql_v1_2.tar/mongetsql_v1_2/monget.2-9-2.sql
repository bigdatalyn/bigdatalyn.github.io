select
  MEMBER,
  case when TOTAL_LOG_AVAILABLE < 100 then null else
  cast (100*TOTAL_LOG_USED/TOTAL_LOG_AVAILABLE as decimal(4,1)) end
     as LOG_USED_PERCENT
from table(mon_get_transaction_log(-1)) as t
order by member asc;
