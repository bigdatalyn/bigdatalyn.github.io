SELECT int(l.EVENT_ID)              as EVENT_ID, 
       l.EVENT_TIMESTAMP, 
       substr(l.EVENT_TYPE,1,10)    as TYPE, 
       p.PARTICIPANT_NO, 
       substr(p.APPL_ID,1,28)       as APPLID, 
       substr(p.APPL_NAME,1,12)     as APPLNAME, 
       int(p.APPLICATION_HANDLE)    as APPLHANDLE, 
       l.ROLLED_BACK_PARTICIPANT_NO as VICTIM
from LOCK_lcktevmon l, LOCK_PARTICIPANTS_lcktevmon p 
where l.EVENT_TYPE='DEADLOCK' AND l.EVENT_ID=p.EVENT_ID
;
