select
  b.GET_TIMESTAMP,
  substr(b.bp_name,1,10) as Bufferpool,
  case when sum(w.TOTAL_APP_COMMITS) < 1 then null else
    cast( float(sum(b.POOL_DATA_P_READS+b.POOL_INDEX_P_READS+
                    b.POOL_TEMP_DATA_P_READS+b.POOL_TEMP_INDEX_P_READS))
              / sum(w.TOTAL_APP_COMMITS) as decimal(6,1)) end as BPPhysRds_UOW,
  case when sum(b.POOL_DATA_P_READS+b.POOL_INDEX_P_READS+
                b.POOL_TEMP_DATA_P_READS+b.POOL_TEMP_INDEX_P_READS) < 10 then null else
    cast( float(sum(b.POOL_READ_TIME))
              / sum(b.POOL_DATA_P_READS+b.POOL_INDEX_P_READS+
                    b.POOL_TEMP_DATA_P_READS+b.POOL_TEMP_INDEX_P_READS) as decimal(5,1)) end as MS_BPrd,
  case when sum(w.TOTAL_APP_COMMITS) < 1 then null else
    cast( float(sum(b.POOL_DATA_WRITES+b.POOL_INDEX_WRITES))
              / sum(w.TOTAL_APP_COMMITS) as decimal(6,1)) end   as BPWrt_UOW,
  case when sum(b.POOL_DATA_WRITES+b.POOL_INDEX_WRITES) < 10 then null else
    cast( float(sum(b.POOL_WRITE_TIME))
              / sum(b.POOL_DATA_WRITES+b.POOL_INDEX_WRITES) as decimal(5,1)) end as MS_BPWrt,
  case when sum(w.TOTAL_APP_COMMITS) < 1 then null else
    cast( float(sum(b.DIRECT_READS))
              / sum(w.TOTAL_APP_COMMITS) as decimal(6,1)) end   as DirectRds_UOW,
  case when sum(b.DIRECT_READS) < 10 then null else
    cast( 8.0*sum(b.DIRECT_READ_TIME)
              / sum(b.DIRECT_READS) as decimal(5,1)) end  as MS_8DirWrt_4k,
  case when sum(w.TOTAL_APP_COMMITS) < 1 then null else
    cast( float(sum(b.DIRECT_WRITES))
              / sum(w.TOTAL_APP_COMMITS) as decimal(6,1)) end as DirectWrts_UOW,
  case when sum(b.DIRECT_WRITES) < 10 then null else
    cast( 8.0*sum(b.DIRECT_WRITE_TIME)
              / sum(b.DIRECT_WRITES) as decimal(5,1)) end as MS_8DirWrt_4K
  from MONDELTA.MONGET_BUFFERPOOL_DATA as b,
       MONDELTA.MONGET_WORKLOAD_DATA as w
  group by bp_name,b.GET_TIMESTAMP;
