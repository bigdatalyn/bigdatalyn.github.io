set feedback off
prompt Specify the number of days of snapshots to choose from
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
define days=&0
select a.snap_id, to_char(a.begin_interval_time,'yyyy-mm-dd hh24:mi:ss') snap_time from dba_hist_snapshot a
where a.instance_number=(select b.instance_number from v$instance b) 
and a.begin_interval_time > sysdate-&days
order by 1;
/*****************************************
--para1 begin snap id
--para2 end snap id
--para3 split X ( input 80 for thinkpad X230,X250)
--para4 instance number
*****************************************/
set termout       on
set echo          off
set heading       on
prompt Specify the Begin and End Snapshot Ids
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
COLUMN spool_time NEW_VALUE _spool_time NOPRINT
SELECT TO_CHAR(SYSDATE,'YYYYMMDDhh24miss') spool_time FROM dual;
COLUMN iv NEW_VALUE _iv NOPRINT
select trunc(3600*24*(sysdate+snaP_interval-sysdate)) iv from dba_hist_wr_control;

COLUMN dbname NEW_VALUE _dbname NOPRINT
SELECT name dbname FROM v$database;
prompt begin snap id is
define bid=&1
prompt end snap id is
define eid=&2
prompt time point limit to split X-axis is : (for instance ,using thinkpad x230, better to be 80)
define maxx=&3
prompt instance number is
define inid=&4
set long 2000000
set pages 0
set linesize 999
set termout       off
set echo          off
set feedback      off
set heading       off
set verify        off
set wrap          on 
set trimspool     on
set serveroutput on size  unlimited
set escape        on
--spool awrcrt_&_dbname._&_spool_time..html
spool awrcrt_&_dbname._&inid._&bid._&eid..html
prompt <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
prompt <html xmlns="http://www.w3.org/1999/xhtml">
prompt <head>
prompt <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
prompt <title>AWR Chart Report 0.9</title>
prompt <style type="text/css">body.awr {font:bold 10pt Arial,Helvetica,Geneva,sans-serif;color:black; background:White;}
prompt pre.awr  {font:8pt Courier;color:black; background:White;}h1.awr   {font:bold 20pt Arial,Helvetica,Geneva,sans-serif;color:#336699;background-color:White;border-bottom:1px solid #cccc99;margin-top:0pt; margin-bottom:0pt;padding:0px 0px 0px 0px;}
prompt h2.awr   {font:bold 18pt Arial,Helvetica,Geneva,sans-serif;color:#336699;background-color:White;margin-top:4pt; margin-bottom:0pt;}
prompt h3.awr {font:bold 16pt Arial,Helvetica,Geneva,sans-serif;color:#336699;background-color:White;margin-top:4pt; margin-bottom:0pt;}li.awr {font: 8pt Arial,Helvetica,Geneva,sans-serif; color:black; background:White;}
prompt h4.awr   {font:bold 20pt Arial,Helvetica,Geneva,sans-serif;color:#ff0000;}
prompt th.awrnobg {font:bold 8pt Arial,Helvetica,Geneva,sans-serif; color:black; background:White;padding-left:4px; padding-right:4px;padding-bottom:2px}th.awrbg {font:bold 8pt Arial,Helvetica,Geneva,sans-serif; color:White; background:#0066CC;padding-left:4px; padding-right:4px;padding-bottom:2px}
prompt td.awrnc {font:8pt Arial,Helvetica,Geneva,sans-serif;color:black;background:White;vertical-align:top;}
prompt td.awrc    {font:8pt Arial,Helvetica,Geneva,sans-serif;color:black;background:#FFFFCC; vertical-align:top;}
prompt a.awr {font:bold 8pt Arial,Helvetica,sans-serif;color:#663300; vertical-align:top;margin-top:0pt; margin-bottom:0pt;}
prompt a1.awr {font:bold 10pt Arial,Helvetica,sans-serif;color:#0000FF; vertical-align:top;margin-top:0pt; margin-bottom:0pt;}
prompt </style>
prompt <script src="crt.js"></script>
prompt </head>
prompt <body class='awr'>
prompt <H1 class='awr'>
prompt WORKLOAD REPOSITORY CHART report for
prompt </H1>
prompt <p/>
prompt <TABLE BORDER=1 WIDTH=500>
prompt <tr><th class='awrbg'>DB Name</th><th class='awrbg'>DB Id</th><th class='awrbg'>Instance</th><th class='awrbg'>Inst num</th><th class='awrbg'>Release</th><th class='awrbg'>RAC</th><th class='awrbg'>Host</th></tr>
prompt <tr><TD class='awrnc'>
SELECT A.NAME||'</td><TD ALIGN=''right'' class=''awrnc''>'
||A.DBID||'</td><TD class=''awrnc''>'||(SELECT B.INSTANCE_NAME||'</td><TD ALIGN=''right'' class=''awrnc''>'||&inid||'</td><TD class=''awrnc''>'||B.VERSION || '</td><TD class=''awrnc''>'||(SELECT value FROM V$PARAMETER C WHERE C.NAME ='cluster_database')||'</td><TD class=''awrnc''>'||b.HOST_NAME FROM V$INSTANCE B WHERE B.INSTANCE_NUMBER=1)
  FROM V$DATABASE A;
prompt </td></tr>
prompt </table>
prompt <p />
prompt <TABLE BORDER=1 WIDTH=500>
prompt <tr><th class='awrnobg'></th><th class='awrbg'>Snap Id</th><th class='awrbg'>Snap Time</th></tr>
prompt <tr><TD class='awrnc'>Begin Snap:</td><TD ALIGN='right' class='awrnc'>&bid</td><TD ALIGN='center' class='awrnc'>
select  
nvl((select to_char(a.begin_interval_time,'yyyy-mm-dd hh24:mi:ss') from dba_hist_snapshot a where a.instance_number=&inid and a.snap_id=&bid),
'minimum snap time')
from dual;
prompt </td></tr>
prompt <tr><TD class='awrc'>End Snap:</td><TD ALIGN='right' class='awrc'>&eid</td><TD ALIGN='center' class='awrc'>
select  
nvl((select to_char(a.begin_interval_time,'yyyy-mm-dd hh24:mi:ss') from dba_hist_snapshot a where a.instance_number=&inid and a.snap_id=&eid),
'maximum snap time')
from dual;
prompt </td></tr>
prompt </table>
prompt <p />
prompt <a class="awr" name="top"></a>
prompt <h2 class="awr">
prompt Main Report
prompt </h2>
prompt <hr>
prompt <ul>
prompt <li class="awr"><a class="awr" href="#1">CPU Utilization </a></li>
prompt <li class="awr"><a class="awr" href="#2">Time Model : DB TIME  DB CPU SQL EXEC TIME</a></li>
prompt <li class="awr"><a class="awr" href="#21">Active session history</a></li>
prompt <li class="awr"><a class="awr" href="#3">SQL execution count </a></li>
prompt <li class="awr"><a class="awr" href="#4">Average SQL execution time </a></li>
prompt <li class="awr"><a class="awr" href="#5">Session logic reads</a></li>
prompt <li class="awr"><a class="awr" href="#6">Physical writes and reads </a></li>
prompt <li class="awr"><a class="awr" href="#7">User commits </a></li>
prompt <li class="awr"><a class="awr" href="#8">Connections</a></li>
prompt <li class="awr"><a class="awr" href="#9">Redo Size </a></li>
prompt <li class="awr"><a class="awr" href="#10">Global cache transformation</a></li>
prompt <li class="awr"><a class="awr" href="#11">GCS/GES messages </a></li>
prompt <li class="awr"><a class="awr" href="#12">Global Cache Average CR Time</a></li>
prompt <li class="awr"><a class="awr" href="#13">Global Cache Average Current Get Time</a></li>
prompt <li class="awr"><a class="awr" href="#14">Buffer Cache Hit POINT</a></li>
prompt <li class="awr"><a class="awr" href="#141">PGA Cache Hit POINT</a></li>
prompt <li class="awr"><a class="awr" href="#140">Library Hit POINT</a></li>
prompt <li class="awr"><a class="awr" href="#161">Latch Hit POINT</a></li>
prompt <li class="awr"><a class="awr" href="#16">Latch:shared pool</a></li>
prompt <li class="awr"><a class="awr" href="#17">Latch:row cache objects</a></li>
prompt <li class="awr"><a class="awr" href="#18">Latch:cache buffers chains</a></li>
prompt <li class="awr"><a class="awr" href="#19">Latch:cache buffers lru chain</a></li>
prompt <li class="awr"><a class="awr" href="#20">Latch:gc element</a></li>
prompt <li class="awr"><a class="awr" href="#21">Latch:DML lock allocation</a></li>
prompt <li class="awr"><a class="awr" href="#211">Parse count</a></li>
prompt <li class="awr"><a class="awr" href="#212">Hard parse count</a></li>
prompt <li class="awr"><a class="awr" href="#22">Slowest File Average Read Wait time</a></li>
prompt <li class="awr"><a class="awr" href="#23">Table fetch continued row</a></li>
prompt <li class="awr"><a class="awr" href="#24">Dirty buffers inspected</a></li>
prompt <li class="awr"><a class="awr" href="#50">Cell physical IO bytes eligible for predicate offload</a></li>
prompt <li class="awr"><a class="awr" href="#51">Cell physical IO bytes saved by storage index</a></li>
prompt <li class="awr"><a class="awr" href="#52">Cell physical IO interconnect bytes returned by smart scan</a></li>
prompt <li class="awr"><a class="awr" href="#53">Cell IO uncompressed bytes</a></li>
prompt <li class="awr"><a class="awr" href="#151">Top 5 Wait Event</a></li>
prompt <li class="awr"><a class="awr" href="#15">Top 5 Wait Event trends</a></li>
prompt </ul>
prompt <a class="awr" name="1"></a>
prompt <p><h3 class='awr'>Cpu Utilization</h3></p>
prompt <table width="200" border="1">
prompt   <tr>
prompt     <td style="color:rgba(255,0,0,1)"><b>SERVER CPU</b></td>
prompt     <td style="color:rgba(0,255,128,1)"><b>DB CPU</b></td>
prompt     <td style="color:rgba(151,187,205,1)"><b>BACKUP CPU</b></td>
prompt   </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt        <div>
prompt         <canvas id="cpu-area"></canvas>
prompt       </div>
prompt     </div>
prompt <a class="awr" href="#top">Back to Top</a>
prompt <a class="awr" name="2"></a>
prompt <p><h3 class='awr'>Time model: DB TIME , DB CPU TIME, SQL EXECUTION TIME</h3> </p> 
prompt <table width="200" border="1">
prompt   <tr>
prompt     <td style="color:rgba(255,0,0,1)"><b>DB TIME</b></td>
prompt     <td style="color:rgba(255,255,0,1)"><b>DB CPU</b></td>
prompt     <td style="color:rgba(34,139,34,1)"><b>SQL EXEC TIMES</b></td>
prompt   </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt       <div>
prompt        <canvas id="timemodel-area"></canvas>
prompt      </div>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>

prompt <a class="awr" name="21"></a>
prompt <p><h3 class='awr'>Active Session History</h3> </p> 
prompt <table width="200" border="1">
prompt   <tr>
prompt     <td style="color:rgba(255,0,0,1)"><b>CPU</b></td>
prompt     <td style="color:rgba(255,0,128,1)"><b>Concurrency</b></td>
prompt     <td style="color:rgba(255,255,0,1)"><b>Systemio</b></td>
prompt     <td style="color:rgba(0,0,255,1)"><b>userio</b></td>
prompt     <td style="color:rgba(0,128,0,1)"><b>Administrative</b></td>
prompt     <td style="color:rgba(128,128,0,1)"><b>Configuration</b></td>
prompt     <td style="color:rgba(0,255,0,1)"><b>Application</b></td>
prompt     <td style="color:rgba(0,0,0,1)"><b>Network</b></td>
prompt     <td style="color:rgba(128,0,64,1)"><b>Commit</b></td>
prompt     <td style="color:rgba(192,192,192,1)"><b>Scheduler</b></td>
prompt     <td style="color:rgba(0,128,255,1)"><b>Cluster</b></td>
prompt     <td style="color:rgba(128,64,0,1)"><b>Queueing</b></td>
prompt     <td style="color:rgba(255,128,0,1)"><b>Other</b></td>
prompt   </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:450%">
prompt       <div>
prompt        <canvas width="3000px" height="200px" id="ash-area"></canvas>
prompt      </div>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>

prompt
prompt <a class="awr" name="3"></a>
prompt  <p><h3 class='awr'>Workload: SQL EXECUTION COUNT  </h3></p> 
prompt <table width="200" border="1">
prompt  <tr>
prompt    <td style="color:rgba(0,0,205,1)"><b>SQL EXECUTION COUNT Per Second</b></td>
prompt  </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt       <div>
prompt        <canvas id="sqlcount-area"></canvas>
prompt      </div>
prompt    </div>  
prompt <a class="awr" href="#top">Back to Top</a>
  
prompt <a class="awr" name="4"></a>
prompt   <p><h3 class='awr'>AVERAGE SQL EXECUTION TIME</h3></p> 
prompt <table width="200" border="1">
prompt   <tr>
prompt     <td style="color:rgba(50,205,50,1)"><b>AVG SQL EXECUTION TIME</b></td>
prompt   </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt        <div>
prompt         <canvas id="sqlavgtime-area"></canvas>
prompt       </div>
prompt </div>  
prompt <a class="awr" href="#top">Back to Top</a>

prompt <a class="awr" name="5"></a>
prompt   <p><h3 class='awr'>SESSION LOGIC READS AND CONSISTENT GETS</h3> </p> 
prompt <table width="200" border="1">
prompt   <tr>
prompt     <td style="color:rgba(255,255,0,1)"><b>SESSION LOGIC READ Per Second</b></td>
prompt      <td style="color:rgba(255,0,0,1)"><b>CONSISTENT GETS Per Second</b></td>
prompt   </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt        <div>
prompt         <canvas id="logicread-area"></canvas>
prompt       </div>
prompt </div> 
prompt <a class="awr" href="#top">Back to Top</a>

prompt <a class="awr" name="6"></a>
prompt  <p><h3 class='awr'>PHYSICAL WRITES AND READS</h3> </p> 
prompt<table width="200" border="1">
prompt  <tr>
prompt    <td style="color:rgba(0,0,255,1)"><b>PHYSICAL READ (MB) Per Second</b></td>
prompt     <td style="color:rgba(50,205,50,1)"><b>PHYSICAL WRITE (MB) Per Second</b></td>
prompt  </tr>
prompt</table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt<div style="width:75%">
prompt       <div>
prompt        <canvas id="physical-area"></canvas>
prompt      </div>
prompt</div>
prompt <a class="awr" href="#top">Back to Top</a>

prompt <a class="awr" name="7"></a>
prompt   <p>USER COMMITS </p> 
prompt <table width="200" border="1">
prompt   <tr>
prompt     <td style="color:rgba(255,0,0,1)"><b>USER COMMITS Per Second</b></td>
prompt   </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt        <div>
prompt         <canvas id="usercommit-area"></canvas>
prompt       </div>
prompt </div>    
prompt <a class="awr" href="#top">Back to Top</a>

prompt <a class="awr" name="8"></a>
prompt  <p><h3 class='awr'>CONNECTIONS</h3></p> 
prompt<table width="200" border="1">
prompt  <tr>
prompt    <td style="color:rgba(255,128,0,1)"><b>PROCESSES</b></td>
prompt     <td style="color:rgba(128,0,0,1)"><b>SESSIONS</b></td>
prompt  </tr>
prompt</table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt<div style="width:75%">
prompt       <div>
prompt        <canvas id="connect-area"></canvas>
prompt      </div>
prompt</div> 
prompt <a class="awr" href="#top">Back to Top</a>

prompt <a class="awr" name="9"></a>
prompt  <p><h3 class='awr'>REDO SIZE</h3> </p> 
prompt<table width="200" border="1">
prompt  <tr>
prompt    <td style="color:rgba(128,0,255,1)"><b>REDO LOG SIZE(MB)</b></td>
prompt  </tr>
prompt</table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt<div style="width:75%">
prompt       <div>
prompt        <canvas id="archivelog-area"></canvas>
prompt      </div>
prompt    </div>   
prompt <a class="awr" href="#top">Back to Top</a>
     
prompt <a class="awr" name="10"></a>
prompt   <p><h3 class='awr'>GLOBAL CACHE  TRANSFORMATION</h3> </p> 
prompt <table width="200" border="1">
prompt   <tr>
prompt     <td style="color:rgba(0,0,255,1)"><b>Global Cache blocks received</b></td>
prompt      <td style="color:rgba(255,0,0,1)"><b>Global Cache blocks served</b></td>
prompt <td style="color:rgba(0,128,0,1)"><b>DBWR Fusion writes</b></td>
prompt   </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt        <div>
prompt         <canvas id="gcblock-area"></canvas>
prompt       </div>
prompt </div>    
prompt <a class="awr" href="#top">Back to Top</a>

prompt <a class="awr" name="11"></a>
prompt   <p><h3 class='awr'>GCS/GES MESSAGES </h3> </p> 
prompt <table width="200" border="1">
prompt   <tr>
prompt      <td style="color:rgba(255,0,0,1)"><b>GCS/GES messages sent:</b></td>
prompt   </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt        <div>
prompt         <canvas id="gcmessage-area"></canvas>
prompt       </div>
prompt </div>    
prompt <a class="awr" href="#top">Back to Top</a>

prompt <a class="awr" name="12"></a>
prompt   <p><h3 class='awr'>Global Cache Average CR Time</h3></p> 
prompt <table width="200" border="1">
prompt   <tr>
prompt     <td style="color:rgba(0,255,0,1)"><b>Average</b></td>
prompt      <td style="color:rgba(255,0,0,1)"><b>Maxval</b></td>
prompt   </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt        <div>
prompt         <canvas id="gccrtime-area"></canvas>
prompt       </div>
prompt </div>    
prompt <a class="awr" href="#top">Back to Top</a>

prompt <a class="awr" name="13"></a>
prompt   <p><h3 class='awr'>Global Cache Average Current Get Time</h3></p> 
prompt <table width="200" border="1">
prompt   <tr>
prompt     <td style="color:rgba(0,255,0,1)"><b>Average</b></td>
prompt      <td style="color:rgba(255,0,0,1)"><b>Maxval</b></td>
prompt   </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt        <div>
prompt         <canvas id="gccutime-area"></canvas>
prompt       </div>
prompt </div> 
prompt <a class="awr" href="#top">Back to Top</a>

prompt <a class="awr" name="14"></a>
prompt  <p><h3 class='awr'>Buffer Cache hit point</h3></p> 
prompt <table width="200" border="1">
prompt   <tr>
prompt     <td style="color:rgba(0,0,0,1)"><b>hit point</b></td>
prompt   </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt        <div>
prompt         <canvas id="buffhit-area"></canvas>
prompt       </div>
prompt </div>  
prompt <a class="awr" href="#top">Back to Top</a>

prompt <a class="awr" name="141"></a>
prompt  <p><h3 class='awr'>PGA Cache hit point</h3></p> 
prompt <table width="200" border="1">
prompt   <tr>
prompt     <td style="color:rgba(64,0,128,1)"><b>hit point</b></td>
prompt   </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt        <div>
prompt         <canvas id="pga-area"></canvas>
prompt       </div>
prompt </div>  
prompt <a class="awr" href="#top">Back to Top</a>

prompt <a class="awr" name="140"></a>
prompt  <p><h3 class='awr'>Library Hit Point</h3></p> 
prompt <table width="200" border="1">
prompt   <tr>
prompt     <td style="color:rgba(0,0,0,1)"><b>hit point</b></td>
prompt   </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt        <div>
prompt         <canvas id="library-area"></canvas>
prompt       </div>
prompt </div>  
prompt <a class="awr" href="#top">Back to Top</a>


prompt <a class="awr" name="161"></a>
prompt <p><h3 class='awr'>Latch hit point</h3></p>
prompt <table width="600" border="1">
prompt <tr>
prompt <td style="color:rgba(0,255,128,1)"><b>Latch hit point % </b></td>
prompt </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt <div>
prompt <canvas id="latch_hit-area"></canvas>
prompt </div>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
prompt 
prompt <a class="awr" name="16"></a>
prompt <p><h3 class='awr'>Latch:shared pool</h3></p>
prompt <table width="600" border="1">
prompt <tr>
prompt <td style="color:rgba(255,0,0,1)"><b>Latch:shared pool - MISSES RATE  N/10000 </b></td>
prompt </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt <div>
prompt <canvas id="latch_sp-area"></canvas>
prompt </div>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
prompt 
prompt <a class="awr" name="17"></a>
prompt <p><h3 class='awr'>Latch:row cache objects</h3></p>
prompt <table width="600" border="1">
prompt <tr>
prompt <td style="color:rgba(255,128,64,1)"><b>Latch:row cache objects - MISSES RATE  N/10000 </b></td>
prompt </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt <div>
prompt <canvas id="latch_rco-area"></canvas>
prompt </div>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
prompt 
prompt <a class="awr" name="18"></a>
prompt <p><h3 class='awr'>Latch:cache buffers chains</h3></p>
prompt <table width="600" border="1">
prompt <tr>
prompt <td style="color:rgba(0,128,0,1)"><b>Latch:cache buffers chains - MISSES RATE  N/10000 </b></td>
prompt </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt <div>
prompt <canvas id="latch_cbc-area"></canvas>
prompt </div>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
prompt 
prompt <a class="awr" name="18"></a>
prompt <p><h3 class='awr'>Latch:cache buffers lru chain</h3></p>
prompt <table width="600" border="1">
prompt <tr>
prompt <td style="color:rgba(0,0,255,1)"><b>Latch:cache buffers lru chain - MISSES RATE  N/10000 </b></td>
prompt </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt <div>
prompt <canvas id="latch_lru-area"></canvas>
prompt </div>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
prompt 
prompt <a class="awr" name="20"></a>
prompt <p><h3 class='awr'>Latch:gc element</h3></p>
prompt <table width="600" border="1">
prompt <tr>
prompt <td style="color:rgba(128,0,64,1)"><b>Latch:gc element - MISSES RATE  N/10000 </b></td>
prompt </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt <div>
prompt <canvas id="latch_gc-area"></canvas>
prompt </div>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
prompt 
prompt <a class="awr" name="21"></a>
prompt <p><h3 class='awr'>Latch:DML lock allocation</h3></p>
prompt <table width="600" border="1">
prompt <tr>
prompt <td style="color:rgba(64,0,128,1)"><b>Latch:DML lock allocation - MISSES RATE  N/10000 </b></td>
prompt </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt <div>
prompt <canvas id="latch_dml-area"></canvas>
prompt </div>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>

prompt 
prompt <a class="awr" name="211"></a>
prompt <p><h3 class='awr'>Parses  </h3></p>
prompt <table width="600" border="1">
prompt <tr>
prompt <td style="color:rgba(0,255,128,1)"><b>Parses Per Second (count) </b></td>
prompt </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt <div>
prompt <canvas id="p-area"></canvas>
prompt </div>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>

prompt 
prompt <a class="awr" name="212"></a>
prompt <p><h3 class='awr'>Hard Parse  </h3></p>
prompt <table width="600" border="1">
prompt <tr>
prompt <td style="color:rgba(0,0,160,1)"><b>Hard Parses Per Second (count) </b></td>
prompt </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt <div>
prompt <canvas id="hp-area"></canvas>
prompt </div>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>


prompt 
prompt <a class="awr" name="22"></a>
prompt <p><h3 class='awr'>Top3 File Average Read Time</h3></p>
prompt <table width="600" border="1">
prompt <tr>
prompt <td style="color:rgba(0,0,160,1)"><b>Top3 File Average Read Time MS </b></td>
prompt </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt <div>
prompt <canvas id="top3f-area"></canvas>
prompt </div>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>

prompt 
prompt <a class="awr" name="23"></a>
prompt <p><h3 class='awr'>Table fetch continued row</h3></p>
prompt <table width="600" border="1">
prompt <tr>
prompt <td style="color:rgba(128,64,0,1)"><b>Table fetch continued row / Second </b></td>
prompt </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt <div>
prompt <canvas id="tfetch-area"></canvas>
prompt </div>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>

prompt 
prompt <a class="awr" name="24"></a>
prompt <p><h3 class='awr'>Dirty buffers inspected</h3></p>
prompt <table width="600" border="1">
prompt <tr>
prompt <td style="color:rgba(0,64,0,1)"><b>Dirty buffers inspected / Second </b></td>
prompt </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div style="width:75%">
prompt <div>
prompt <canvas id="dirty-area"></canvas>
prompt </div>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>

prompt 
prompt <a class="awr" name="50"></a>
prompt <p><h3 class='awr'>Cell physical IO MB eligible for predicate offload</h3></p>
prompt <table width="600" border="1">
prompt <tr>
prompt <td style="color:rgba(255,0,0,1)"><b>Cell physical IO MB eligible for predicate offload / Second </b></td>
prompt </tr>
prompt </table>
prompt <a1 class="awr" href="#50">Comments:</a1>
prompt <div style="width:75%">
prompt <div>
prompt <canvas id="cellpredicate-area"></canvas>
prompt </div>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>

prompt 
prompt <a class="awr" name="51"></a>
prompt <p><h3 class='awr'>Cell physical IO MB saved by storage index</h3></p>
prompt <table width="600" border="1">
prompt <tr>
prompt <td style="color:rgba((255,0,0,1)"><b>Cell physical IO MB saved by storage index / Second </b></td>
prompt </tr>
prompt </table>
prompt <a1 class="awr" href="#51">Comments:</a1>
prompt <div style="width:75%">
prompt <div>
prompt <canvas id="storageidx-area"></canvas>
prompt </div>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>

prompt 
prompt <a class="awr" name="52"></a>
prompt <p><h3 class='awr'>Cell physical IO interconnect MB returned by smart scan</h3></p>
prompt <table width="600" border="1">
prompt <tr>
prompt <td style="color:rgba((255,0,0,1)"><b>Cell physical IO interconnect MB returned by smart scan / Second </b></td>
prompt </tr>
prompt </table>
prompt <a1 class="awr" href="#52">Comments:</a1>
prompt <div style="width:75%">
prompt <div>
prompt <canvas id="smart-area"></canvas>
prompt </div>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>

prompt 
prompt <a class="awr" name="53"></a>
prompt <p><h3 class='awr'>Cell IO uncompressed MB</h3></p>
prompt <table width="600" border="1">
prompt <tr>
prompt <td style="color:rgba((255,0,0,1)"><b>Cell IO uncompressed MB / Second </b></td>
prompt </tr>
prompt </table>
prompt <a1 class="awr" href="#53">Comments:</a1>
prompt <div style="width:75%">
prompt <div>
prompt <canvas id="uncom-area"></canvas>
prompt </div>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>

prompt <a class="awr" name="151"></a>
prompt <p><h3 class='awr'>Top5 Wait Event</h3></p>
prompt <table width="600" border="1">
prompt <tr>
prompt <td style="color:rgba(0,0,160,1)"><b>Top5 Wait Event Of Whole Period</b></td>
prompt </tr>
prompt </table>
prompt <a1 class="awr" href="#10">Comments:</a1>
prompt <div >
prompt <div>
prompt <canvas id="top5-area"  height="500" width="500"></canvas>
prompt </div>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>


prompt <a class="awr" name="15"></a>
prompt <p><h3 class='awr'>Top 5 Wait Event trends </h3></p>
prompt <div style="width:75%">
prompt <div>


declare
vevent varchar2(100);  
vtime number;
vavgtime number;
vpctwt number;
vwaits number;
vwaitclass varchar2(100);
vbid number ;
veid number ;
vinid number:=&inid;
startid number:=&bid;
endid number:=&eid;
vstarttime varchar2(200);
vendtime varchar2(200);
cursor c1 is
SELECT EVENT,
       WAITS,
       trunc(TIME,2),
       trunc(DECODE(WAITS,
              NULL,
              TO_NUMBER(NULL),
              0,
              TO_NUMBER(NULL),
              TIME / WAITS * 1000),2) AVGWT,
       trunc(PCTWTT,2) ,
       WAIT_CLASS
  FROM (SELECT EVENT, WAITS, TIME, PCTWTT, WAIT_CLASS
          FROM (SELECT E.EVENT_NAME EVENT,
                       E.TOTAL_WAITS_FG - NVL(B.TOTAL_WAITS_FG, 0) WAITS,
                       (E.TIME_WAITED_MICRO_FG - NVL(B.TIME_WAITED_MICRO_FG, 0)) /
                       1000000 TIME,
                       100 *
                       (E.TIME_WAITED_MICRO_FG - NVL(B.TIME_WAITED_MICRO_FG, 0)) /
                       ((SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL e
                          WHERE e.SNAP_ID = veid
                            AND e.INSTANCE_NUMBER = vinid
                            AND e.STAT_NAME = 'DB time') -
                       (SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL b
                          WHERE b.SNAP_ID = vbid
                            AND b.INSTANCE_NUMBER = vinid
                            AND b.STAT_NAME = 'DB time')) PCTWTT,
                       E.WAIT_CLASS WAIT_CLASS
                  FROM DBA_HIST_SYSTEM_EVENT B, DBA_HIST_SYSTEM_EVENT E
                 WHERE B.SNAP_ID(+) = vbid
                   AND E.SNAP_ID = veid
                   AND B.INSTANCE_NUMBER(+) = vinid
                   AND E.INSTANCE_NUMBER = vinid
                   AND B.EVENT_ID(+) = E.EVENT_ID
                   AND E.TOTAL_WAITS > NVL(B.TOTAL_WAITS, 0)
                   AND E.WAIT_CLASS != 'Idle'
                UNION ALL
                SELECT 'CPU time' EVENT,
                       TO_NUMBER(NULL) WAITS,
                       ((SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL e
                          WHERE e.SNAP_ID = veid
                            AND e.INSTANCE_NUMBER = vinid
                            AND e.STAT_NAME = 'DB CPU') -
                       (SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL b
                          WHERE b.SNAP_ID = vbid
                            AND b.INSTANCE_NUMBER = vinid
                            AND b.STAT_NAME = 'DB CPU')) / 1000000 TIME,
                       100 * ((SELECT sum(value)
                                 FROM DBA_HIST_SYS_TIME_MODEL e
                                WHERE e.SNAP_ID = veid
                                  AND e.INSTANCE_NUMBER = vinid
                                  AND e.STAT_NAME = 'DB CPU') -
                       (SELECT sum(value)
                                 FROM DBA_HIST_SYS_TIME_MODEL b
                                WHERE b.SNAP_ID = vbid
                                  AND b.INSTANCE_NUMBER = vinid
                                  AND b.STAT_NAME = 'DB CPU')) /
                       ((SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL e
                          WHERE e.SNAP_ID = veid
                            AND e.INSTANCE_NUMBER = vinid
                            AND e.STAT_NAME = 'DB time') -
                       (SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL b
                          WHERE b.SNAP_ID = vbid
                            AND b.INSTANCE_NUMBER = vinid
                            AND b.STAT_NAME = 'DB time')) PCTWTT,
                       NULL WAIT_CLASS
                  from dual
                 WHERE ((SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL e
                          WHERE e.SNAP_ID = veid
                            AND e.INSTANCE_NUMBER = vinid
                            AND e.STAT_NAME = 'DB CPU') -
                       (SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL b
                          WHERE b.SNAP_ID = vbid
                            AND b.INSTANCE_NUMBER = vinid
                            AND b.STAT_NAME = 'DB CPU')) > 0)
         ORDER BY TIME DESC, WAITS DESC)
 WHERE ROWNUM <= 5;
begin
  for i in startid..endid-1 loop
    vbid:=i;
    veid:=i+1;
     select to_char(a.end_interval_time,'yyyy-mm-dd hh24:mi') into vstarttime from dba_hist_snapshot a where snap_id=vbid and instance_number=&inid;
     select to_char(a.end_interval_time,'yyyy-mm-dd hh24:mi') into vendtime from dba_hist_snapshot a where snap_id=veid and instance_number=&inid;
     dbms_output.put_line('<table border="1" width="50%" ><tr><th class="awrbg" scope="col" colspan="6">'||vstarttime||' to '||vendtime);
     dbms_output.put_line('</th></tr><tr><th class="awrbg" scope="col">Event</th><th class="awrbg" scope="col">Waits</th>');
     dbms_output.put_line('<th class="awrbg" scope="col">Time(s)</th><th class="awrbg" scope="col">Avg wait (ms)</th><th class="awrbg" scope="col">% DB time</th><th class="awrbg" scope="col">Wait Class</th></tr>');

  open c1;
  loop
  fetch c1 into vevent,vwaits,vtime,vavgtime,vpctwt,vwaitclass;
  exit when c1%notfound;

   dbms_output.put_line( '<tr>' );
  dbms_output.put_line('<td scope="row" class=''awrc''>'||vevent||'</td>' );
  dbms_output.put_line('<td align="right" class=''awrc''>'||vwaits||'</td>' );
  dbms_output.put_line('<td align="right" class=''awrc''>'||vtime||'</td>' );
  dbms_output.put_line('<td align="right" class=''awrc''>'||vavgtime||'</td>' );
  dbms_output.put_line('<td align="right" class=''awrc''>'||vpctwt||'</td>' );
   dbms_output.put_line('<td class=''awrc''>'||vwaitclass||'</td>' );
  dbms_output.put_line('</tr>' );
  end loop;
  close c1;
   dbms_output.put_line('</table><p />');
  end loop;
end;
/

prompt </div>
prompt </div>
prompt <a class="awr" href="#top">Back to Top</a>
prompt <!-- Wen Jie Wang from Oracle ACS 2015/8/24-->
prompt        
prompt <script>
prompt   //var randomScalingFactor = function(){ return Math.round(Math.random()*300000)};
prompt   
prompt     var cpuChartData = {
prompt       labels : [
select listagg(snap_time,','||chr(10)) within GROUP (order by snap_id)          || chr(10) ||
'],' || chr(10) ||
'            datasets : [' || chr(10) ||
'        {' || chr(10) ||
'          label: "Database cpu dataset",' || chr(10) ||
'          fillColor : "rgba(0,255,128,0.7)",' || chr(10) ||
'          strokeColor : "rgba(0,255,128,1)",' || chr(10) ||
'          pointColor : "rgba(0,255,128,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : ['|| chr(10) 
  from (
select  snap_id,
       sum(case
             when e.metric_name = 'Background CPU Usage Per Sec' then
              e.pct
             else
              0
           end) backdb_cpu,
       sum(case
             when e.metric_name = 'Host CPU Utilization (%)' then
              e.pct
             else
              0
           end) server_cpu,
       sum(case
             when e.metric_name = 'CPU Usage Per Sec' then
              e.pct
             else
              0
           end) db_cpu, 
           case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id = e.snap_id
           and f.instance_number = &inid)
              end snap_time
  from (select a.snap_id,
               trunc(decode(a.METRIC_NAME,
                            'Host CPU Utilization (%)',
                            a.average,
                            'CPU Usage Per Sec',
                            a.average / 100 / (select value from v$parameter t where t.NAME = 'cpu_count' ) * 100, 
                            a.average / 100 / (select value from v$parameter t where t.NAME = 'cpu_count' ) * 100,
                            a.average),
                     2) pct,
               a.METRIC_NAME,
               a.METRIC_UNIT
          from dba_hist_sysmetric_summary a
         where A.snap_id >= &bid and a.snap_id <=&eid  
           and a.instance_number = &inid
           and a.METRIC_NAME in
               ('Host CPU Utilization (%)',
                'CPU Usage Per Sec',
                'Background CPU Usage Per Sec')
         order by 1, 3) e
 group by snap_id
 order by snap_id
 ) a1;
 
select  
 listagg(db_cpu,','||chr(10)) within GROUP (order by snap_id)         ||
 ']' || chr(10) ||
'        },' || chr(10) ||
'        {' || chr(10) ||
'          label: "Server cpu dataset",' || chr(10) ||
'          fillColor : "rgba(255,0,0,0.3)",' || chr(10) ||
'          strokeColor : "rgba(255,0,0,1)",' || chr(10) ||
'          pointColor : "rgba(255,0,0,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : ['|| chr(10) ||
  listagg(server_cpu,','||chr(10)) within GROUP (order by snap_id)     ||
  ']' || chr(10) ||
'        },' || chr(10) ||
'        {' || chr(10) ||
'          label: "Backup cpu dataset",' || chr(10) ||
'          fillColor : "rgba(30,144,255,0)",' || chr(10) ||
'          strokeColor : "rgba(151,187,205,1)",' || chr(10) ||
'          pointColor : "rgba(151,187,205,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(151,187,205,1)",' || chr(10) ||
'          data : ['|| chr(10) ||
  listagg(backdb_cpu,','||chr(10)) within GROUP (order by snap_id)     
  from (
select  snap_id,
       sum(case
             when e.metric_name = 'Background CPU Usage Per Sec' then
              e.pct
             else
              0
           end) backdb_cpu,
       sum(case
             when e.metric_name = 'Host CPU Utilization (%)' then
              e.pct
             else
              0
           end) server_cpu,
       sum(case
             when e.metric_name = 'CPU Usage Per Sec' then
              e.pct
             else
              0
           end) db_cpu, 
           case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id = e.snap_id
           and f.instance_number = &inid)
              end snap_time
  from (select a.snap_id,
               trunc(decode(a.METRIC_NAME,
                            'Host CPU Utilization (%)',
                            a.average,
                            'CPU Usage Per Sec',
                            a.average / 100 / (select value from v$parameter t where t.NAME = 'cpu_count' ) * 100, 
                            a.average / 100 / (select value from v$parameter t where t.NAME = 'cpu_count' ) * 100,
                            a.average),
                     2) pct,
               a.METRIC_NAME,
               a.METRIC_UNIT
          from dba_hist_sysmetric_summary a
         where A.snap_id >= &bid and a.snap_id <=&eid  
           and a.instance_number = &inid
           and a.METRIC_NAME in
               ('Host CPU Utilization (%)',
                'CPU Usage Per Sec',
                'Background CPU Usage Per Sec')
         order by 1, 3) e
 group by snap_id
 order by snap_id
 ) a1;
 
prompt ]
prompt         }
prompt       ]
prompt     }
prompt
prompt var timemodelChartData = { labels : [      
select 
 listagg(snap_time,','||chr(10)) within GROUP (order by snap_id) || chr(10) ||'],' || chr(10) ||
'    datasets : [' || chr(10) ||
'      {' || chr(10) ||
'fillColor : "rgba(255,0,0,0.2)",' || chr(10) ||
'          strokeColor : "rgba(255,0,0,1)",' || chr(10) ||
'          pointColor : "rgba(255,0,0,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",'|| chr(10) ||
'        data : ['|| chr(10) ||
listagg(db_time,','||chr(10)) within GROUP (order by snap_id) ||chr(10)||']' || chr(10) ||
'    },' || chr(10) ||
'    {' || chr(10) ||
'fillColor : "rgba(255,255,0,0.3)",' || chr(10) ||
'  strokeColor : "rgba(255,255,0,1)",' || chr(10) ||
'  pointColor : "rgba(255,255,0,1)",' || chr(10) ||
'  pointStrokeColor : "#fff",' || chr(10) ||
'  pointHighlightFill : "#fff",' || chr(10) ||
'  pointHighlightStroke : "rgba(255,255,0,1)",'|| chr(10) || 'data : ['||chr(10)
 from (
select  a1.snap_id,
trunc((a1.dbtime - lag(a1.dbtime, 1, a1.dbtime) over(order by a1.snap_id))/1000000) db_time,
trunc((a1.dbcpu - lag(a1.dbcpu, 1, a1.dbcpu) over(order by a1.snap_id))/1000000) db_cpu,
trunc((a1.sql_time - lag(a1.sql_time, 1, a1.sql_time) over(order by a1.snap_id))/1000000) sql_exec_time ,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id = a1.snap_id
           and f.instance_number = &inid)
              end snap_time
 from (
select a.snap_id,instance_number,
sum(case when a.stat_name='DB CPU' then  a.value else 0 end  )  dbcpu,
sum(case when a.stat_name='DB time' then  a.value else 0 end  )  dbtime,
sum(case when a.stat_name='hard parse elapsed time' then  a.value else 0 end  )  hardptime,
sum(case when a.stat_name='parse time elapsed' then  a.value else 0 end  )  ptime,
sum(case when a.stat_name='sql execute elapsed time' then  a.value else 0 end  )  sql_time,
(select b.value from DBA_HIST_SYSSTAT b where b.snap_id=a.snap_id and b.stat_name='execute count' and b.instance_number=&inid) exec_count
 from  dba_hist_sys_time_model a 
where a.stat_name in (   'DB time','DB CPU','parse time elapsed','hard parse elapsed time','sql execute elapsed time')
and A.snap_id >= &bid and A.snap_id <= &eid and a.instance_number=&inid 
group by a.snap_id,instance_number order by snap_id ) a1 ) a2 
where a2.db_time>0 and a2.db_cpu>0 and a2.sql_exec_time>0;

select
listagg(db_cpu,','||chr(10)) within GROUP (order by snap_id) ||chr(10)||']' || chr(10) ||
'    },' || chr(10) ||
'    {' || chr(10) ||
'fillColor : "rgba(69,139,116,0.3)",' || chr(10) ||
'  strokeColor : "rgba(69,139,116,1)",' || chr(10) ||
'  pointColor : "rgba(69,139,116,1)",' || chr(10) ||
'  pointStrokeColor : "#fff",' || chr(10) ||
'  pointHighlightFill : "#fff",' || chr(10) ||
'  pointHighlightStroke : "rgba(220,220,220,1)",'|| chr(10) ||
'      data : ['|| chr(10) ||
listagg(sql_exec_time,','||chr(10)) within GROUP (order by snap_id) ||chr(10)||'      ]' || chr(10) ||
'    }' || chr(10) ||
'  ]' || chr(10) ||
'}'
 from (
select  a1.snap_id,
trunc((a1.dbtime - lag(a1.dbtime, 1, a1.dbtime) over(order by a1.snap_id))/1000000) db_time,
trunc((a1.dbcpu - lag(a1.dbcpu, 1, a1.dbcpu) over(order by a1.snap_id))/1000000) db_cpu,
trunc((a1.sql_time - lag(a1.sql_time, 1, a1.sql_time) over(order by a1.snap_id))/1000000) sql_exec_time ,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id = a1.snap_id
           and f.instance_number = &inid)
              end snap_time
 from (
select a.snap_id,instance_number,
sum(case when a.stat_name='DB CPU' then  a.value else 0 end  )  dbcpu,
sum(case when a.stat_name='DB time' then  a.value else 0 end  )  dbtime,
sum(case when a.stat_name='hard parse elapsed time' then  a.value else 0 end  )  hardptime,
sum(case when a.stat_name='parse time elapsed' then  a.value else 0 end  )  ptime,
sum(case when a.stat_name='sql execute elapsed time' then  a.value else 0 end  )  sql_time,
(select b.value from DBA_HIST_SYSSTAT b where b.snap_id=a.snap_id and b.stat_name='execute count' and b.instance_number=&inid) exec_count
 from  dba_hist_sys_time_model a 
where a.stat_name in (   'DB time','DB CPU','parse time elapsed','hard parse elapsed time','sql execute elapsed time')
and A.snap_id >= &bid and A.snap_id <= &eid and a.instance_number=&inid 
group by a.snap_id,instance_number order by snap_id ) a1 ) a2 
where a2.db_time>0 and a2.db_cpu>0 and a2.sql_exec_time>0;

set serveroutput on size unlimited
declare
cursor cur1 is
select to_char(time,'yyyy-mm-dd hh24:mi') time,
       sum(case activity
             when 'CPU' then
              1
             else
              0
           end) CPU,
       sum(case activity
             when 'Concurrency' then
              1
             else
              0
           end) Concurrency,
       sum(case activity
             when 'System I/O' then
              1
             else
              0
           end) Systemio,
       sum(case activity
             when 'User I/O' then
              1
             else
              0
           end) userio,
       sum(case activity
             when 'Administrative' then
              1
             else
              0
           end) Administrative,
       sum(case activity
             when 'Configuration' then
              1
             else
              0
           end) Configuration,
       sum(case activity
             when 'Application' then
              1
             else
              0
           end) Application,
       sum(case activity
             when 'Network' then
              1
             else
              0
           end) Network,
       sum(case activity
             when 'Commit' then
              1
             else
              0
           end) Commit,
       sum(case activity
             when 'Scheduler' then
              1
             else
              0
           end) Scheduler,
       sum(case activity
             when 'Cluster' then
              1
             else
              0
           end) Cluster1,
       sum(case activity
             when 'Queueing' then
              1
             else
              0
           end) Queueing,
       sum(case activity
             when 'Other' then
              1
             else
              0
           end) Other
  from (select to_date(substr(to_char(sample_time, 'yyyymmdd hh24:mi'),1,13)||'0','yyyymmdd hh24:mi') time,
               nvl(wait_class, 'CPU') activity
          from  dba_hist_active_sess_history a
         where session_type = 'FOREGROUND' 
         and a.snap_id >=&bid and snap_id <=&eid  and a.instance_number=&inid
         )
 group by time
 order by time;
 r1 cur1%rowtype;
 TYPE Roster IS TABLE OF cur1%rowtype;
 r2 Roster;
 i number:=1;
 m number;
begin
  r2:=Roster();
  OPEN cur1;
loop
FETCH cur1 INTO r1;
exit when cur1%notfound;
r2.extend;
r2(i):=r1;
i:=i+1;
END LOOP;
CLOSE cur1;
---
m:=r2.count();
DBMS_OUTPUT.PUT_LINE('var ashdata = { labels : [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m   then
  if mod(i,3)=0 then
DBMS_OUTPUT.PUT_LINE('"'||r1.time||'",');
  else
    DBMS_OUTPUT.PUT_LINE('"'||'",');
    end if;
else
DBMS_OUTPUT.PUT_LINE('"'||r1.time||'"');
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE('],datasets : [{');
DBMS_OUTPUT.PUT_LINE('label: "",');
DBMS_OUTPUT.PUT_LINE('fillColor : "rgba(0,0,0,0)",');
DBMS_OUTPUT.PUT_LINE('strokeColor : "rgba(255,0,0,1)",');
DBMS_OUTPUT.PUT_LINE('pointColor : "rgba(255,0,0,1)",');
DBMS_OUTPUT.PUT_LINE('pointStrokeColor : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightFill : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightStroke : "rgba(220,220,220,1)",');
DBMS_OUTPUT.PUT_LINE('data : [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.CPU||',');
else
DBMS_OUTPUT.PUT_LINE(r1.CPU);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE(']},{');
DBMS_OUTPUT.PUT_LINE('label: "",');
DBMS_OUTPUT.PUT_LINE('fillColor : "rgba(255,0,0,0)",');
DBMS_OUTPUT.PUT_LINE('strokeColor : "rgba(255,0,128,1)",');
DBMS_OUTPUT.PUT_LINE('pointColor : "rgba(255,0,128,1)",');
DBMS_OUTPUT.PUT_LINE('pointStrokeColor : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightFill : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightStroke : "rgba(220,220,220,1)",');
DBMS_OUTPUT.PUT_LINE('data : [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.Concurrency||',');
else
DBMS_OUTPUT.PUT_LINE(r1.Concurrency);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE(']},{');
DBMS_OUTPUT.PUT_LINE('label: "",');
DBMS_OUTPUT.PUT_LINE('fillColor : "rgba(255,0,0,0)",');
DBMS_OUTPUT.PUT_LINE('strokeColor : "rgba(255,255,0,1)",');
DBMS_OUTPUT.PUT_LINE('pointColor : "rgba(255,255,0,1)",');
DBMS_OUTPUT.PUT_LINE('pointStrokeColor : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightFill : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightStroke : "rgba(220,220,220,1)",');
DBMS_OUTPUT.PUT_LINE('data : [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.Systemio||',');
else
DBMS_OUTPUT.PUT_LINE(r1.Systemio);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE(']},{');
DBMS_OUTPUT.PUT_LINE('label: "",');
DBMS_OUTPUT.PUT_LINE('fillColor : "rgba(255,0,0,0)",');
DBMS_OUTPUT.PUT_LINE('strokeColor : "rgba(0,0,255,1)",');
DBMS_OUTPUT.PUT_LINE('pointColor : "rgba(0,0,255,1)",');
DBMS_OUTPUT.PUT_LINE('pointStrokeColor : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightFill : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightStroke : "rgba(220,220,220,1)",');
DBMS_OUTPUT.PUT_LINE('data : [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.userio||',');
else
DBMS_OUTPUT.PUT_LINE(r1.userio);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE(']},{');
DBMS_OUTPUT.PUT_LINE('label: "",');
DBMS_OUTPUT.PUT_LINE('fillColor : "rgba(255,0,0,0)",');
DBMS_OUTPUT.PUT_LINE('strokeColor : "rgba(0,128,0,1)",');
DBMS_OUTPUT.PUT_LINE('pointColor : "rgba(0,128,0,1)",');
DBMS_OUTPUT.PUT_LINE('pointStrokeColor : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightFill : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightStroke : "rgba(220,220,220,1)",');
DBMS_OUTPUT.PUT_LINE('data : [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.Administrative||',');
else
DBMS_OUTPUT.PUT_LINE(r1.Administrative);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE(']},{');
DBMS_OUTPUT.PUT_LINE('label: "",');
DBMS_OUTPUT.PUT_LINE('fillColor : "rgba(255,0,0,0)",');
DBMS_OUTPUT.PUT_LINE('strokeColor : "rgba(128,128,0,1)",');
DBMS_OUTPUT.PUT_LINE('pointColor : "rgba(128,128,0,1)",');
DBMS_OUTPUT.PUT_LINE('pointStrokeColor : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightFill : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightStroke : "rgba(220,220,220,1)",');
DBMS_OUTPUT.PUT_LINE('data : [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.Configuration||',');
else
DBMS_OUTPUT.PUT_LINE(r1.Configuration);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE(']},{');
DBMS_OUTPUT.PUT_LINE('label: "",');
DBMS_OUTPUT.PUT_LINE('fillColor : "rgba(255,0,0,0)",');
DBMS_OUTPUT.PUT_LINE('strokeColor : "rgba(0,255,0,1)",');
DBMS_OUTPUT.PUT_LINE('pointColor : "rgba(0,255,0,1)",');
DBMS_OUTPUT.PUT_LINE('pointStrokeColor : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightFill : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightStroke : "rgba(220,220,220,1)",');
DBMS_OUTPUT.PUT_LINE('data : [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.Application||',');
else
DBMS_OUTPUT.PUT_LINE(r1.Application);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE(']},{');
DBMS_OUTPUT.PUT_LINE('label: "",');
DBMS_OUTPUT.PUT_LINE('fillColor : "rgba(255,0,0,0)",');
DBMS_OUTPUT.PUT_LINE('strokeColor : "rgba(0,0,0,1)",');
DBMS_OUTPUT.PUT_LINE('pointColor : "rgba(0,0,0,1)",');
DBMS_OUTPUT.PUT_LINE('pointStrokeColor : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightFill : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightStroke : "rgba(220,220,220,1)",');
DBMS_OUTPUT.PUT_LINE('data : [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.Network||',');
else
DBMS_OUTPUT.PUT_LINE(r1.Network);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE(']},{');
DBMS_OUTPUT.PUT_LINE('label: "",');
DBMS_OUTPUT.PUT_LINE('fillColor : "rgba(255,0,0,0)",');
DBMS_OUTPUT.PUT_LINE('strokeColor : "rgba(128,0,64,1)",');
DBMS_OUTPUT.PUT_LINE('pointColor : "rgba(128,0,64,1)",');
DBMS_OUTPUT.PUT_LINE('pointStrokeColor : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightFill : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightStroke : "rgba(220,220,220,1)",');
DBMS_OUTPUT.PUT_LINE('data : [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.Commit||',');
else
DBMS_OUTPUT.PUT_LINE(r1.Commit);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE(']},{');
DBMS_OUTPUT.PUT_LINE('label: "",');
DBMS_OUTPUT.PUT_LINE('fillColor : "rgba(255,0,0,0)",');
DBMS_OUTPUT.PUT_LINE('strokeColor : "rgba(192,192,192,1)",');
DBMS_OUTPUT.PUT_LINE('pointColor : "rgba(192,192,192,1)",');
DBMS_OUTPUT.PUT_LINE('pointStrokeColor : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightFill : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightStroke : "rgba(220,220,220,1)",');
DBMS_OUTPUT.PUT_LINE('data : [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.Scheduler||',');
else
DBMS_OUTPUT.PUT_LINE(r1.Scheduler);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE(']},{');
DBMS_OUTPUT.PUT_LINE('label: "",');
DBMS_OUTPUT.PUT_LINE('fillColor : "rgba(255,0,0,0)",');
DBMS_OUTPUT.PUT_LINE('strokeColor : "rgba(0,128,255,1)",');
DBMS_OUTPUT.PUT_LINE('pointColor : "rgba(0,128,255,1)",');
DBMS_OUTPUT.PUT_LINE('pointStrokeColor : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightFill : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightStroke : "rgba(220,220,220,1)",');
DBMS_OUTPUT.PUT_LINE('data : [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.Cluster1||',');
else
DBMS_OUTPUT.PUT_LINE(r1.Cluster1);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE(']},{');
DBMS_OUTPUT.PUT_LINE('label: "",');
DBMS_OUTPUT.PUT_LINE('fillColor : "rgba(255,0,0,0)",');
DBMS_OUTPUT.PUT_LINE('strokeColor : "rgba(128,64,0,1)",');
DBMS_OUTPUT.PUT_LINE('pointColor : "rgba(128,64,0,1)",');
DBMS_OUTPUT.PUT_LINE('pointStrokeColor : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightFill : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightStroke : "rgba(220,220,220,1)",');
DBMS_OUTPUT.PUT_LINE('data : [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.Queueing||',');
else
DBMS_OUTPUT.PUT_LINE(r1.Queueing);
end if;
END LOOP;
---
DBMS_OUTPUT.PUT_LINE(']},{');
DBMS_OUTPUT.PUT_LINE('label: "",');
DBMS_OUTPUT.PUT_LINE('fillColor : "rgba(255,0,0,0)",');
DBMS_OUTPUT.PUT_LINE('strokeColor : "rgba(255,128,0,1)",');
DBMS_OUTPUT.PUT_LINE('pointColor : "rgba(255,128,0,1)",');
DBMS_OUTPUT.PUT_LINE('pointStrokeColor : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightFill : "#fff",');
DBMS_OUTPUT.PUT_LINE('pointHighlightStroke : "rgba(220,220,220,1)",');
DBMS_OUTPUT.PUT_LINE('data : [');
FOR i IN r2.FIRST .. r2.LAST LOOP 
r1:=r2(i);
if i<m then
DBMS_OUTPUT.PUT_LINE(r1.Other||',');
else
DBMS_OUTPUT.PUT_LINE(r1.Other);
end if;
END LOOP;
DBMS_OUTPUT.PUT_LINE(']}]}');
---
end;
/

prompt var sqlcountdata = {
prompt    labels : [
select 
listagg(snap_time,','||chr(10)) within GROUP (order by snap_id)  ||'],' || chr(10) ||
'    datasets : [' || chr(10) ||
'      {' || chr(10) ||
'        fillColor : "rgba(0,0,205,0.5)",' || chr(10) ||
'        strokeColor : "rgba(0,0,205,0.8)",' || chr(10) ||
'        highlightFill: "rgba(220,220,220,0.75)",' || chr(10) ||
'        highlightStroke: "rgba(220,220,220,1)",' || chr(10) ||
'        data : ['||chr(10)
 from (
select a1.snap_id, a1.snap_time,
a1.exec_count - lag(a1.exec_count, 1, a1.exec_count) over(order by a1.snap_id) sql_exec_count
 from (
select a.snap_id,
sum(case when a.stat_name='sql execute elapsed time' then  a.value else 0 end  )  sql_time,
(select b.value from DBA_HIST_SYSSTAT b where b.snap_id=a.snap_id and b.stat_name='execute count' and b.instance_number=&inid) exec_count,
 case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id = a.snap_id
           and f.instance_number = &inid)
              end snap_time
 from  dba_hist_sys_time_model a 
where a.stat_name in (   'DB time','DB CPU','parse time elapsed','hard parse elapsed time','sql execute elapsed time')
and A.snap_id >= &bid and A.snap_id <= &eid and a.instance_number=&inid 
group by a.snap_id order by snap_id ) a1) where sql_exec_count > 0;

select 
listagg(trunc(sql_exec_count/(select trunc((sysdate+snap_interval-sysdate)*24*3600) from dba_hist_wr_control)  ),','||chr(10)) within GROUP (order by snap_id) 
 from (
select a1.snap_id, a1.snap_time,
a1.exec_count - lag(a1.exec_count, 1, a1.exec_count) over(order by a1.snap_id) sql_exec_count
 from (
select a.snap_id,
sum(case when a.stat_name='sql execute elapsed time' then  a.value else 0 end  )  sql_time,
(select b.value from DBA_HIST_SYSSTAT b where b.snap_id=a.snap_id and b.stat_name='execute count' and b.instance_number=&inid) exec_count,
 case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id = a.snap_id
           and f.instance_number = &inid)
              end snap_time
 from  dba_hist_sys_time_model a 
where a.stat_name in (   'DB time','DB CPU','parse time elapsed','hard parse elapsed time','sql execute elapsed time')
and A.snap_id >= &bid and A.snap_id <= &eid and a.instance_number=&inid 
group by a.snap_id order by snap_id ) a1) where sql_exec_count > 0;
prompt           ]
prompt         }
prompt       ]
prompt     }
select ' var sqltimedata = {' || chr(10) ||
'labels : ['|| chr(10) ||
listagg(snap_time,','||chr(10)) within GROUP (order by snap_id)|| chr(10) ||
'],' || chr(10) ||
'    datasets : [' || chr(10) ||
'      {' || chr(10) ||
'        fillColor : "rgba(50,205,50,1)",' || chr(10) ||
'        strokeColor : "rgba(50,205,50,1)",' || chr(10) ||
'        highlightFill: "rgba(220,220,220,0.75)",' || chr(10) ||
'        highlightStroke: "rgba(220,220,220,1)",' || chr(10) ||
'        data : ['|| chr(10) 
 from (
select a1.snap_id, a1.snap_time,
a1.exec_count - lag(a1.exec_count, 1, a1.exec_count) over(order by a1.snap_id) sql_exec_count,
TRUNC((a1.sql_time - lag(a1.sql_time, 1, a1.sql_time) over(order by a1.snap_id))/
DECODE((a1.exec_count - lag(a1.exec_count, 1, a1.exec_count) over(order by a1.snap_id)),0,1,
(a1.exec_count - lag(a1.exec_count, 1, a1.exec_count) over(order by a1.snap_id))),2) avg_sql_time
 from (
select a.snap_id,
sum(case when a.stat_name='sql execute elapsed time' then  a.value else 0 end  )  sql_time,
(select b.value from DBA_HIST_SYSSTAT b where b.snap_id=a.snap_id and b.stat_name='execute count' and b.instance_number=&inid) exec_count,
 case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id = a.snap_id
           and f.instance_number = &inid)
              end snap_time
 from  dba_hist_sys_time_model a 
where a.stat_name in (   'DB time','DB CPU','parse time elapsed','hard parse elapsed time','sql execute elapsed time')
and A.snap_id >= &bid and A.snap_id <= &eid and a.instance_number=&inid
group by a.snap_id order by snap_id ) a1) where sql_exec_count > 0;

select 
listagg(avg_sql_time,','||chr(10)) within GROUP (order by snap_id)|| chr(10) ||
 ']' || chr(10) ||
'      }' || chr(10) ||
'    ]' || chr(10) ||
'  }' 
 from (
select a1.snap_id, a1.snap_time,
a1.exec_count - lag(a1.exec_count, 1, a1.exec_count) over(order by a1.snap_id) sql_exec_count,
TRUNC((a1.sql_time - lag(a1.sql_time, 1, a1.sql_time) over(order by a1.snap_id))/
DECODE((a1.exec_count - lag(a1.exec_count, 1, a1.exec_count) over(order by a1.snap_id)),0,1,
(a1.exec_count - lag(a1.exec_count, 1, a1.exec_count) over(order by a1.snap_id))),2) avg_sql_time
 from (
select a.snap_id,
sum(case when a.stat_name='sql execute elapsed time' then  a.value else 0 end  )  sql_time,
(select b.value from DBA_HIST_SYSSTAT b where b.snap_id=a.snap_id and b.stat_name='execute count' and b.instance_number=&inid) exec_count,
 case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id = a.snap_id
           and f.instance_number = &inid)
              end snap_time
 from  dba_hist_sys_time_model a 
where a.stat_name in (   'DB time','DB CPU','parse time elapsed','hard parse elapsed time','sql execute elapsed time')
and A.snap_id >= &bid and A.snap_id <= &eid and a.instance_number=&inid
group by a.snap_id order by snap_id ) a1) where sql_exec_count > 0;

prompt   var logicreadData = {
prompt       labels : [
select
listagg(snap_time,','||chr(10)) within GROUP (order by snap_id) || chr(10)||
'],' || chr(10) ||
'            datasets : [' || chr(10) ||
'        {' || chr(10) ||
'          label: "Database cpu dataset",' || chr(10) ||
'          fillColor : "rgba(255,255,128,0)",' || chr(10) ||
'          strokeColor : "rgba(255,0,0,1)",' || chr(10) ||
'          pointColor : "rgba(255,0,0,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : ['
 from (
select a2.snap_id  , 
a2.csget - lag(a2.csget, 1, a2.csget) over(order by a2.snap_id) cg,
a2.pr - lag(a2.pr, 1, a2.pr) over(order by a2.snap_id) pr,
a2.slr - lag(a2.slr, 1, a2.slr) over(order by a2.snap_id) sl,
a2.pw - lag(a2.pw, 1, a2.pw) over(order by a2.snap_id) pw,
a2.uc - lag(a2.uc, 1, a2.uc) over(order by a2.snap_id) uc,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) end snap_time
 from (
select a1.snap_id,
sum(case when a1.stat_name='consistent gets' then  a1.value else 0 end  )  csget ,
sum(case when a1.stat_name='physical read bytes' then  a1.value else 0 end  )  pr ,
sum(case when a1.stat_name='session logical reads' then  a1.value else 0 end  )  slr ,
sum(case when a1.stat_name='physical write bytes' then  a1.value else 0 end  )  pw ,
sum(case when a1.stat_name='user commits' then  a1.value else 0 end  )  uc 
from
(select a.snap_id,a.stat_name,a.value from dba_hist_sysstat a where    (a.stat_name = 'consistent gets'
or a.stat_name like '%physical read bytes%' or a.stat_name = 'session logical reads' or a.stat_name='execute count' 
or a.stat_name='physical write bytes' or a.stat_name='user commits') 
and snap_id >=&bid and snap_id<=&eid and a.instance_number=&inid
 order by a.snap_id,a.stat_name) a1
group by a1.snap_id order by a1.snap_id) a2 ) a3
where a3.sl >0;

select
listagg(trunc(cg/(select trunc((sysdate+snap_interval-sysdate)*24*3600) from dba_hist_wr_control)  ),','||chr(10)) within GROUP (order by snap_id) 
|| chr(10) ||']' || chr(10) ||
'        },' || chr(10) ||
'        {' || chr(10) ||
'          label: "Server cpu dataset",' || chr(10) ||
'          fillColor : "rgba(69,139,116,0)",' || chr(10) ||
'          strokeColor : "rgba(255,255,0,1)",' || chr(10) ||
'          pointColor : "rgba(255,255,0,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : ['|| chr(10) 
 from (
select a2.snap_id  , 
a2.csget - lag(a2.csget, 1, a2.csget) over(order by a2.snap_id) cg,
a2.pr - lag(a2.pr, 1, a2.pr) over(order by a2.snap_id) pr,
a2.slr - lag(a2.slr, 1, a2.slr) over(order by a2.snap_id) sl,
a2.pw - lag(a2.pw, 1, a2.pw) over(order by a2.snap_id) pw,
a2.uc - lag(a2.uc, 1, a2.uc) over(order by a2.snap_id) uc,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number =&inid) end snap_time
 from (
select a1.snap_id,
sum(case when a1.stat_name='consistent gets' then  a1.value else 0 end  )  csget ,
sum(case when a1.stat_name='physical read bytes' then  a1.value else 0 end  )  pr ,
sum(case when a1.stat_name='session logical reads' then  a1.value else 0 end  )  slr ,
sum(case when a1.stat_name='physical write bytes' then  a1.value else 0 end  )  pw ,
sum(case when a1.stat_name='user commits' then  a1.value else 0 end  )  uc 
from
(select a.snap_id,a.stat_name,a.value from dba_hist_sysstat a where    (a.stat_name = 'consistent gets'
or a.stat_name like '%physical read bytes%' or a.stat_name = 'session logical reads' or a.stat_name='execute count' 
or a.stat_name='physical write bytes' or a.stat_name='user commits') 
and snap_id >=&bid and snap_id<=&eid and a.instance_number=&inid
 order by a.snap_id,a.stat_name) a1
group by a1.snap_id order by a1.snap_id) a2 ) a3
where a3.sl >0;

select
listagg(trunc(sl/(select trunc((sysdate+snap_interval-sysdate)*24*3600) from dba_hist_wr_control)  ),','||chr(10)) within GROUP (order by snap_id) || chr(10) ||
']' || chr(10) ||
'        }' || chr(10) ||
'' || chr(10) ||
'      ]' || chr(10) ||
'    }'
 from (
select a2.snap_id  , 
a2.csget - lag(a2.csget, 1, a2.csget) over(order by a2.snap_id) cg,
a2.pr - lag(a2.pr, 1, a2.pr) over(order by a2.snap_id) pr,
a2.slr - lag(a2.slr, 1, a2.slr) over(order by a2.snap_id) sl,
a2.pw - lag(a2.pw, 1, a2.pw) over(order by a2.snap_id) pw,
a2.uc - lag(a2.uc, 1, a2.uc) over(order by a2.snap_id) uc,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number =&inid) end snap_time
 from (
select a1.snap_id,
sum(case when a1.stat_name='consistent gets' then  a1.value else 0 end  )  csget ,
sum(case when a1.stat_name='physical read bytes' then  a1.value else 0 end  )  pr ,
sum(case when a1.stat_name='session logical reads' then  a1.value else 0 end  )  slr ,
sum(case when a1.stat_name='physical write bytes' then  a1.value else 0 end  )  pw ,
sum(case when a1.stat_name='user commits' then  a1.value else 0 end  )  uc 
from
(select a.snap_id,a.stat_name,a.value from dba_hist_sysstat a where    (a.stat_name = 'consistent gets'
or a.stat_name like '%physical read bytes%' or a.stat_name = 'session logical reads' or a.stat_name='execute count' 
or a.stat_name='physical write bytes' or a.stat_name='user commits') 
and snap_id >=&bid and snap_id<=&eid and a.instance_number=&inid
 order by a.snap_id,a.stat_name) a1
group by a1.snap_id order by a1.snap_id) a2 ) a3
where a3.sl >0;


select 'var physicalData = {' || chr(10) ||
'    labels : [' || chr(10) ||
listagg(snap_time,','||chr(10)) within GROUP (order by snap_id) || chr(10) ||
'],' || chr(10) ||
'            datasets : [' || chr(10) ||
'        {' || chr(10) ||
'          label: "Database cpu dataset",' || chr(10) ||
'          fillColor : "rgba(0,128,255,0)",' || chr(10) ||
'          strokeColor : "rgba(0,128,255,1)",' || chr(10) ||
'          pointColor : "rgba(0,128,255,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : [' || chr(10) 
 from (
select a2.snap_id  , 
a2.csget - lag(a2.csget, 1, a2.csget) over(order by a2.snap_id) cg,
a2.pr - lag(a2.pr, 1, a2.pr) over(order by a2.snap_id) pr,
a2.slr - lag(a2.slr, 1, a2.slr) over(order by a2.snap_id) sl,
a2.pw - lag(a2.pw, 1, a2.pw) over(order by a2.snap_id) pw,
a2.uc - lag(a2.uc, 1, a2.uc) over(order by a2.snap_id) uc,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) end snap_time
 from (
select a1.snap_id,
sum(case when a1.stat_name='consistent gets' then  a1.value else 0 end  )  csget ,
sum(case when a1.stat_name='physical read bytes' then  a1.value else 0 end  )  pr ,
sum(case when a1.stat_name='session logical reads' then  a1.value else 0 end  )  slr ,
sum(case when a1.stat_name='physical write bytes' then  a1.value else 0 end  )  pw ,
sum(case when a1.stat_name='user commits' then  a1.value else 0 end  )  uc 
from
(select a.snap_id,a.stat_name,a.value from dba_hist_sysstat a where    (a.stat_name = 'consistent gets'
or a.stat_name like '%physical read bytes%' or a.stat_name = 'session logical reads' or a.stat_name='execute count' 
or a.stat_name='physical write bytes' or a.stat_name='user commits') 
and snap_id >=&bid and snap_id<&eid and a.instance_number=&inid
 order by a.snap_id,a.stat_name) a1
group by a1.snap_id order by a1.snap_id) a2 ) a3
where a3.sl >0;

select
listagg(trunc(pr/(select trunc((sysdate+snap_interval-sysdate)*24*3600) from dba_hist_wr_control)  ),','||chr(10)) within GROUP (order by snap_id) || chr(10) ||
']' || chr(10) ||
'        },' || chr(10) ||
'        {' || chr(10) ||
'          label: "Physical write",' || chr(10) ||
'          fillColor : "rgba(0,255,64,0)",' || chr(10) ||
'          strokeColor : "rgba(0,255,64,1)",' || chr(10) ||
'          pointColor : "rgba(0,255,64,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : [' || chr(10) ||
listagg(trunc(pw/(select trunc((sysdate+snap_interval-sysdate)*24*3600) from dba_hist_wr_control)  ),','||chr(10)) within GROUP (order by snap_id)  || chr(10) ||
']' || chr(10) ||
'        }' || chr(10) ||
'' || chr(10) ||
'      ]' || chr(10) ||
'    }' || chr(10)
 from (
select a2.snap_id  , 
a2.csget - lag(a2.csget, 1, a2.csget) over(order by a2.snap_id) cg,
a2.pr - lag(a2.pr, 1, a2.pr) over(order by a2.snap_id) pr,
a2.slr - lag(a2.slr, 1, a2.slr) over(order by a2.snap_id) sl,
a2.pw - lag(a2.pw, 1, a2.pw) over(order by a2.snap_id) pw,
a2.uc - lag(a2.uc, 1, a2.uc) over(order by a2.snap_id) uc,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) end snap_time
 from (
select a1.snap_id,
sum(case when a1.stat_name='consistent gets' then  a1.value else 0 end  )  csget ,
trunc(sum(case when a1.stat_name='physical read bytes' then  a1.value else 0 end  )/1024/1024)  pr ,
sum(case when a1.stat_name='session logical reads' then  a1.value else 0 end  )  slr ,
trunc(sum(case when a1.stat_name='physical write bytes' then  a1.value else 0 end  )/1024/1024)  pw ,
sum(case when a1.stat_name='user commits' then  a1.value else 0 end  )  uc 
from
(select a.snap_id,a.stat_name,a.value from dba_hist_sysstat a where    (a.stat_name = 'consistent gets'
or a.stat_name like '%physical read bytes%' or a.stat_name = 'session logical reads' or a.stat_name='execute count' 
or a.stat_name='physical write bytes' or a.stat_name='user commits') 
and snap_id >=&bid and snap_id<=&eid and a.instance_number=&inid
 order by a.snap_id,a.stat_name) a1
group by a1.snap_id order by a1.snap_id) a2 ) a3
where a3.sl >0;
select 
'var usercommitdata = {' || chr(10) ||
'    labels : ['|| chr(10) ||
listagg(snap_time,','||chr(10)) within GROUP (order by snap_id) || chr(10)||
'],' || chr(10) ||
'    datasets : [' || chr(10) ||
'      {' || chr(10) ||
'        fillColor : "rgba(255,0,0,0.5)",' || chr(10) ||
'        strokeColor : "rgba(255,0,0,0.8)",' || chr(10) ||
'        highlightFill: "rgba(220,220,220,0.75)",' || chr(10) ||
'        highlightStroke: "rgba(220,220,220,1)",' || chr(10) ||
'        data : ['|| chr(10) ||
listagg(trunc(uc/(select trunc((sysdate+snap_interval-sysdate)*24*3600) from dba_hist_wr_control)  ),','||chr(10)) within GROUP (order by snap_id)  || chr(10) ||
'      ]' || chr(10) ||
'    }' || chr(10) ||
'  ]' || chr(10) ||
'}' || chr(10)
 from (
select a2.snap_id  , 
a2.csget - lag(a2.csget, 1, a2.csget) over(order by a2.snap_id) cg,
a2.pr - lag(a2.pr, 1, a2.pr) over(order by a2.snap_id) pr,
a2.slr - lag(a2.slr, 1, a2.slr) over(order by a2.snap_id) sl,
a2.pw - lag(a2.pw, 1, a2.pw) over(order by a2.snap_id) pw,
a2.uc - lag(a2.uc, 1, a2.uc) over(order by a2.snap_id) uc,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) end snap_time
 from (
select a1.snap_id,
sum(case when a1.stat_name='consistent gets' then  a1.value else 0 end  )  csget ,
sum(case when a1.stat_name='physical read bytes' then  a1.value else 0 end  )  pr ,
sum(case when a1.stat_name='session logical reads' then  a1.value else 0 end  )  slr ,
sum(case when a1.stat_name='physical write bytes' then  a1.value else 0 end  )  pw ,
sum(case when a1.stat_name='user commits' then  a1.value else 0 end  )  uc 
from
(select a.snap_id,a.stat_name,a.value from dba_hist_sysstat a where    (a.stat_name = 'consistent gets'
or a.stat_name like '%physical read bytes%' or a.stat_name = 'session logical reads' or a.stat_name='execute count' 
or a.stat_name='physical write bytes' or a.stat_name='user commits') 
and snap_id >=&bid and snap_id<=&eid and a.instance_number=&inid
 order by a.snap_id,a.stat_name) a1
group by a1.snap_id order by a1.snap_id) a2 ) a3
where a3.uc >0;
select '  var connectData = {' || chr(10) ||
'      labels : ['  || chr(10) ||
listagg(snap_time,','||chr(10)) within GROUP (order by snap_id)  || chr(10)
from (
select pr,se,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a1.snap_id
           and f.instance_number = &inid) end snap_time,snap_id
 from 
(
select snap_id,
sum(case when a.resource_name = 'processes' then  a.current_utilization else 0 end  )  pr ,
       sum(case when a.resource_name='sessions' then  a.current_utilization else 0 end  )  se     
  from dba_hist_resource_limit a
 where a.snap_id >=&bid and a.snap_id<=&eid and a.instance_number=&inid
   and (a.resource_name='sessions' or a.resource_name = 'processes' ) group by snap_id  order by snap_id )a1)a2;
select '],' || chr(10) ||
'            datasets : [' || chr(10) ||
'        {' || chr(10) ||
'          label: "Database cpu dataset",' || chr(10) ||
'          fillColor : "rgba(0,128,255,0)",' || chr(10) ||
'          strokeColor : "rgba(255,128,0,1)",' || chr(10) ||
'          pointColor : "rgba(255,128,0,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : [' || chr(10) ||
listagg(pr,','||chr(10)) within GROUP (order by snap_id) || chr(10) ||']' || chr(10) ||
'        },' || chr(10) ||
'        {' || chr(10) ||
'          label: "Server cpu dataset",' || chr(10) ||
'          fillColor : "rgba(0,255,64,0)",' || chr(10) ||
'          strokeColor : "rgba(128,0,0,1)",' || chr(10) ||
'          pointColor : "rgba(128,0,0,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : ['|| chr(10) ||
listagg(se,','||chr(10)) within GROUP (order by snap_id)  || chr(10) ||
']' || chr(10) ||
'        }' || chr(10) ||
'' || chr(10) ||
'      ]' || chr(10) ||
'    }' || chr(10)
from (
select pr,se,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a1.snap_id
           and f.instance_number = &inid) end snap_time,snap_id
 from 
(
select snap_id,
sum(case when a.resource_name = 'processes' then  a.current_utilization else 0 end  )  pr ,
       sum(case when a.resource_name='sessions' then  a.current_utilization else 0 end  )  se     
  from dba_hist_resource_limit a
 where a.snap_id >=&bid and a.snap_id<=&eid and a.instance_number=&inid
   and (a.resource_name='sessions' or a.resource_name = 'processes' ) group by snap_id  order by snap_id )a1)a2;
   
select 'var archivelogdata = {' || chr(10) ||
'    labels : [' || chr(10) ||
listagg(snap_time,','||chr(10)) within GROUP (order by snap_time2)   || chr(10) ||
'],' || chr(10) ||
'    datasets : [' || chr(10) ||
'      {' || chr(10) ||
'        fillColor : "rgba(128,0,255,1)",' || chr(10) ||
'        strokeColor : "rgba(128,0,255,1)",' || chr(10) ||
'        highlightFill: "rgba(128,0,255,1)",' || chr(10) ||
'        highlightStroke: "rgba(220,220,220,1)",' || chr(10) ||
'        data : [' || chr(10) ||
listagg(sz,','||chr(10)) within GROUP (order by snap_time2)  || chr(10) ||
'      ]' || chr(10) ||
'    }' || chr(10) ||
'  ]' || chr(10) ||
'}' || chr(10) 
  from (
select case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_time),2)=0 then
             '""' else 
             '"'||snap_time||'"' end snap_time ,
              sz - lag( sz, 1,  sz) over(order by  snap_id)    sz,
                snap_time snap_time2
             from(
select (select  to_char(b.begin_interval_time, 'yyyy-mm-dd hh24') from dba_hist_snapshot b where a.snap_id=b.snap_id and b.instance_number=a.instance_number) snap_time,
trunc(a.value/1024/1024) sz,snap_id from dba_hist_sysstat a where a.stat_name = 'redo size' 
and a.snap_id>=&bid and a.snap_id<=&eid and a.instance_number=&inid
order by a.snap_id ) a1  )a2 where sz >=0;

select  '  var gcblockData = {' || chr(10) ||
'      labels : [' || chr(10) ||
listagg(snap_time,','||chr(10)) within GROUP (order by snap_id)  || chr(10) ||
'],' || chr(10) ||
'            datasets : [' || chr(10) ||
'        {' || chr(10) ||
'          label: "Database cpu dataset",' || chr(10) ||
'          fillColor : "rgba(0,128,255,1)",' || chr(10) ||
'          strokeColor : "rgba(0,0,255,1)",' || chr(10) ||
'          pointColor : "rgba(0,0,255,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : [' || chr(10) ||
listagg(cr,','||chr(10)) within GROUP (order by snap_id)  || chr(10) ||
']' || chr(10) ||
'        }' || chr(10) ||
'' || chr(10) ||
'      ]' || chr(10) ||
'    }'  || chr(10)
 from (
select a2.snap_id  , 
trunc((a2.cr - lag(a2.cr, 1, a2.cr) over(order by a2.snap_id))/&_iv)  cr,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) end snap_time
 from (
select a1.snap_id,
sum(case when a1.stat_name  = 'gc cr blocks received' 
or a1.stat_name='gc current blocks received' or a1.stat_name  = 'gc cr blocks served' 
or a1.stat_name='gc current blocks served'  then  a1.value else 0 end  )*(select value/1024 from v$parameter where name='db_block_size')  cr 
from
(select a.snap_id,a.stat_name,a.value from dba_hist_sysstat a where    ( a.stat_name  = 'gc cr blocks received' 
or a.stat_name='gc current blocks received' or a.stat_name  = 'gc cr blocks served' 
or a.stat_name='gc current blocks served'   
) 
and snap_id >=&bid and snap_id<=&eid and a.instance_number=&inid
 order by a.snap_id,a.stat_name) a1
group by a1.snap_id order by a1.snap_id) a2 ) a3;

select  'var gcmessageData = {' || chr(10) ||
'    labels : ['|| chr(10) ||
listagg(snap_time,','||chr(10)) within GROUP (order by snap_id)  || chr(10) ||
'],' || chr(10) ||
'            datasets : [' || chr(10) ||
'        {' || chr(10) ||
'          label: "Database cpu dataset",' || chr(10) ||
'          fillColor : "rgba(0,128,255,0)",' || chr(10) ||
'          strokeColor : "rgba(0,0,255,1)",' || chr(10) ||
'          pointColor : "rgba(0,0,255,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : [' || chr(10) 
 from (
select a2.snap_id  , 
trunc((a2.gm - lag(a2.gm, 1, a2.gm) over(order by a2.snap_id))/&_iv)   gm ,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) end snap_time
 from (
select a1.snap_id,
sum(case when a1.stat_name  = 'ges messages sent' 
or a1.stat_name='gcs messages sent'  then  a1.value else 0 end  )  gm 
from
(select a.snap_id,a.stat_name,a.value from dba_hist_sysstat a where    (a.stat_name = 'ges messages sent' 
or a.stat_name = 'gcs messages sent') 
and snap_id >=&bid and snap_id<=&eid and a.instance_number=&inid
 order by a.snap_id,a.stat_name) a1
group by a1.snap_id order by a1.snap_id) a2 ) a3;

select 
listagg(gm,','||chr(10)) within GROUP (order by snap_id)  || chr(10) ||
']' || chr(10) ||
'        }' || chr(10) ||
'' || chr(10) ||
'      ]' || chr(10) ||
'    }' || chr(10) 
 from (
select a2.snap_id  , 
trunc((a2.gm - lag(a2.gm, 1, a2.gm) over(order by a2.snap_id))/&_iv)   gm ,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) end snap_time
 from (
select a1.snap_id,
sum(case when a1.stat_name  = 'ges messages sent' 
or a1.stat_name='gcs messages sent'  then  a1.value else 0 end  )  gm 
from
(select a.snap_id,a.stat_name,a.value from dba_hist_sysstat a where    (a.stat_name = 'ges messages sent' 
or a.stat_name = 'gcs messages sent') 
and snap_id >=&bid and snap_id<=&eid and a.instance_number=&inid
 order by a.snap_id,a.stat_name) a1
group by a1.snap_id order by a1.snap_id) a2 ) a3;

select '  var gccrtimeData = {' || chr(10) ||
'      labels : ['  || chr(10) ||
listagg(snap_time,','||chr(10)) within GROUP (order by snap_id) 
  || chr(10) ||
'],' || chr(10) ||
'            datasets : [' || chr(10) ||
'        {' || chr(10) ||
'          label: "Database cpu dataset",' || chr(10) ||
'          fillColor : "rgba(0,128,255,0)",' || chr(10) ||
'          strokeColor : "rgba(0,255,0,1)",' || chr(10) ||
'          pointColor : "rgba(0,255,0,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : [' 
from (
select a2.average,a2.maxval,a2.snap_id,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else '"'||to_char(begin_time,'yyyy-mm-dd hh24:mi')||'"'
              end snap_time from(
select a.begin_time,a.snap_id,
       a.average   average,
       a.maxval   maxval
  from dba_hist_sysmetric_summary a
 where a.metric_name like '%Global Cache Average CR Get Time%'
   and a.instance_number = &inid
   and a.snap_id >= &bid and a.snap_id <=&eid 
 order by a.snap_id   )a2)a3;
 
select 
listagg(average,','||chr(10)) within GROUP (order by snap_id) || chr(10) ||
']' || chr(10) ||
'        },' || chr(10) ||
'        {' || chr(10) ||
'          label: "Server cpu dataset",' || chr(10) ||
'          fillColor : "rgba(0,255,64,0)",' || chr(10) ||
'          strokeColor : "rgba(255,0,0,1)",' || chr(10) ||
'          pointColor : "rgba(255,0,0,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : ['|| chr(10) 
from (
select trunc(a2.average,5) average,a2.maxval,a2.snap_id,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else '"'||to_char(begin_time,'yyyy-mm-dd hh24:mi')||'"'
              end snap_time from(
select a.begin_time,a.snap_id,
       a.average   average,
       a.maxval  maxval
  from dba_hist_sysmetric_summary a
 where a.metric_name like '%Global Cache Average CR Get Time%'
   and a.instance_number = &inid
   and a.snap_id >= &bid and a.snap_id <=&eid
 order by a.snap_id   )a2)a3;
 
select 
listagg(maxval,','||chr(10)) within GROUP (order by snap_id)   || chr(10) ||
']' || chr(10) ||
'        }' || chr(10) ||
'' || chr(10) ||
'      ]' || chr(10) ||
'    }'|| chr(10)
from (
select a2.average,trunc(a2.maxval,5) maxval,a2.snap_id,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else '"'||to_char(begin_time,'yyyy-mm-dd hh24:mi')||'"'
              end snap_time from(
select a.begin_time,a.snap_id,
       a.average   average,
       a.maxval  maxval
  from dba_hist_sysmetric_summary a
 where a.metric_name like '%Global Cache Average CR Get Time%'
   and a.instance_number = &inid
   and a.snap_id >= &bid and a.snap_id <=&eid
 order by a.snap_id   )a2)a3;

select '  var gccutimeData = {' || chr(10) ||
'      labels : ['  || chr(10) ||
listagg(snap_time,','||chr(10)) within GROUP (order by snap_id) 
  || chr(10) ||
'],' || chr(10) ||
'            datasets : [' || chr(10) ||
'        {' || chr(10) ||
'          label: "Database cpu dataset",' || chr(10) ||
'          fillColor : "rgba(0,128,255,0)",' || chr(10) ||
'          strokeColor : "rgba(0,255,0,1)",' || chr(10) ||
'          pointColor : "rgba(0,255,0,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : [' 
from (
select a2.average,a2.maxval,a2.snap_id,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else '"'||to_char(begin_time,'yyyy-mm-dd hh24:mi')||'"'
              end snap_time from(
select a.begin_time,a.snap_id,
       a.average   average,
       a.maxval  maxval
  from dba_hist_sysmetric_summary a
 where a.metric_name like '%Global Cache Average Current Get Time%'
   and a.instance_number = &inid
   and a.snap_id >= &bid and a.snap_id <=&eid 
 order by a.snap_id   )a2)a3;
 
select 
listagg(average,','||chr(10)) within GROUP (order by snap_id) || chr(10) ||
']' || chr(10) ||
'        },' || chr(10) ||
'        {' || chr(10) ||
'          label: "Server cpu dataset",' || chr(10) ||
'          fillColor : "rgba(0,255,64,0)",' || chr(10) ||
'          strokeColor : "rgba(255,0,0,1)",' || chr(10) ||
'          pointColor : "rgba(255,0,0,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : ['|| chr(10)
from (
select trunc(a2.average,5) average,a2.maxval,a2.snap_id,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else '"'||to_char(begin_time,'yyyy-mm-dd hh24:mi')||'"'
              end snap_time from(
select a.begin_time,a.snap_id,
       a.average   average,
       a.maxval   maxval
  from dba_hist_sysmetric_summary a
 where a.metric_name like '%Global Cache Average Current Get Time%'
   and a.instance_number = &inid
   and a.snap_id >= &bid and a.snap_id <=&eid
 order by a.snap_id   )a2)a3;
 
 select 
listagg(maxval,','||chr(10)) within GROUP (order by snap_id)   || chr(10) ||
']' || chr(10) ||
'        }' || chr(10) ||
'' || chr(10) ||
'      ]' || chr(10) ||
'    }'|| chr(10)
from (
select a2.average,trunc(a2.maxval,5) maxval,a2.snap_id,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else '"'||to_char(begin_time,'yyyy-mm-dd hh24:mi')||'"'
              end snap_time from(
select a.begin_time,a.snap_id,
       a.average   average,
       a.maxval   maxval
  from dba_hist_sysmetric_summary a
 where a.metric_name like '%Global Cache Average Current Get Time%'
   and a.instance_number = &inid
   and a.snap_id >= &bid and a.snap_id <=&eid
 order by a.snap_id   )a2)a3;
 
select 'var buffhitData = {' || chr(10) ||
'      labels : ['|| chr(10) ||
 listagg(snap_time,','||chr(10)) within GROUP (order by snap_id)  || chr(10) ||
 '],' || chr(10) ||
'            datasets : [' || chr(10) ||
'        {' || chr(10) ||
'          label: "Hit point",' || chr(10) ||
'          fillColor : "rgba(0,128,255,0.2)",' || chr(10) ||
'          strokeColor : "rgba(0,0,0,1)",' || chr(10) ||
'          pointColor : "rgba(0,0,0,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : ['  || chr(10) 
from (
select 
case when count(1) over() >&maxx and  mod(row_number() over(  order by a1.snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id = a1.snap_id
           and f.instance_number = &inid) end snap_time,
            a1.bh,a1.snap_id
 from (
select trunc((1-physical_reads/(db_block_gets+consistent_gets))*100) bh, a.snap_id
 from dba_hist_buffer_pool_stat a
 where a.snap_id>=&bid and a.snap_id<=&eid and a.instance_number=&inid
 and a.block_size=(select value from v$parameter where name = 'db_block_size') and (db_block_gets >0 or consistent_gets>0)
 ) a1 )a3;
 
select 
 listagg(bh,','||chr(10)) within GROUP (order by snap_id)  || chr(10)  ||
 ']' || chr(10) ||
'        }' || chr(10) ||
'' || chr(10) ||
'      ]' || chr(10) ||
'    }'  || chr(10)  
from (
select 
case when count(1) over() >&maxx and  mod(row_number() over(  order by a1.snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id = a1.snap_id
           and f.instance_number = &inid) end snap_time,
            a1.bh,a1.snap_id
 from (
select snap_id,trunc((1-physical_reads/(db_block_gets+consistent_gets))*100) bh from (
select --trunc((1-physical_reads/(db_block_gets+consistent_gets))*100) bh, 
a.physical_reads - lag(a.physical_reads, 1, a.physical_reads) over( order by a.snap_id) physical_reads,
a.db_block_gets - lag(a.db_block_gets, 1, a.db_block_gets) over( order by a.snap_id) db_block_gets,
a.consistent_gets - lag(a.consistent_gets, 1, a.consistent_gets) over( order by a.snap_id) consistent_gets,
a.snap_id
 from dba_hist_buffer_pool_stat a
 where a.snap_id>=&bid and a.snap_id<=&eid and a.instance_number=&inid
 and a.block_size=(select value from v$parameter where name = 'db_block_size')  and (db_block_gets >0 or consistent_gets>0)
 order by a.snap_id ) b where b.consistent_gets >0
 ) a1 )a3;
 
select   'var library_data = {' || chr(10) ||
'      labels : ['||chr(10) ||
listagg(snap_time,','||chr(10)) within GROUP (order by snap_id) ||chr(10) ||
'],' || chr(10) ||
'            datasets : [' || chr(10) ||
'        {' || chr(10) ||
'          label: "Hit point",' || chr(10) ||
'          fillColor : "rgba(0,128,255,0.2)",' || chr(10) ||
'          strokeColor : "rgba(0,128,255,1)",' || chr(10) ||
'          pointColor : "rgba(0,128,255,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : ['||chr(10) ||
listagg(hit,','||chr(10)) within GROUP (order by snap_id) ||chr(10) ||
']' || chr(10) ||
'        }' || chr(10) ||
'' || chr(10) ||
'      ]' || chr(10) ||
'    }' || chr(10)  
 from (
select 
case when count(1) over() >&maxx and  mod(row_number() over(  order by a2.snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id = a2.snap_id
           and f.instance_number = &inid) end snap_time,
a2.snap_id,  trunc(a2.ph/a2.p*100,2) hit from (
SELECT snap_id,
a1.ph - lag(a1.ph, 1, a1.ph) over( order by a1.snap_id) ph,
a1.p - lag(a1.p, 1, a1.p) over( order by a1.snap_id) p
from ( 
select snap_id,  sum(pinhits) PH,sum(pins) P  from DBA_HIST_LIBRARYCACHE   
WHERE SNAP_ID >= &bid AND SNAP_ID <=&eid and instance_number=&inid
group by snap_id ORDER BY SNAP_ID )a1)a2 where p>0 )a3;

select   'var pga_data = {' || chr(10) ||
'      labels : ['||chr(10) ||
listagg(snap_time,','||chr(10)) within GROUP (order by snap_id) ||chr(10) ||
'],' || chr(10) ||
'            datasets : [' || chr(10) ||
'        {' || chr(10) ||
'          label: "Hit point",' || chr(10) ||
'          fillColor : "rgba(128,0,255,0.3)",' || chr(10) ||
'          strokeColor : "rgba(64,0,128,1)",' || chr(10) ||
'          pointColor : "rgba(0,128,255,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : ['||chr(10) ||
listagg(hit,','||chr(10)) within GROUP (order by snap_id) ||chr(10) ||
']' || chr(10) ||
'        }' || chr(10) ||
'' || chr(10) ||
'      ]' || chr(10) ||
'    }' || chr(10)  
 from (
select 
case when count(1) over() >&maxx and  mod(row_number() over(  order by a.snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id = a.snap_id
           and f.instance_number = &inid) end snap_time,
snap_id,value hit from dba_hist_pgastat a where name ='cache hit percentage'
and a.instance_number=&inid and a.snap_id >=&bid and a.snap_id <=&eid
 order by snap_id );
 
select   'var latch_hit_data = {' || chr(10) ||
'      labels : ['||chr(10) ||
listagg(snap_time,','||chr(10)) within GROUP (order by snap_id) ||chr(10) ||
'],' || chr(10) ||
'            datasets : [' || chr(10) ||
'        {' || chr(10) ||
'          label: "Hit point",' || chr(10) ||
'          fillColor : "rgba(0,255,128,0.2)",' || chr(10) ||
'          strokeColor : "rgba(0,255,128,1)",' || chr(10) ||
'          pointColor : "rgba(0,255,128,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : ['||chr(10) ||
listagg(miss_rate,','||chr(10)) within GROUP (order by snap_id) ||chr(10) ||
']' || chr(10) ||
'        }' || chr(10) ||
'' || chr(10) ||
'      ]' || chr(10) ||
'    }' || chr(10)  
 from 
(
select 
trunc(100 - (misses/gets*100),2)  miss_rate, 
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) end snap_time, snap_id
           from (
select a1.snap_id,
 a1.gets - lag(a1.gets, 1, a1.gets) over( order by a1.snap_id) gets,
 a1.misses - lag(a1.misses, 1, a1.misses) over(  order by a1.snap_id) misses
 from (
select a.snap_id, sum(a.gets) gets, sum(a.misses) misses
  from dba_hist_latch a
 where a.instance_number = &inid and a.snap_id >= &bid and a.snap_id <=&eid
 group by a.snap_id
 order by a.snap_id ) a1  ) a2
 where gets >0) a3;

select
'var latch_sp_data = {' || chr(10) ||
'      labels : [' || chr(10) ||
 listagg(snap_time,','||chr(10)) within GROUP (order by snap_id)|| chr(10) ||
 '],' || chr(10) ||
'            datasets : [' || chr(10) ||
'        {' || chr(10) ||
'          label: "Hit point",' || chr(10) ||
'          fillColor : "rgba(255,0,0,0.2)",' || chr(10) ||
'          strokeColor : "rgba(255,0,0,1)",' || chr(10) ||
'          pointColor : "rgba(255,0,0,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : ['|| chr(10) ||
       listagg(shared_p,','||chr(10)) within GROUP (order by snap_id) || chr(10) ||
       ']' || chr(10) ||
'        }' || chr(10) ||
'' || chr(10) ||
'      ]' || chr(10) ||
'    }' || chr(10)
         from (
select 
a2.snap_id,
sum(case when a2.latch_name='row cache objects' then  a2.miss_rate else 0 end  ) row_co,
sum(case when a2.latch_name='cache buffers chains' then  a2.miss_rate else 0 end  ) cache_bc,
sum(case when a2.latch_name='shared pool' then  a2.miss_rate else 0 end  ) shared_p,
sum(case when a2.latch_name='gc element' then  a2.miss_rate else 0 end  ) gc_e,
sum(case when a2.latch_name='DML lock allocation' then  a2.miss_rate else 0 end  ) dml,
sum(case when a2.latch_name='cache buffers lru chain' then  a2.miss_rate else 0 end  ) cache_lru,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) end snap_time
 from (
select a1.snap_id, a1.latch_name, trunc(a1.miss / a1.get * 10000 ) miss_rate
  from (select a.snap_id,
               a.latch_name,
               a.gets,
               a.misses,
               a.gets - lag(a.gets, 1, a.gets) over(partition by a.latch_name order by a.snap_id, a.latch_name) get,
               a.misses - lag(a.misses, 1, a.misses) over(partition by a.latch_name order by a.snap_id, a.latch_name) miss
          from dba_hist_latch a 
         where latch_name in ('row cache objects',
                              'cache buffers chains',
                              'shared pool',
                              'gc element',
                              'DML lock allocation',
                              'cache buffers lru chain') and a.instance_number=&inid and
                              a.snap_id >=&bid and a.snap_id <=&eid
         order by snap_id, latch_name) a1
 where a1.get > 0 
  order by snap_id, latch_name )a2
group by a2.snap_id order by a2.snap_id )a3;

select
'var latch_rco_data = {' || chr(10) ||
'      labels : [' || chr(10) ||
 listagg(snap_time,','||chr(10)) within GROUP (order by snap_id)|| chr(10) ||
 '],' || chr(10) ||
'            datasets : [' || chr(10) ||
'        {' || chr(10) ||
'          label: "Hit point",' || chr(10) ||
'          fillColor : "rgba(255,128,64,0.2)",' || chr(10) ||
'          strokeColor : "rgba(255,128,64,1)",' || chr(10) ||
'          pointColor : "rgba(255,128,64,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : ['|| chr(10) ||
       listagg(row_co,','||chr(10)) within GROUP (order by snap_id) || chr(10) ||
       ']' || chr(10) ||
'        }' || chr(10) ||
'' || chr(10) ||
'      ]' || chr(10) ||
'    }' || chr(10)
         from (
select 
a2.snap_id,
sum(case when a2.latch_name='row cache objects' then  a2.miss_rate else 0 end  ) row_co,
sum(case when a2.latch_name='cache buffers chains' then  a2.miss_rate else 0 end  ) cache_bc,
sum(case when a2.latch_name='shared pool' then  a2.miss_rate else 0 end  ) shared_p,
sum(case when a2.latch_name='gc element' then  a2.miss_rate else 0 end  ) gc_e,
sum(case when a2.latch_name='DML lock allocation' then  a2.miss_rate else 0 end  ) dml,
sum(case when a2.latch_name='cache buffers lru chain' then  a2.miss_rate else 0 end  ) cache_lru,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) end snap_time
 from (
select a1.snap_id, a1.latch_name, trunc(a1.miss / a1.get * 10000 ) miss_rate
  from (select a.snap_id,
               a.latch_name,
               a.gets,
               a.misses,
               a.gets - lag(a.gets, 1, a.gets) over(partition by a.latch_name order by a.snap_id, a.latch_name) get,
               a.misses - lag(a.misses, 1, a.misses) over(partition by a.latch_name order by a.snap_id, a.latch_name) miss
          from dba_hist_latch a 
         where latch_name in ('row cache objects',
                              'cache buffers chains',
                              'shared pool',
                              'gc element',
                              'DML lock allocation',
                              'cache buffers lru chain') and a.instance_number=&inid and
                              a.snap_id >=&bid and a.snap_id <=&eid
         order by snap_id, latch_name) a1
 where a1.get > 0 
  order by snap_id, latch_name )a2
group by a2.snap_id order by a2.snap_id )a3;

select
'var latch_cbc_data = {' || chr(10) ||
'      labels : [' || chr(10) ||
 listagg(snap_time,','||chr(10)) within GROUP (order by snap_id)|| chr(10) ||
 '],' || chr(10) ||
'            datasets : [' || chr(10) ||
'        {' || chr(10) ||
'          label: "Hit point",' || chr(10) ||
'          fillColor : "rgba(0,128,0,0.2)",' || chr(10) ||
'          strokeColor : "rgba(0,128,0,1)",' || chr(10) ||
'          pointColor : "rgba(0,128,0,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : ['|| chr(10) ||
       listagg(cache_bc,','||chr(10)) within GROUP (order by snap_id) || chr(10) ||
       ']' || chr(10) ||
'        }' || chr(10) ||
'' || chr(10) ||
'      ]' || chr(10) ||
'    }' || chr(10)
         from (
select 
a2.snap_id,
sum(case when a2.latch_name='row cache objects' then  a2.miss_rate else 0 end  ) row_co,
sum(case when a2.latch_name='cache buffers chains' then  a2.miss_rate else 0 end  ) cache_bc,
sum(case when a2.latch_name='shared pool' then  a2.miss_rate else 0 end  ) shared_p,
sum(case when a2.latch_name='gc element' then  a2.miss_rate else 0 end  ) gc_e,
sum(case when a2.latch_name='DML lock allocation' then  a2.miss_rate else 0 end  ) dml,
sum(case when a2.latch_name='cache buffers lru chain' then  a2.miss_rate else 0 end  ) cache_lru,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) end snap_time
 from (
select a1.snap_id, a1.latch_name, trunc(a1.miss / a1.get * 10000 ) miss_rate
  from (select a.snap_id,
               a.latch_name,
               a.gets,
               a.misses,
               a.gets - lag(a.gets, 1, a.gets) over(partition by a.latch_name order by a.snap_id, a.latch_name) get,
               a.misses - lag(a.misses, 1, a.misses) over(partition by a.latch_name order by a.snap_id, a.latch_name) miss
          from dba_hist_latch a 
         where latch_name in ('row cache objects',
                              'cache buffers chains',
                              'shared pool',
                              'gc element',
                              'DML lock allocation',
                              'cache buffers lru chain') and a.instance_number=&inid and
                              a.snap_id >=&bid and a.snap_id <=&eid
         order by snap_id, latch_name) a1
 where a1.get > 0 
  order by snap_id, latch_name )a2
group by a2.snap_id order by a2.snap_id )a3;

select
'var latch_lru_data = {' || chr(10) ||
'      labels : [' || chr(10) ||
 listagg(snap_time,','||chr(10)) within GROUP (order by snap_id)|| chr(10) ||
 '],' || chr(10) ||
'            datasets : [' || chr(10) ||
'        {' || chr(10) ||
'          label: "Hit point",' || chr(10) ||
'          fillColor : "rgba(0,0,255,0.2)",' || chr(10) ||
'          strokeColor : "rgba(0,0,255,1)",' || chr(10) ||
'          pointColor : "rgba(0,0,255,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : ['|| chr(10) ||
       listagg(cache_lru,','||chr(10)) within GROUP (order by snap_id) || chr(10) ||
       ']' || chr(10) ||
'        }' || chr(10) ||
'' || chr(10) ||
'      ]' || chr(10) ||
'    }' || chr(10)
         from (
select 
a2.snap_id,
sum(case when a2.latch_name='row cache objects' then  a2.miss_rate else 0 end  ) row_co,
sum(case when a2.latch_name='cache buffers chains' then  a2.miss_rate else 0 end  ) cache_bc,
sum(case when a2.latch_name='shared pool' then  a2.miss_rate else 0 end  ) shared_p,
sum(case when a2.latch_name='gc element' then  a2.miss_rate else 0 end  ) gc_e,
sum(case when a2.latch_name='DML lock allocation' then  a2.miss_rate else 0 end  ) dml,
sum(case when a2.latch_name='cache buffers lru chain' then  a2.miss_rate else 0 end  ) cache_lru,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) end snap_time
 from (
select a1.snap_id, a1.latch_name, trunc(a1.miss / a1.get * 10000 ) miss_rate
  from (select a.snap_id,
               a.latch_name,
               a.gets,
               a.misses,
               a.gets - lag(a.gets, 1, a.gets) over(partition by a.latch_name order by a.snap_id, a.latch_name) get,
               a.misses - lag(a.misses, 1, a.misses) over(partition by a.latch_name order by a.snap_id, a.latch_name) miss
          from dba_hist_latch a 
         where latch_name in ('row cache objects',
                              'cache buffers chains',
                              'shared pool',
                              'gc element',
                              'DML lock allocation',
                              'cache buffers lru chain') and a.instance_number=&inid and
                              a.snap_id >=&bid and a.snap_id <=&eid
         order by snap_id, latch_name) a1
 where a1.get > 0 
  order by snap_id, latch_name )a2
group by a2.snap_id order by a2.snap_id )a3;

select
'var latch_gc_data = {' || chr(10) ||
'      labels : [' || chr(10) ||
 listagg(snap_time,','||chr(10)) within GROUP (order by snap_id)|| chr(10) ||
 '],' || chr(10) ||
'            datasets : [' || chr(10) ||
'        {' || chr(10) ||
'          label: "Hit point",' || chr(10) ||
'          fillColor : "rgba(128,0,64,0.2)",' || chr(10) ||
'          strokeColor : "rgba(128,0,64,1)",' || chr(10) ||
'          pointColor : "rgba(128,0,64,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : ['|| chr(10) ||
       listagg(gc_e,','||chr(10)) within GROUP (order by snap_id) || chr(10) ||
       ']' || chr(10) ||
'        }' || chr(10) ||
'' || chr(10) ||
'      ]' || chr(10) ||
'    }' || chr(10)
         from (
select 
a2.snap_id,
sum(case when a2.latch_name='row cache objects' then  a2.miss_rate else 0 end  ) row_co,
sum(case when a2.latch_name='cache buffers chains' then  a2.miss_rate else 0 end  ) cache_bc,
sum(case when a2.latch_name='shared pool' then  a2.miss_rate else 0 end  ) shared_p,
sum(case when a2.latch_name='gc element' then  a2.miss_rate else 0 end  ) gc_e,
sum(case when a2.latch_name='DML lock allocation' then  a2.miss_rate else 0 end  ) dml,
sum(case when a2.latch_name='cache buffers lru chain' then  a2.miss_rate else 0 end  ) cache_lru,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) end snap_time
 from (
select a1.snap_id, a1.latch_name, trunc(a1.miss / a1.get * 10000 ) miss_rate
  from (select a.snap_id,
               a.latch_name,
               a.gets,
               a.misses,
               a.gets - lag(a.gets, 1, a.gets) over(partition by a.latch_name order by a.snap_id, a.latch_name) get,
               a.misses - lag(a.misses, 1, a.misses) over(partition by a.latch_name order by a.snap_id, a.latch_name) miss
          from dba_hist_latch a 
         where latch_name in ('row cache objects',
                              'cache buffers chains',
                              'shared pool',
                              'gc element',
                              'DML lock allocation',
                              'cache buffers lru chain') and a.instance_number=&inid and
                              a.snap_id >=&bid and a.snap_id <=&eid
         order by snap_id, latch_name) a1
 where a1.get > 0 
  order by snap_id, latch_name )a2
group by a2.snap_id order by a2.snap_id )a3;

select
'var latch_dml_data = {' || chr(10) ||
'      labels : [' || chr(10) ||
 listagg(snap_time,','||chr(10)) within GROUP (order by snap_id)|| chr(10) ||
 '],' || chr(10) ||
'            datasets : [' || chr(10) ||
'        {' || chr(10) ||
'          label: "Hit point",' || chr(10) ||
'          fillColor : "rgba(64,0,128,0.2)",' || chr(10) ||
'          strokeColor : "rgba(64,0,128,1)",' || chr(10) ||
'          pointColor : "rgba(64,0,128,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : ['|| chr(10) ||
       listagg(dml,','||chr(10)) within GROUP (order by snap_id) || chr(10) ||
       ']' || chr(10) ||
'        }' || chr(10) ||
'' || chr(10) ||
'      ]' || chr(10) ||
'    }' || chr(10)
         from (
select 
a2.snap_id,
sum(case when a2.latch_name='row cache objects' then  a2.miss_rate else 0 end  ) row_co,
sum(case when a2.latch_name='cache buffers chains' then  a2.miss_rate else 0 end  ) cache_bc,
sum(case when a2.latch_name='shared pool' then  a2.miss_rate else 0 end  ) shared_p,
sum(case when a2.latch_name='gc element' then  a2.miss_rate else 0 end  ) gc_e,
sum(case when a2.latch_name='DML lock allocation' then  a2.miss_rate else 0 end  ) dml,
sum(case when a2.latch_name='cache buffers lru chain' then  a2.miss_rate else 0 end  ) cache_lru,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) end snap_time
 from (
select a1.snap_id, a1.latch_name, trunc(a1.miss / a1.get * 10000 ) miss_rate
  from (select a.snap_id,
               a.latch_name,
               a.gets,
               a.misses,
               a.gets - lag(a.gets, 1, a.gets) over(partition by a.latch_name order by a.snap_id, a.latch_name) get,
               a.misses - lag(a.misses, 1, a.misses) over(partition by a.latch_name order by a.snap_id, a.latch_name) miss
          from dba_hist_latch a 
         where latch_name in ('row cache objects',
                              'cache buffers chains',
                              'shared pool',
                              'gc element',
                              'DML lock allocation',
                              'cache buffers lru chain') and a.instance_number=&inid and
                              a.snap_id >=&bid and a.snap_id <=&eid
         order by snap_id, latch_name) a1
 where a1.get > 0 
  order by snap_id, latch_name )a2
group by a2.snap_id order by a2.snap_id )a3;

select 'var p_data = {' || chr(10) ||
'      labels : [' || chr(10) ||
 listagg(snap_time,','||chr(10)) within GROUP (order by snap_id)|| chr(10) ||
 '],' || chr(10) ||
'            datasets : [' || chr(10) ||
'        {' || chr(10) ||
'          label: "parse",' || chr(10) ||
'          fillColor : "rgba(0,255,0,0.2)",' || chr(10) ||
'          strokeColor : "rgba(0,255,128,1)",' || chr(10) ||
'          pointColor : "rgba(0,255,128,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : ['|| chr(10) ||
  listagg(hp,','||chr(10)) within GROUP (order by snap_id)|| chr(10)  ||
       ']' || chr(10) ||
'        }' || chr(10) ||
'' || chr(10) ||
'      ]' || chr(10) ||
'    }' || chr(10)
 from (
select 
trunc(a2.hp/&_iv) hp,a2.snap_id,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) end snap_time
           from (
select b.snap_id,
b.value - lag(b.value, 1, b.value) over(order by b.snap_id) hp
  FROM DBA_HIST_SYSSTAT b 
where  b.STAT_NAME in ('parse count (total)') and b.instance_number=&inid
and b.snap_id>=&bid and b.snap_id<=&eid
order by b.snap_id)a2
 where hp>0
)a3;

select 'var hp_data = {' || chr(10) ||
'      labels : [' || chr(10) ||
 listagg(snap_time,','||chr(10)) within GROUP (order by snap_id)|| chr(10) ||
 '],' || chr(10) ||
'            datasets : [' || chr(10) ||
'        {' || chr(10) ||
'          label: "Hard parse",' || chr(10) ||
'          fillColor : "rgba(0,0,255,0.2)",' || chr(10) ||
'          strokeColor : "rgba(0,0,160,1)",' || chr(10) ||
'          pointColor : "rgba(0,0,160,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : ['|| chr(10) ||
  listagg(hp,','||chr(10)) within GROUP (order by snap_id)|| chr(10)  ||
       ']' || chr(10) ||
'        }' || chr(10) ||
'' || chr(10) ||
'      ]' || chr(10) ||
'    }' || chr(10)
 from (
select 
trunc(a2.hp/&_iv) hp,a2.snap_id,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) end snap_time
           from (
select b.snap_id,
b.value - lag(b.value, 1, b.value) over(order by b.snap_id) hp
  FROM DBA_HIST_SYSSTAT b 
where  b.STAT_NAME in ('parse count (hard)') and b.instance_number=&inid
and b.snap_id>=&bid and b.snap_id<=&eid
order by b.snap_id)a2
 where hp>0
)a3;



 select
 'var top3f_data = {' || chr(10) ||
'      labels : [' || chr(10) ||
   listagg(snap_time,','||chr(10)) within GROUP (order by snap_id)|| chr(10) ||
 '],' || chr(10) ||
'            datasets : [' || chr(10) ||
'        {' || chr(10) ||
'          label: "Hit point",' || chr(10) ||
'          fillColor : "rgba(0,0,160,0)",' || chr(10) ||
'          strokeColor : "rgba(0,0,160,1)",' || chr(10) ||
'          pointColor : "rgba(0,0,160,1)",' || chr(10) ||
'          pointStrokeColor : "#fff",' || chr(10) ||
'          pointHighlightFill : "#fff",' || chr(10) ||
'          pointHighlightStroke : "rgba(220,220,220,1)",' || chr(10) ||
'          data : ['|| chr(10) ||
   listagg(top3f,','||chr(10)) within GROUP (order by snap_id)  || chr(10) ||
       ']' || chr(10) ||
'        }' || chr(10) ||
'' || chr(10) ||
'      ]' || chr(10) ||
'    }' || chr(10)
     from (
select  a1.snap_id,trunc(sum(case when top3 <=1 then avgw else 0 end)/1) top3f,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a1.snap_id
           and f.instance_number = &inid) end snap_time
 from (
select a.snap_id,a.time/a.wait_count avgw,rank() over(partition by snap_id 
order by  a.time/a.wait_count desc) top3 from dba_hist_filestatxs a where a.wait_count>0 
and a.instance_number=&inid and a.snap_id>= &bid and a.snap_id<=&eid
) a1
group by a1.snap_id ) a2;

select 
'var tfetchdata = {' || chr(10) ||
'    labels : ['|| chr(10) ||
listagg(snap_time,','||chr(10)) within GROUP (order by snap_id) || chr(10)||
'],' || chr(10) ||
'    datasets : [' || chr(10) ||
'      {' || chr(10) ||
'        fillColor : "rgba(0,64,64,0.5)",' || chr(10) ||
'        strokeColor : "rgba(255,0,0,0.8)",' || chr(10) ||
'        highlightFill: "rgba(0,64,64,0.75)",' || chr(10) ||
'        highlightStroke: "rgba(220,220,220,1)",' || chr(10) ||
'        data : ['|| chr(10) ||
listagg(trunc(tfetch/(select trunc((sysdate+snap_interval-sysdate)*24*3600) from dba_hist_wr_control)  ),','||chr(10)) within GROUP (order by snap_id)  || chr(10) ||
'      ]' || chr(10) ||
'    }' || chr(10) ||
'  ]' || chr(10) ||
'}' || chr(10)
 from (
select a2.snap_id  , 
a2.tfetch - lag(a2.tfetch, 1, a2.tfetch) over(order by a2.snap_id) tfetch,
a2.dirty - lag(a2.dirty, 1, a2.dirty) over(order by a2.snap_id) dirty,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) end snap_time
 from (
select a1.snap_id,
sum(case when a1.stat_name='table fetch continued row' then  a1.value else 0 end  )  tfetch ,
sum(case when a1.stat_name='dirty buffers inspected' then  a1.value else 0 end  )  dirty  
from
(select a.snap_id,a.stat_name,a.value from dba_hist_sysstat a where    ( a.stat_name = 'dirty buffers inspected' or a.stat_name = 'table fetch continued row' ) 
and snap_id >=&bid and snap_id<=&eid and a.instance_number=&inid
 order by a.snap_id,a.stat_name) a1 group by a1.snap_id order by a1.snap_id) a2 ) a3
where a3.tfetch >0;

select 
'var dirtydata = {' || chr(10) ||
'    labels : ['|| chr(10) ||
listagg(snap_time,','||chr(10)) within GROUP (order by snap_id) || chr(10)||
'],' || chr(10) ||
'    datasets : [' || chr(10) ||
'      {' || chr(10) ||
'        fillColor : "rgba(0,64,0,0.5)",' || chr(10) ||
'        strokeColor : "rgba(0,64,0,0.8)",' || chr(10) ||
'        highlightFill: "rgba(220,220,220,0.75)",' || chr(10) ||
'        highlightStroke: "rgba(220,220,220,1)",' || chr(10) ||
'        data : ['|| chr(10) ||
listagg(trunc(dirty/(select trunc((sysdate+snap_interval-sysdate)*24*3600) from dba_hist_wr_control)  ),','||chr(10)) within GROUP (order by snap_id)  || chr(10) ||
'      ]' || chr(10) ||
'    }' || chr(10) ||
'  ]' || chr(10) ||
'}' || chr(10)
 from (
select a2.snap_id  , 
a2.tfetch - lag(a2.tfetch, 1, a2.tfetch) over(order by a2.snap_id) tfetch,
a2.dirty - lag(a2.dirty, 1, a2.dirty) over(order by a2.snap_id) dirty,
case when count(1) over() >&maxx and  mod(row_number() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) end snap_time
 from (
select a1.snap_id,
sum(case when a1.stat_name='table fetch continued row' then  a1.value else 0 end  )  tfetch ,
sum(case when a1.stat_name='dirty buffers inspected' then  a1.value else 0 end  )  dirty  
from
(select a.snap_id,a.stat_name,a.value from dba_hist_sysstat a where    ( a.stat_name = 'dirty buffers inspected' or a.stat_name = 'table fetch continued row' ) 
and snap_id >=&bid and snap_id<=&eid and a.instance_number=&inid
 order by a.snap_id,a.stat_name) a1 group by a1.snap_id order by a1.snap_id) a2 ) a3
where a3.tfetch >0;

select 'var cellpredicatedata = {' || chr(10) ||
'    labels : ['|| chr(10) ||
listagg(snap_time,','||chr(10)) within GROUP (order by snap_id) || chr(10)||
'],' || chr(10) ||
'    datasets : [' || chr(10) ||
'      {' || chr(10) ||
'        fillColor : "rgba((255,0,0,0.5)",' || chr(10) ||
'        strokeColor : "rgba((255,0,0,0.8)",' || chr(10) ||
'        highlightFill: "rgba(220,220,220,0.75)",' || chr(10) ||
'        highlightStroke: "rgba(220,220,220,1)",' || chr(10) ||
'        data : ['|| chr(10) ||
listagg(trunc(predicate/1048576/(select trunc((sysdate+snap_interval-sysdate)*24*3600) from dba_hist_wr_control)  ),','||chr(10)) within GROUP (order by snap_id)  || chr(10) ||
'      ]' || chr(10) ||
'    }' || chr(10) ||
'  ]' || chr(10) ||
'}' || chr(10)
 from (
select a2.snap_id  , 
a2.predicate - lag(a2.predicate, 1, a2.predicate) over(order by a2.snap_id) predicate,
a2.storageidx - lag(a2.storageidx, 1, a2.storageidx) over(order by a2.snap_id) storageidx,
a2.uncom - lag(a2.uncom, 1, a2.uncom) over(order by a2.snap_id) uncom,
a2.smart - lag(a2.smart, 1, a2.smart) over(order by a2.snap_id) smart,
case when count(1) over() >&maxx and  mod(rank() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) end snap_time
 from (
select a1.snap_id,
sum(case when a1.stat_name='cell physical IO bytes eligible for predicate offload' then  a1.value else 0 end )   predicate ,
sum(case when a1.stat_name='cell physical IO bytes saved by storage index' then  a1.value else 0 end )  storageidx  ,
sum(case when a1.stat_name='cell IO uncompressed bytes' then  a1.value else 0 end)    uncom  ,
sum(case when a1.stat_name='cell physical IO interconnect bytes returned by smart scan' then  a1.value else 0 end )    smart  
from
(select a.snap_id,a.stat_name,a.value from dba_hist_sysstat a where    
stat_name in ('cell physical IO bytes eligible for predicate offload',
            'cell physical IO bytes saved by storage index',
            'cell IO uncompressed bytes',
            'cell physical IO interconnect bytes returned by smart scan') 
and snap_id >=&bid and snap_id<=&eid and a.instance_number=&inid
 order by a.snap_id,a.stat_name) a1 group by a1.snap_id order by a1.snap_id) a2 ) a3;
 
select 'var storageidxdata = {' || chr(10) ||
'    labels : ['|| chr(10) ||
listagg(snap_time,','||chr(10)) within GROUP (order by snap_id) || chr(10)||
'],' || chr(10) ||
'    datasets : [' || chr(10) ||
'      {' || chr(10) ||
'        fillColor : "rgba((255,0,0,0.5)",' || chr(10) ||
'        strokeColor : "rgba((255,0,0,0.8)",' || chr(10) ||
'        highlightFill: "rgba(220,220,220,0.75)",' || chr(10) ||
'        highlightStroke: "rgba(220,220,220,1)",' || chr(10) ||
'        data : ['|| chr(10) ||
listagg(trunc(storageidx/1048576/(select trunc((sysdate+snap_interval-sysdate)*24*3600) from dba_hist_wr_control)  ),','||chr(10)) within GROUP (order by snap_id)  || chr(10) ||
'      ]' || chr(10) ||
'    }' || chr(10) ||
'  ]' || chr(10) ||
'}' || chr(10)
 from (
select a2.snap_id  , 
a2.predicate - lag(a2.predicate, 1, a2.predicate) over(order by a2.snap_id) predicate,
a2.storageidx - lag(a2.storageidx, 1, a2.storageidx) over(order by a2.snap_id) storageidx,
a2.uncom - lag(a2.uncom, 1, a2.uncom) over(order by a2.snap_id) uncom,
a2.smart - lag(a2.smart, 1, a2.smart) over(order by a2.snap_id) smart,
case when count(1) over() >&maxx and  mod(rank() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) end snap_time
 from (
select a1.snap_id,
sum(case when a1.stat_name='cell physical IO bytes eligible for predicate offload' then  a1.value else 0 end )   predicate ,
sum(case when a1.stat_name='cell physical IO bytes saved by storage index' then  a1.value else 0 end )  storageidx  ,
sum(case when a1.stat_name='cell IO uncompressed bytes' then  a1.value else 0 end)    uncom  ,
sum(case when a1.stat_name='cell physical IO interconnect bytes returned by smart scan' then  a1.value else 0 end )    smart  
from
(select a.snap_id,a.stat_name,a.value from dba_hist_sysstat a where    
stat_name in ('cell physical IO bytes eligible for predicate offload',
            'cell physical IO bytes saved by storage index',
            'cell IO uncompressed bytes',
            'cell physical IO interconnect bytes returned by smart scan') 
and snap_id >=&bid and snap_id<=&eid and a.instance_number=&inid
 order by a.snap_id,a.stat_name) a1 group by a1.snap_id order by a1.snap_id) a2 ) a3;
 
select 'var uncomdata = {' || chr(10) ||
'    labels : ['|| chr(10) ||
listagg(snap_time,','||chr(10)) within GROUP (order by snap_id) || chr(10)||
'],' || chr(10) ||
'    datasets : [' || chr(10) ||
'      {' || chr(10) ||
'        fillColor : "rgba((255,0,0,0.5)",' || chr(10) ||
'        strokeColor : "rgba((255,0,0,0.8)",' || chr(10) ||
'        highlightFill: "rgba(220,220,220,0.75)",' || chr(10) ||
'        highlightStroke: "rgba(220,220,220,1)",' || chr(10) ||
'        data : ['|| chr(10) ||
listagg(trunc(uncom/1048576/(select trunc((sysdate+snap_interval-sysdate)*24*3600) from dba_hist_wr_control)  ),','||chr(10)) within GROUP (order by snap_id)  || chr(10) ||
'      ]' || chr(10) ||
'    }' || chr(10) ||
'  ]' || chr(10) ||
'}' || chr(10)
 from (
select a2.snap_id  , 
a2.predicate - lag(a2.predicate, 1, a2.predicate) over(order by a2.snap_id) predicate,
a2.storageidx - lag(a2.storageidx, 1, a2.storageidx) over(order by a2.snap_id) storageidx,
a2.uncom - lag(a2.uncom, 1, a2.uncom) over(order by a2.snap_id) uncom,
a2.smart - lag(a2.smart, 1, a2.smart) over(order by a2.snap_id) smart,
case when count(1) over() >&maxx and  mod(rank() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) end snap_time
 from (
select a1.snap_id,
sum(case when a1.stat_name='cell physical IO bytes eligible for predicate offload' then  a1.value else 0 end )   predicate ,
sum(case when a1.stat_name='cell physical IO bytes saved by storage index' then  a1.value else 0 end )  storageidx  ,
sum(case when a1.stat_name='cell IO uncompressed bytes' then  a1.value else 0 end)    uncom  ,
sum(case when a1.stat_name='cell physical IO interconnect bytes returned by smart scan' then  a1.value else 0 end )    smart  
from
(select a.snap_id,a.stat_name,a.value from dba_hist_sysstat a where    
stat_name in ('cell physical IO bytes eligible for predicate offload',
            'cell physical IO bytes saved by storage index',
            'cell IO uncompressed bytes',
            'cell physical IO interconnect bytes returned by smart scan') 
and snap_id >=&bid and snap_id<=&eid and a.instance_number=&inid
 order by a.snap_id,a.stat_name) a1 group by a1.snap_id order by a1.snap_id) a2 ) a3;

select 'var smartdata = {' || chr(10) ||
'    labels : ['|| chr(10) ||
listagg(snap_time,','||chr(10)) within GROUP (order by snap_id) || chr(10)||
'],' || chr(10) ||
'    datasets : [' || chr(10) ||
'      {' || chr(10) ||
'        fillColor : "rgba((255,0,0,0.5)",' || chr(10) ||
'        strokeColor : "rgba((255,0,0,0.8)",' || chr(10) ||
'        highlightFill: "rgba(220,220,220,0.75)",' || chr(10) ||
'        highlightStroke: "rgba(220,220,220,1)",' || chr(10) ||
'        data : ['|| chr(10) ||
listagg(trunc(smart/1048576/(select trunc((sysdate+snap_interval-sysdate)*24*3600) from dba_hist_wr_control)  ),','||chr(10)) within GROUP (order by snap_id)  || chr(10) ||
'      ]' || chr(10) ||
'    }' || chr(10) ||
'  ]' || chr(10) ||
'}' || chr(10)
 from (
select a2.snap_id  , 
a2.predicate - lag(a2.predicate, 1, a2.predicate) over(order by a2.snap_id) predicate,
a2.storageidx - lag(a2.storageidx, 1, a2.storageidx) over(order by a2.snap_id) storageidx,
a2.uncom - lag(a2.uncom, 1, a2.uncom) over(order by a2.snap_id) uncom,
a2.smart - lag(a2.smart, 1, a2.smart) over(order by a2.snap_id) smart,
case when count(1) over() >&maxx and  mod(rank() over(  order by snap_id),2)=0 then
             '""' else 
             (select '"'||to_char(f.begin_interval_time, 'mm-dd hh24:mi')||'"'
          from dba_hist_snapshot f
         where f.snap_id =a2.snap_id
           and f.instance_number = &inid) end snap_time
 from (
select a1.snap_id,
sum(case when a1.stat_name='cell physical IO bytes eligible for predicate offload' then  a1.value else 0 end )   predicate ,
sum(case when a1.stat_name='cell physical IO bytes saved by storage index' then  a1.value else 0 end )  storageidx  ,
sum(case when a1.stat_name='cell IO uncompressed bytes' then  a1.value else 0 end)    uncom  ,
sum(case when a1.stat_name='cell physical IO interconnect bytes returned by smart scan' then  a1.value else 0 end )    smart  
from
(select a.snap_id,a.stat_name,a.value from dba_hist_sysstat a where    
stat_name in ('cell physical IO bytes eligible for predicate offload',
            'cell physical IO bytes saved by storage index',
            'cell IO uncompressed bytes',
            'cell physical IO interconnect bytes returned by smart scan') 
and snap_id >=&bid and snap_id<=&eid and a.instance_number=&inid
 order by a.snap_id,a.stat_name) a1 group by a1.snap_id order by a1.snap_id) a2 ) a3;

select 
case when rn=1 then
  'var top5_data = [{value: '||pct||',color:"#F7464A",highlight: "#FF5A5E",label: "'||event||'"},'
     when rn=2 then
      '{value: '||pct||',color: "#46BFBD",highlight: "#5AD3D1",label: "'||event||'"},' 
      when rn=3 then
         '{value: '||pct||',color: "#FDB45C",highlight: "#FFC870",label: "'||event||'"},' 
       when rn=4 then
          '{value: '||pct||',color: "#949FB1",highlight: "#A8B3C5",label: "'||event||'"},' 
        when rn=5 then
         ' {value: '||pct||',color: "#4D5360",highlight: "#616774",label: "'||event||'"}];'||chr(10)
end
 from
(
SELECT
        trunc(PCTWTT,2) pct , EVENT, rownum rn
  FROM (SELECT EVENT, WAITS, TIME, PCTWTT, WAIT_CLASS
          FROM (SELECT E.EVENT_NAME EVENT,
                       E.TOTAL_WAITS_FG - NVL(B.TOTAL_WAITS_FG, 0) WAITS,
                       (E.TIME_WAITED_MICRO_FG - NVL(B.TIME_WAITED_MICRO_FG, 0)) /
                       1000000 TIME,
                       100 *
                       (E.TIME_WAITED_MICRO_FG - NVL(B.TIME_WAITED_MICRO_FG, 0)) /
                       ((SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL e
                          WHERE e.SNAP_ID = &eid
                            AND e.INSTANCE_NUMBER = &inid
                            AND e.STAT_NAME = 'DB time') -
                       (SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL b
                          WHERE b.SNAP_ID = &bid
                            AND b.INSTANCE_NUMBER = &inid
                            AND b.STAT_NAME = 'DB time')) PCTWTT,
                       E.WAIT_CLASS WAIT_CLASS
                  FROM DBA_HIST_SYSTEM_EVENT B, DBA_HIST_SYSTEM_EVENT E
                 WHERE B.SNAP_ID(+) = &bid
                   AND E.SNAP_ID = &eid
                   AND B.INSTANCE_NUMBER(+) = &inid
                   AND E.INSTANCE_NUMBER = &inid
                   AND B.EVENT_ID(+) = E.EVENT_ID
                   AND E.TOTAL_WAITS > NVL(B.TOTAL_WAITS, 0)
                   AND E.WAIT_CLASS != 'Idle'
                UNION ALL
                SELECT 'CPU time' EVENT,
                       TO_NUMBER(NULL) WAITS,
                       ((SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL e
                          WHERE e.SNAP_ID = &eid
                            AND e.INSTANCE_NUMBER = &inid
                            AND e.STAT_NAME = 'DB CPU') -
                       (SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL b
                          WHERE b.SNAP_ID = &bid
                            AND b.INSTANCE_NUMBER = &inid
                            AND b.STAT_NAME = 'DB CPU')) / 1000000 TIME,
                       100 * ((SELECT sum(value)
                                 FROM DBA_HIST_SYS_TIME_MODEL e
                                WHERE e.SNAP_ID = &eid
                                  AND e.INSTANCE_NUMBER = &inid
                                  AND e.STAT_NAME = 'DB CPU') -
                       (SELECT sum(value)
                                 FROM DBA_HIST_SYS_TIME_MODEL b
                                WHERE b.SNAP_ID = &bid
                                  AND b.INSTANCE_NUMBER = &inid
                                  AND b.STAT_NAME = 'DB CPU')) /
                       ((SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL e
                          WHERE e.SNAP_ID = &eid
                            AND e.INSTANCE_NUMBER = &inid
                            AND e.STAT_NAME = 'DB time') -
                       (SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL b
                          WHERE b.SNAP_ID = &bid
                            AND b.INSTANCE_NUMBER = &inid
                            AND b.STAT_NAME = 'DB time')) PCTWTT,
                       NULL WAIT_CLASS
                  from dual
                 WHERE ((SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL e
                          WHERE e.SNAP_ID = &eid
                            AND e.INSTANCE_NUMBER = &inid
                            AND e.STAT_NAME = 'DB CPU') -
                       (SELECT sum(value)
                           FROM DBA_HIST_SYS_TIME_MODEL b
                          WHERE b.SNAP_ID = &bid
                            AND b.INSTANCE_NUMBER = &inid
                            AND b.STAT_NAME = 'DB CPU'))> 0)
         ORDER BY TIME DESC, WAITS DESC)
 WHERE ROWNUM <= 5) a1 order by rn;

prompt     
prompt       window.onload = function(){
prompt     var ctx1 = document.getElementById("cpu-area").getContext("2d");
prompt     window.myLine = new Chart(ctx1).Line(cpuChartData, {
prompt         scaleOverlay : false,
prompt      scaleOverlay : false,
prompt   scaleOverride : true,
prompt   
prompt   scaleSteps : 10,
prompt   scaleStepWidth : 10,
prompt   scaleStartValue : 0,
prompt 
prompt   scaleLineColor : "rgba(0,0,0,.1)",
prompt   
prompt   scaleLineWidth : 1,
prompt 
prompt   //Boolean - Whether to show labels on the scale  
prompt   scaleShowLabels : true,
prompt   
prompt   //Interpolated JS string - can access value
prompt   scaleLabel : "<%=value%>",
prompt   
prompt   //String - Scale label font declaration for the scale label
prompt   scaleFontFamily : "'Arial'",
prompt   
prompt   //Number - Scale label font size in pixels  
prompt   scaleFontSize : 12,
prompt   
prompt   //String - Scale label font weight style  
prompt   scaleFontStyle : "normal",
prompt   
prompt   //String - Scale label font colour  
prompt   scaleFontColor : "#666",  
prompt   
prompt   ///Boolean - Whether grid lines are shown across the chart
prompt   scaleShowGridLines : true,
prompt   
prompt   //String - Colour of the grid lines
prompt   scaleGridLineColor : "rgba(0,0,0,.05)",
prompt   
prompt   //Number - Width of the grid lines
prompt   scaleGridLineWidth : 1,  
prompt   
prompt   //Boolean - Whether the line is curved between points
prompt   bezierCurve : false,
prompt   
prompt   //Boolean - Whether to show a dot for each point
prompt   pointDot : false,
prompt   
prompt   //Number - Radius of each point dot in pixels
prompt   pointDotRadius : 3,
prompt   
prompt   //Number - Pixel width of point dot stroke
prompt   pointDotStrokeWidth : 1,
prompt   
prompt   //Boolean - Whether to show a stroke for datasets
prompt   datasetStroke : true,
prompt   
prompt   //Number - Pixel width of dataset stroke
prompt   datasetStrokeWidth : 2,
prompt   
prompt   //Boolean - Whether to fill the dataset with a colour
prompt   datasetFill : true,
prompt   
prompt   //Boolean - Whether to animate the chart
prompt   animation : true,
prompt 
prompt   //Number - Number of animation steps
prompt   animationSteps : 1,
prompt   
prompt   //String - Animation easing effect
prompt   animationEasing : "easeOutQuart",
prompt 
prompt   //Function - Fires when the animation is complete
prompt   onAnimationComplete : null,
prompt       responsive: true
prompt     });

prompt var ctx2 = document.getElementById("timemodel-area").getContext("2d");
prompt    window.myBar = new Chart(ctx2).Line(timemodelChartData, {
prompt        scaleOverlay : false,
prompt  
prompt  //Boolean - If we want to override with a hard coded scale
prompt  scaleOverride : false,
prompt  
prompt  // Required if scaleOverride is true **
prompt  //Number - The number of steps in a hard coded scale
prompt  scaleSteps : null,
prompt  //Number - The value jump in the hard coded scale
prompt  scaleStepWidth : null,
prompt  //Number - The scale starting value
prompt  scaleStartValue : null,
prompt
prompt  //String - Colour of the scale line  
prompt  scaleLineColor : "rgba(0,0,0,.1)",
prompt  
prompt  //Number - Pixel width of the scale line  
prompt  scaleLineWidth : 1,
prompt 
prompt  //Boolean - Whether to show labels on the scale  
prompt  scaleShowLabels : true,
prompt  
prompt  //Interpolated JS string - can access value
prompt  scaleLabel : "<%=value%>",
prompt  
prompt  //String - Scale label font declaration for the scale label
prompt  scaleFontFamily : "'Arial'",
prompt  
prompt  //Number - Scale label font size in pixels  
prompt  scaleFontSize : 12,
prompt  
prompt  //String - Scale label font weight style  
prompt  scaleFontStyle : "normal",
prompt  
prompt  //String - Scale label font colour  
prompt  scaleFontColor : "#666",  
prompt  
prompt  ///Boolean - Whether grid lines are shown across the chart
prompt  scaleShowGridLines : true,
prompt  
prompt  //String - Colour of the grid lines
prompt  scaleGridLineColor : "rgba(0,0,0,.05)",
prompt  pointDot : false, 
prompt  //Number - Width of the grid lines
prompt  scaleGridLineWidth : 1,  
prompt
prompt  //Boolean - If there is a stroke on each bar  
prompt  barShowStroke : true,
prompt  
prompt  //Number - Pixel width of the bar stroke  
prompt  barStrokeWidth : 2,
prompt  
prompt  //Number - Spacing between each of the X value sets
prompt  barValueSpacing : 5,
prompt  
prompt  //Number - Spacing between data sets within X values
prompt  barDatasetSpacing : 1,
prompt  
prompt  //Boolean - Whether to animate the chart
prompt  animation : true,
prompt  bezierCurve : false,
prompt  //Number - Number of animation steps
prompt  animationSteps : 1,
prompt  
prompt  //String - Animation easing effect
prompt  animationEasing : "easeOutQuart",
prompt
prompt  //Function - Fires when the animation is complete
prompt  onAnimationComplete : null,
prompt      responsive : true
prompt    });    

prompt var ctx21 = document.getElementById("ash-area").getContext("2d");
prompt    window.myBar = new Chart(ctx21).Line(ashdata, {
prompt        scaleOverlay : false,
prompt  
prompt  //Boolean - If we want to override with a hard coded scale
prompt  scaleOverride : false,
prompt  
prompt  // Required if scaleOverride is true **
prompt  //Number - The number of steps in a hard coded scale
prompt  scaleSteps : null,
prompt  //Number - The value jump in the hard coded scale
prompt  scaleStepWidth : null,
prompt  //Number - The scale starting value
prompt  scaleStartValue : null,
prompt
prompt  //String - Colour of the scale line  
prompt  scaleLineColor : "rgba(0,0,0,.1)",
prompt  
prompt  //Number - Pixel width of the scale line  
prompt  scaleLineWidth : 1,
prompt 
prompt  //Boolean - Whether to show labels on the scale  
prompt  scaleShowLabels : true,
prompt  
prompt  //Interpolated JS string - can access value
prompt  scaleLabel : "<%=value%>",
prompt  
prompt  //String - Scale label font declaration for the scale label
prompt  scaleFontFamily : "'Arial'",
prompt  
prompt  //Number - Scale label font size in pixels  
prompt  scaleFontSize : 12,
prompt  
prompt  //String - Scale label font weight style  
prompt  scaleFontStyle : "normal",
prompt  
prompt  //String - Scale label font colour  
prompt  scaleFontColor : "#666",  
prompt  
prompt  ///Boolean - Whether grid lines are shown across the chart
prompt  scaleShowGridLines : true,
prompt  
prompt  //String - Colour of the grid lines
prompt  scaleGridLineColor : "rgba(0,0,0,.05)",
prompt  pointDot : false, 
prompt  //Number - Width of the grid lines
prompt  scaleGridLineWidth : 1,  
prompt
prompt  //Boolean - If there is a stroke on each bar  
prompt  barShowStroke : true,
prompt  
prompt  //Number - Pixel width of the bar stroke  
prompt  barStrokeWidth : 2,
prompt  
prompt  //Number - Spacing between each of the X value sets
prompt  barValueSpacing : 5,
prompt  
prompt  //Number - Spacing between data sets within X values
prompt  barDatasetSpacing : 1,
prompt  
prompt  //Boolean - Whether to animate the chart
prompt  animation : true,
prompt  bezierCurve : false,
prompt  //Number - Number of animation steps
prompt  animationSteps : 1,
prompt  
prompt  //String - Animation easing effect
prompt  animationEasing : "easeOutQuart",
prompt
prompt  //Function - Fires when the animation is complete
prompt  onAnimationComplete : null,
prompt      responsive : true
prompt    });    

prompt var ctx3 = document.getElementById("sqlcount-area").getContext("2d");
prompt    window.myBar = new Chart(ctx3).Bar(sqlcountdata, {
prompt        scaleOverlay : false,
prompt  
prompt  //Boolean - If we want to override with a hard coded scale
prompt  scaleOverride : false,
prompt  
prompt  
prompt  //Number - The number of steps in a hard coded scale
prompt  scaleSteps : null,
prompt  //Number - The value jump in the hard coded scale
prompt  scaleStepWidth : null,
prompt  //Number - The scale starting value
prompt  scaleStartValue : null,
prompt
prompt  //String - Colour of the scale line  
prompt  scaleLineColor : "rgba(0,0,0,.1)",
prompt  
prompt  //Number - Pixel width of the scale line  
prompt  scaleLineWidth : 1,
prompt
prompt  //Boolean - Whether to show labels on the scale 
prompt  scaleShowLabels : true,
prompt  
prompt  //Interpolated JS string - can access value
prompt  scaleLabel : "<%=value%>",
prompt  
prompt  //String - Scale label font declaration for the scale label
prompt  scaleFontFamily : "'Arial'",
prompt  
prompt  //Number - Scale label font size in pixels  
prompt  scaleFontSize : 12,
prompt  
prompt  //String - Scale label font weight style  
prompt  scaleFontStyle : "normal",
prompt  
prompt  //String - Scale label font colour  
prompt  scaleFontColor : "#666",  
prompt  
prompt  ///Boolean - Whether grid lines are shown across the chart
prompt  scaleShowGridLines : true,
prompt  
prompt  //String - Colour of the grid lines
prompt  scaleGridLineColor : "rgba(0,0,0,.05)",
prompt  
prompt  //Number - Width of the grid lines
prompt  scaleGridLineWidth : 1,  
prompt
prompt  //Boolean - If there is a stroke on each bar  
prompt  barShowStroke : true,
prompt  
prompt  //Number - Pixel width of the bar stroke  
prompt  barStrokeWidth : 2,
prompt  
prompt  //Number - Spacing between each of the X value sets
prompt  barValueSpacing : 5,
prompt  
prompt  //Number - Spacing between data sets within X values
prompt  barDatasetSpacing : 1,
prompt  
prompt  //Boolean - Whether to animate the chart
prompt  animation : true,
prompt
prompt  //Number - Number of animation steps
prompt  animationSteps : 1,
prompt  
prompt  //String - Animation easing effect
prompt  animationEasing : "easeOutQuart",
prompt
prompt  //Function - Fires when the animation is complete
prompt  onAnimationComplete : null,
prompt      responsive : true
prompt    });
prompt   var ctx4 = document.getElementById("sqlavgtime-area").getContext("2d");
prompt     window.myBar = new Chart(ctx4).Bar(sqltimedata, {
prompt         scaleOverlay : false,
prompt   
prompt   //Boolean - If we want to override with a hard coded scale
prompt   scaleOverride : false,
prompt   
prompt   
prompt   //Number - The number of steps in a hard coded scale
prompt   scaleSteps : null,
prompt   //Number - The value jump in the hard coded scale
prompt   scaleStepWidth : null,
prompt   //Number - The scale starting value
prompt   scaleStartValue : null,
prompt 
prompt   //String - Colour of the scale line  
prompt   scaleLineColor : "rgba(0,0,0,.1)",
prompt   
prompt   //Number - Pixel width of the scale line  
prompt   scaleLineWidth : 1,
prompt 
prompt   //Boolean - Whether to show labels on the scale 
prompt   scaleShowLabels : true,
prompt   
prompt   //Interpolated JS string - can access value
prompt   scaleLabel : "<%=value%>",
prompt   
prompt   //String - Scale label font declaration for the scale label
prompt   scaleFontFamily : "'Arial'",
prompt   
prompt   //Number - Scale label font size in pixels  
prompt   scaleFontSize : 12,
prompt   
prompt   //String - Scale label font weight style  
prompt   scaleFontStyle : "normal",
prompt   
prompt   //String - Scale label font colour  
prompt   scaleFontColor : "#666",  
prompt   
prompt   ///Boolean - Whether grid lines are shown across the chart
prompt   scaleShowGridLines : true,
prompt   
prompt   //String - Colour of the grid lines
prompt   scaleGridLineColor : "rgba(0,0,0,.05)",
prompt   
prompt   //Number - Width of the grid lines
prompt   scaleGridLineWidth : 1,  
prompt 
prompt   //Boolean - If there is a stroke on each bar  
prompt   barShowStroke : true,
prompt   
prompt   //Number - Pixel width of the bar stroke  
prompt   barStrokeWidth : 2,
prompt   
prompt   //Number - Spacing between each of the X value sets
prompt   barValueSpacing : 5,
prompt   
prompt   //Number - Spacing between data sets within X values
prompt   barDatasetSpacing : 1,
prompt   
prompt   //Boolean - Whether to animate the chart
prompt   animation : true,
prompt 
prompt   //Number - Number of animation steps
prompt   animationSteps : 1,
prompt   
prompt   //String - Animation easing effect
prompt   animationEasing : "easeOutQuart",
prompt 
prompt   //Function - Fires when the animation is complete
prompt   onAnimationComplete : null,
prompt       responsive : true
prompt     });
prompt    var ctx5 = document.getElementById("logicread-area").getContext("2d");
prompt    window.myLine = new Chart(ctx5).Line(logicreadData, {
prompt        scaleOverlay : false,
prompt  
prompt  //Boolean - If we want to override with a hard coded scale
prompt     scaleOverlay : false,
prompt  
prompt  //Boolean - If we want to override with a hard coded scale
prompt  scaleOverride : false,
prompt  
prompt  
prompt  //Number - The number of steps in a hard coded scale 
prompt  scaleSteps : 10,
prompt  //Number - The value jump in the hard coded scale
prompt  scaleStepWidth : 10,
prompt  //Number - The scale starting value 
prompt  scaleStartValue : 0,
prompt
prompt  //String - Colour of the scale line  
prompt  scaleLineColor : "rgba(0,0,0,.1)",
prompt  
prompt  //Number - Pixel width of the scale line  
prompt  scaleLineWidth : 1,
prompt
prompt  //Boolean - Whether to show labels on the scale  
prompt  scaleShowLabels : true,
prompt  
prompt  //Interpolated JS string - can access value
prompt  scaleLabel : "<%=value%>",
prompt  
prompt  //String - Scale label font declaration for the scale label
prompt  scaleFontFamily : "'Arial'",
prompt  
prompt  //Number - Scale label font size in pixels  
prompt  scaleFontSize : 12,
prompt  
prompt  //String - Scale label font weight style  
prompt  scaleFontStyle : "normal",
prompt  
prompt  //String - Scale label font colour  
prompt  scaleFontColor : "#666",  
prompt  
prompt  ///Boolean - Whether grid lines are shown across the chart
prompt  scaleShowGridLines : true,
prompt  
prompt  //String - Colour of the grid lines
prompt  scaleGridLineColor : "rgba(0,0,0,.05)",
prompt  
prompt  //Number - Width of the grid lines
prompt  scaleGridLineWidth : 1,  
prompt  
prompt  //Boolean - Whether the line is curved between points 
prompt  bezierCurve : false,
prompt  
prompt  //Boolean - Whether to show a dot for each point
prompt  pointDot : false,
prompt  
prompt  //Number - Radius of each point dot in pixels
prompt  pointDotRadius : 3,
prompt  
prompt  //Number - Pixel width of point dot stroke
prompt  pointDotStrokeWidth : 1,
prompt  
prompt  //Boolean - Whether to show a stroke for datasets
prompt  datasetStroke : true,
prompt  
prompt  //Number - Pixel width of dataset stroke
prompt  datasetStrokeWidth : 2,
prompt  
prompt  //Boolean - Whether to fill the dataset with a colour
prompt  datasetFill : true,
prompt  
prompt  //Boolean - Whether to animate the chart
prompt  animation : true,
prompt
prompt  //Number - Number of animation steps
prompt  animationSteps : 1,
prompt  
prompt  //String - Animation easing effect
prompt  animationEasing : "easeOutQuart",
prompt
prompt  //Function - Fires when the animation is complete
prompt  onAnimationComplete : null,
prompt      responsive: true
prompt    });


prompt  var ctx6 = document.getElementById("physical-area").getContext("2d");
prompt    window.myLine = new Chart(ctx6).Line(physicalData, {
prompt        scaleOverlay : false,
prompt  
prompt  //Boolean - If we want to override with a hard coded scale
prompt     scaleOverlay : false,
prompt  
prompt  //Boolean - If we want to override with a hard coded scale 
prompt  scaleOverride : false,
prompt  
prompt  
prompt  //Number - The number of steps in a hard coded scale  
prompt  scaleSteps : 10,
prompt  //Number - The value jump in the hard coded scale 
prompt  scaleStepWidth : 10,
prompt  //Number - The scale starting value 
prompt  scaleStartValue : 0,
prompt
prompt  //String - Colour of the scale line  
prompt  scaleLineColor : "rgba(0,0,0,.1)",
prompt  
prompt  //Number - Pixel width of the scale line  
prompt  scaleLineWidth : 1,
prompt
prompt  //Boolean - Whether to show labels on the scale  
prompt  scaleShowLabels : true,
prompt  
prompt  //Interpolated JS string - can access value
prompt  scaleLabel : "<%=value%>",
prompt  
prompt  //String - Scale label font declaration for the scale label
prompt  scaleFontFamily : "'Arial'",
prompt  
prompt  //Number - Scale label font size in pixels  
prompt  scaleFontSize : 12,
prompt  
prompt  //String - Scale label font weight style  
prompt  scaleFontStyle : "normal",
prompt  
prompt  //String - Scale label font colour  
prompt  scaleFontColor : "#666",  
prompt  
prompt  ///Boolean - Whether grid lines are shown across the chart
prompt  scaleShowGridLines : true,
prompt  
prompt  //String - Colour of the grid lines
prompt  scaleGridLineColor : "rgba(0,0,0,.05)",
prompt  
prompt  //Number - Width of the grid lines
prompt  scaleGridLineWidth : 1,  
prompt  
prompt  //Boolean - Whether the line is curved between points 
prompt  bezierCurve : false,
prompt  
prompt  //Boolean - Whether to show a dot for each point
prompt  pointDot : false,
prompt  
prompt  //Number - Radius of each point dot in pixels
prompt  pointDotRadius : 3,
prompt  
prompt  //Number - Pixel width of point dot stroke
prompt  pointDotStrokeWidth : 1,
prompt  
prompt  //Boolean - Whether to show a stroke for datasets
prompt  datasetStroke : true,
prompt  
prompt  //Number - Pixel width of dataset stroke
prompt  datasetStrokeWidth : 2,
prompt  
prompt  //Boolean - Whether to fill the dataset with a colour
prompt  datasetFill : true,
prompt  
prompt  //Boolean - Whether to animate the chart
prompt  animation : true,
prompt
prompt  //Number - Number of animation steps
prompt  animationSteps : 1,
prompt  
prompt  //String - Animation easing effect
prompt  animationEasing : "easeOutQuart",
prompt
prompt  //Function - Fires when the animation is complete
prompt  onAnimationComplete : null,
prompt      responsive: true
prompt    });

prompt   var ctx7 = document.getElementById("usercommit-area").getContext("2d");
prompt     window.myBar = new Chart(ctx7).Bar(usercommitdata, {
prompt         scaleOverlay : false,
prompt   
prompt   //Boolean - If we want to override with a hard coded scale
prompt   scaleOverride : false,
prompt   
prompt   
prompt   //Number - The number of steps in a hard coded scale
prompt   scaleSteps : null,
prompt   //Number - The value jump in the hard coded scale
prompt   scaleStepWidth : null,
prompt   //Number - The scale starting value
prompt   scaleStartValue : null,
prompt 
prompt   //String - Colour of the scale line  
prompt   scaleLineColor : "rgba(0,0,0,.1)",
prompt   
prompt   //Number - Pixel width of the scale line  
prompt   scaleLineWidth : 1,
prompt 
prompt   //Boolean - Whether to show labels on the scale
prompt   scaleShowLabels : true,
prompt   
prompt   //Interpolated JS string - can access value
prompt   scaleLabel : "<%=value%>",
prompt   
prompt   //String - Scale label font declaration for the scale label
prompt   scaleFontFamily : "'Arial'",
prompt   
prompt   //Number - Scale label font size in pixels  
prompt   scaleFontSize : 12,
prompt   
prompt   //String - Scale label font weight style  
prompt   scaleFontStyle : "normal",
prompt   
prompt   //String - Scale label font colour  
prompt   scaleFontColor : "#666",  
prompt   
prompt   ///Boolean - Whether grid lines are shown across the chart
prompt   scaleShowGridLines : true,
prompt   
prompt   //String - Colour of the grid lines
prompt   scaleGridLineColor : "rgba(0,0,0,.05)",
prompt   
prompt   //Number - Width of the grid lines
prompt   scaleGridLineWidth : 1,  
prompt 
prompt   //Boolean - If there is a stroke on each bar  
prompt   barShowStroke : true,
prompt   
prompt   //Number - Pixel width of the bar stroke  
prompt   barStrokeWidth : 2,
prompt   
prompt   //Number - Spacing between each of the X value sets
prompt   barValueSpacing : 5,
prompt   
prompt   //Number - Spacing between data sets within X values
prompt   barDatasetSpacing : 1,
prompt   
prompt   //Boolean - Whether to animate the chart
prompt   animation : true,
prompt 
prompt   //Number - Number of animation steps
prompt   animationSteps : 1,
prompt   
prompt   //String - Animation easing effect
prompt   animationEasing : "easeOutQuart",
prompt 
prompt   //Function - Fires when the animation is complete
prompt   onAnimationComplete : null,
prompt       responsive : true
prompt     });

prompt var ctx8 = document.getElementById("connect-area").getContext("2d");
prompt    window.myLine = new Chart(ctx8).Line(connectData, {
prompt        scaleOverlay : false,
prompt  
prompt  //Boolean - If we want to override with a hard coded scale
prompt     scaleOverlay : false,
prompt  
prompt  //Boolean - If we want to override with a hard coded scale
prompt  scaleOverride : false,
prompt  
prompt  
prompt  //Number - The number of steps in a hard coded scale 
prompt  scaleSteps : 10,
prompt  //Number - The value jump in the hard coded scale 
prompt  scaleStepWidth : 10,
prompt  //Number - The scale starting value 
prompt  scaleStartValue : 0,
prompt
prompt  //String - Colour of the scale line  
prompt  scaleLineColor : "rgba(0,0,0,.1)",
prompt  
prompt  //Number - Pixel width of the scale line  
prompt  scaleLineWidth : 1,
prompt
prompt  //Boolean - Whether to show labels on the scale  
prompt  scaleShowLabels : true,
prompt  
prompt  //Interpolated JS string - can access value
prompt  scaleLabel : "<%=value%>",
prompt  
prompt  //String - Scale label font declaration for the scale label
prompt  scaleFontFamily : "'Arial'",
prompt  
prompt  //Number - Scale label font size in pixels  
prompt  scaleFontSize : 12,
prompt  
prompt  //String - Scale label font weight style  
prompt  scaleFontStyle : "normal",
prompt  
prompt  //String - Scale label font colour  
prompt  scaleFontColor : "#666",  
prompt  
prompt  ///Boolean - Whether grid lines are shown across the chart
prompt  scaleShowGridLines : true,
prompt  
prompt  //String - Colour of the grid lines
prompt  scaleGridLineColor : "rgba(0,0,0,.05)",
prompt  
prompt  //Number - Width of the grid lines
prompt  scaleGridLineWidth : 1,  
prompt  
prompt  //Boolean - Whether the line is curved between points 
prompt  bezierCurve : false,
prompt  
prompt  //Boolean - Whether to show a dot for each point
prompt  pointDot : false,
prompt  
prompt  //Number - Radius of each point dot in pixels
prompt  pointDotRadius : 3,
prompt  
prompt  //Number - Pixel width of point dot stroke
prompt  pointDotStrokeWidth : 1,
prompt  
prompt  //Boolean - Whether to show a stroke for datasets
prompt  datasetStroke : true,
prompt  
prompt  //Number - Pixel width of dataset stroke
prompt  datasetStrokeWidth : 2,
prompt  
prompt  //Boolean - Whether to fill the dataset with a colour
prompt  datasetFill : true,
prompt  
prompt  //Boolean - Whether to animate the chart
prompt  animation : true,
prompt
prompt  //Number - Number of animation steps
prompt  animationSteps : 1,
prompt  
prompt  //String - Animation easing effect
prompt  animationEasing : "easeOutQuart",
prompt
prompt  //Function - Fires when the animation is complete
prompt  onAnimationComplete : null,
prompt      responsive: true
prompt    });


prompt   var ctx9 = document.getElementById("archivelog-area").getContext("2d");
prompt    window.myBar = new Chart(ctx9).Bar(archivelogdata, {
prompt        scaleOverlay : false,
prompt  
prompt  //Boolean - If we want to override with a hard coded scale
prompt  scaleOverride : false,
prompt  
prompt  
prompt  //Number - The number of steps in a hard coded scale
prompt  scaleSteps : null,
prompt  //Number - The value jump in the hard coded scale
prompt  scaleStepWidth : null,
prompt  //Number - The scale starting value
prompt  scaleStartValue : null,
prompt
prompt  //String - Colour of the scale line  
prompt  scaleLineColor : "rgba(0,0,0,.1)",
prompt  
prompt  //Number - Pixel width of the scale line  
prompt  scaleLineWidth : 1,
prompt
prompt  //Boolean - Whether to show labels on the scale 
prompt  scaleShowLabels : true,
prompt  
prompt  //Interpolated JS string - can access value
prompt  scaleLabel : "<%=value%>",
prompt  
prompt  //String - Scale label font declaration for the scale label
prompt  scaleFontFamily : "'Arial'",
prompt  
prompt  //Number - Scale label font size in pixels  
prompt  scaleFontSize : 12,
prompt  
prompt  //String - Scale label font weight style  
prompt  scaleFontStyle : "normal",
prompt  
prompt  //String - Scale label font colour  
prompt  scaleFontColor : "#666",  
prompt  
prompt  ///Boolean - Whether grid lines are shown across the chart
prompt  scaleShowGridLines : true,
prompt  
prompt  //String - Colour of the grid lines
prompt  scaleGridLineColor : "rgba(0,0,0,.05)",
prompt  
prompt  //Number - Width of the grid lines
prompt  scaleGridLineWidth : 1,  
prompt
prompt  //Boolean - If there is a stroke on each bar  
prompt  barShowStroke : true,
prompt  
prompt  //Number - Pixel width of the bar stroke  
prompt  barStrokeWidth : 2,
prompt  
prompt  //Number - Spacing between each of the X value sets
prompt  barValueSpacing : 5,
prompt  
prompt  //Number - Spacing between data sets within X values
prompt  barDatasetSpacing : 1,
prompt  
prompt  //Boolean - Whether to animate the chart
prompt  animation : true,
prompt
prompt  //Number - Number of animation steps
prompt  animationSteps : 1,
prompt  
prompt  //String - Animation easing effect
prompt  animationEasing : "easeOutQuart",
prompt
prompt  //Function - Fires when the animation is complete
prompt  onAnimationComplete : null,
prompt      responsive : true
prompt    });

prompt  //---------10-------------------
prompt  
prompt     var ctx10 = document.getElementById("gcblock-area").getContext("2d");
prompt     window.myLine = new Chart(ctx10).Line(gcblockData, {
prompt         scaleOverlay : false,
prompt   
prompt   //Boolean - If we want to override with a hard coded scale
prompt      scaleOverlay : false,
prompt   
prompt   //Boolean - If we want to override with a hard coded scale 
prompt   scaleOverride : false,
prompt   
prompt   
prompt   //Number - The number of steps in a hard coded scale  
prompt   scaleSteps : 10,
prompt   //Number - The value jump in the hard coded scale 
prompt   scaleStepWidth : 10,
prompt   //Number - The scale starting value 
prompt   scaleStartValue : 0,
prompt 
prompt   //String - Colour of the scale line  
prompt   scaleLineColor : "rgba(0,0,0,.1)",
prompt   
prompt   //Number - Pixel width of the scale line  
prompt   scaleLineWidth : 1,
prompt 
prompt   //Boolean - Whether to show labels on the scale  
prompt   scaleShowLabels : true,
prompt   
prompt   //Interpolated JS string - can access value
prompt   scaleLabel : "<%=value%>",
prompt   
prompt   //String - Scale label font declaration for the scale label
prompt   scaleFontFamily : "'Arial'",
prompt   
prompt   //Number - Scale label font size in pixels  
prompt   scaleFontSize : 12,
prompt   
prompt   //String - Scale label font weight style  
prompt   scaleFontStyle : "normal",
prompt   
prompt   //String - Scale label font colour  
prompt   scaleFontColor : "#666",  
prompt   
prompt   ///Boolean - Whether grid lines are shown across the chart
prompt   scaleShowGridLines : true,
prompt   
prompt   //String - Colour of the grid lines
prompt   scaleGridLineColor : "rgba(0,0,0,.05)",
prompt   
prompt   //Number - Width of the grid lines
prompt   scaleGridLineWidth : 1,  
prompt   
prompt   //Boolean - Whether the line is curved between points 
prompt   bezierCurve : false,
prompt   
prompt   //Boolean - Whether to show a dot for each point
prompt   pointDot : false,
prompt   
prompt   //Number - Radius of each point dot in pixels
prompt   pointDotRadius : 3,
prompt   
prompt   //Number - Pixel width of point dot stroke
prompt   pointDotStrokeWidth : 1,
prompt   
prompt   //Boolean - Whether to show a stroke for datasets
prompt   datasetStroke : true,
prompt   
prompt   //Number - Pixel width of dataset stroke
prompt   datasetStrokeWidth : 2,
prompt   
prompt   //Boolean - Whether to fill the dataset with a colour
prompt   datasetFill : true,
prompt   
prompt   //Boolean - Whether to animate the chart
prompt   animation : true,
prompt 
prompt   //Number - Number of animation steps
prompt   animationSteps : 1,
prompt   
prompt   //String - Animation easing effect
prompt   animationEasing : "easeOutQuart",
prompt 
prompt   //Function - Fires when the animation is complete
prompt   onAnimationComplete : null,
prompt       responsive: true
prompt     });
prompt //-------------------------------------10----------------------------------    
prompt   
prompt   //------------------------------11-------------------
prompt  
prompt     var ctx11 = document.getElementById("gcmessage-area").getContext("2d");
prompt     window.myLine = new Chart(ctx11).Line(gcmessageData, {
prompt         scaleOverlay : false,
prompt   
prompt   //Boolean - If we want to override with a hard coded scale
prompt      scaleOverlay : false,
prompt   
prompt   //Boolean - If we want to override with a hard coded scale 
prompt   scaleOverride : false,
prompt   
prompt   
prompt   //Number - The number of steps in a hard coded scale  
prompt   scaleSteps : 10,
prompt   //Number - The value jump in the hard coded scale 
prompt   scaleStepWidth : 10,
prompt   //Number - The scale starting value 
prompt   scaleStartValue : 0,
prompt 
prompt   //String - Colour of the scale line  
prompt   scaleLineColor : "rgba(0,0,0,.1)",
prompt   
prompt   //Number - Pixel width of the scale line  
prompt   scaleLineWidth : 1,
prompt 
prompt   //Boolean - Whether to show labels on the scale  
prompt   scaleShowLabels : true,
prompt   
prompt   //Interpolated JS string - can access value
prompt   scaleLabel : "<%=value%>",
prompt   
prompt   //String - Scale label font declaration for the scale label
prompt   scaleFontFamily : "'Arial'",
prompt   
prompt   //Number - Scale label font size in pixels  
prompt   scaleFontSize : 12,
prompt   
prompt   //String - Scale label font weight style  
prompt   scaleFontStyle : "normal",
prompt   
prompt   //String - Scale label font colour  
prompt   scaleFontColor : "#666",  
prompt   
prompt   ///Boolean - Whether grid lines are shown across the chart
prompt   scaleShowGridLines : true,
prompt   
prompt   //String - Colour of the grid lines
prompt   scaleGridLineColor : "rgba(0,0,0,.05)",
prompt   
prompt   //Number - Width of the grid lines
prompt   scaleGridLineWidth : 1,  
prompt   
prompt   //Boolean - Whether the line is curved between points 
prompt   bezierCurve : false,
prompt   
prompt   //Boolean - Whether to show a dot for each point
prompt   pointDot : false,
prompt   
prompt   //Number - Radius of each point dot in pixels
prompt   pointDotRadius : 3,
prompt   
prompt   //Number - Pixel width of point dot stroke
prompt   pointDotStrokeWidth : 1,
prompt   
prompt   //Boolean - Whether to show a stroke for datasets
prompt   datasetStroke : true,
prompt   
prompt   //Number - Pixel width of dataset stroke
prompt   datasetStrokeWidth : 2,
prompt   
prompt   //Boolean - Whether to fill the dataset with a colour
prompt   datasetFill : true,
prompt   
prompt   //Boolean - Whether to animate the chart
prompt   animation : true,
prompt 
prompt   //Number - Number of animation steps
prompt   animationSteps : 1,
prompt   
prompt   //String - Animation easing effect
prompt   animationEasing : "easeOutQuart",
prompt 
prompt   //Function - Fires when the animation is complete
prompt   onAnimationComplete : null,
prompt       responsive: true
prompt     });
    
 
prompt  
prompt     var ctx12 = document.getElementById("gccrtime-area").getContext("2d");
prompt     window.myLine = new Chart(ctx12).Line(gccrtimeData, {
prompt         scaleOverlay : false,
prompt   
prompt   //Boolean - If we want to override with a hard coded scale
prompt      scaleOverlay : false,
prompt   
prompt   //Boolean - If we want to override with a hard coded scale 
prompt   scaleOverride : false,
prompt   
prompt   
prompt   //Number - The number of steps in a hard coded scale 
prompt   scaleSteps : 10,
prompt   //Number - The value jump in the hard coded scale
prompt   scaleStepWidth : 10,
prompt   //Number - The scale starting value 
prompt   scaleStartValue : 0,
prompt 
prompt   //String - Colour of the scale line  
prompt   scaleLineColor : "rgba(0,0,0,.1)",
prompt   
prompt   //Number - Pixel width of the scale line  
prompt   scaleLineWidth : 1,
prompt 
prompt   //Boolean - Whether to show labels on the scale  
prompt   scaleShowLabels : true,
prompt   
prompt   //Interpolated JS string - can access value
prompt   scaleLabel : "<%=value%>",
prompt   
prompt   //String - Scale label font declaration for the scale label
prompt   scaleFontFamily : "'Arial'",
prompt   
prompt   //Number - Scale label font size in pixels  
prompt   scaleFontSize : 12,
prompt   
prompt   //String - Scale label font weight style  
prompt   scaleFontStyle : "normal",
prompt   
prompt   //String - Scale label font colour  
prompt   scaleFontColor : "#666",  
prompt   
prompt   ///Boolean - Whether grid lines are shown across the chart
prompt   scaleShowGridLines : true,
prompt   
prompt   //String - Colour of the grid lines
prompt   scaleGridLineColor : "rgba(0,0,0,.05)",
prompt   
prompt   //Number - Width of the grid lines
prompt   scaleGridLineWidth : 1,  
prompt   
prompt   //Boolean - Whether the line is curved between points 
prompt   bezierCurve : false,
prompt   
prompt   //Boolean - Whether to show a dot for each point
prompt   pointDot : false,
prompt   
prompt   //Number - Radius of each point dot in pixels
prompt   pointDotRadius : 3,
prompt   
prompt   //Number - Pixel width of point dot stroke
prompt   pointDotStrokeWidth : 1,
prompt   
prompt   //Boolean - Whether to show a stroke for datasets
prompt   datasetStroke : true,
prompt   
prompt   //Number - Pixel width of dataset stroke
prompt   datasetStrokeWidth : 2,
prompt   
prompt   //Boolean - Whether to fill the dataset with a colour
prompt   datasetFill : true,
prompt   
prompt   //Boolean - Whether to animate the chart
prompt   animation : true,
prompt 
prompt   //Number - Number of animation steps
prompt   animationSteps : 1,
prompt   
prompt   //String - Animation easing effect
prompt   animationEasing : "easeOutQuart",
prompt 
prompt   //Function - Fires when the animation is complete
prompt   onAnimationComplete : null,
prompt       responsive: true
prompt     });
prompt  
prompt     var ctx13 = document.getElementById("gccutime-area").getContext("2d");
prompt     window.myLine = new Chart(ctx13).Line(gccutimeData, {
prompt         scaleOverlay : false,
prompt   
prompt   //Boolean - If we want to override with a hard coded scale
prompt      scaleOverlay : false,
prompt   
prompt   //Boolean - If we want to override with a hard coded scale 
prompt   scaleOverride : false,
prompt   
prompt   
prompt   //Number - The number of steps in a hard coded scale  
prompt   scaleSteps : 10,
prompt   //Number - The value jump in the hard coded scale 
prompt   scaleStepWidth : 10,
prompt   //Number - The scale starting value 
prompt   scaleStartValue : 0,
prompt 
prompt   //String - Colour of the scale line  
prompt   scaleLineColor : "rgba(0,0,0,.1)",
prompt   
prompt   //Number - Pixel width of the scale line  
prompt   scaleLineWidth : 1,
prompt 
prompt   //Boolean - Whether to show labels on the scale  
prompt   scaleShowLabels : true,
prompt   
prompt   //Interpolated JS string - can access value
prompt   scaleLabel : "<%=value%>",
prompt   
prompt   //String - Scale label font declaration for the scale label
prompt   scaleFontFamily : "'Arial'",
prompt   
prompt   //Number - Scale label font size in pixels  
prompt   scaleFontSize : 12,
prompt   
prompt   //String - Scale label font weight style  
prompt   scaleFontStyle : "normal",
prompt   
prompt   //String - Scale label font colour  
prompt   scaleFontColor : "#666",  
prompt   
prompt   ///Boolean - Whether grid lines are shown across the chart
prompt   scaleShowGridLines : true,
prompt   
prompt   //String - Colour of the grid lines
prompt   scaleGridLineColor : "rgba(0,0,0,.05)",
prompt   
prompt   //Number - Width of the grid lines
prompt   scaleGridLineWidth : 1,  
prompt   
prompt   //Boolean - Whether the line is curved between points 
prompt   bezierCurve : false,
prompt   
prompt   //Boolean - Whether to show a dot for each point
prompt   pointDot : false,
prompt   
prompt   //Number - Radius of each point dot in pixels
prompt   pointDotRadius : 3,
prompt   
prompt   //Number - Pixel width of point dot stroke
prompt   pointDotStrokeWidth : 1,
prompt   
prompt   //Boolean - Whether to show a stroke for datasets
prompt   datasetStroke : true,
prompt   
prompt   //Number - Pixel width of dataset stroke
prompt   datasetStrokeWidth : 2,
prompt   
prompt   //Boolean - Whether to fill the dataset with a colour
prompt   datasetFill : true,
prompt   
prompt   //Boolean - Whether to animate the chart
prompt   animation : true,
prompt 
prompt   //Number - Number of animation steps
prompt   animationSteps : 1,
prompt   
prompt   //String - Animation easing effect
prompt   animationEasing : "easeOutQuart",
prompt 
prompt   //Function - Fires when the animation is complete
prompt   onAnimationComplete : null,
prompt       responsive: true
prompt     });

prompt     var ctx14 = document.getElementById("buffhit-area").getContext("2d");
prompt     window.myLine = new Chart(ctx14).Line(buffhitData, {
prompt         scaleOverlay : false,
prompt   
prompt   //Boolean - If we want to override with a hard coded scale
prompt      scaleOverlay : false,
prompt   
prompt   //Boolean - If we want to override with a hard coded scale 
prompt   scaleOverride : true,
prompt   
prompt   
prompt   //Number - The number of steps in a hard coded scale  
prompt   scaleSteps : 10,
prompt   //Number - The value jump in the hard coded scale 
prompt   scaleStepWidth : 10,
prompt   //Number - The scale starting value 
prompt   scaleStartValue : 0,
prompt 
prompt   //String - Colour of the scale line  
prompt   scaleLineColor : "rgba(0,0,0,.1)",
prompt   
prompt   //Number - Pixel width of the scale line  
prompt   scaleLineWidth : 1,
prompt 
prompt   //Boolean - Whether to show labels on the scale  
prompt   scaleShowLabels : true,
prompt   
prompt   //Interpolated JS string - can access value
prompt   scaleLabel : "<%=value%>",
prompt   
prompt   //String - Scale label font declaration for the scale label
prompt   scaleFontFamily : "'Arial'",
prompt   
prompt   //Number - Scale label font size in pixels  
prompt   scaleFontSize : 12,
prompt   
prompt   //String - Scale label font weight style  
prompt   scaleFontStyle : "normal",
prompt   
prompt   //String - Scale label font colour  
prompt   scaleFontColor : "#666",  
prompt   
prompt   ///Boolean - Whether grid lines are shown across the chart
prompt   scaleShowGridLines : true,
prompt   
prompt   //String - Colour of the grid lines
prompt   scaleGridLineColor : "rgba(0,0,0,.05)",
prompt   
prompt   //Number - Width of the grid lines
prompt   scaleGridLineWidth : 1,  
prompt   
prompt   //Boolean - Whether the line is curved between points 
prompt   bezierCurve : false,
prompt   
prompt   //Boolean - Whether to show a dot for each point
prompt   pointDot : false,
prompt   
prompt   //Number - Radius of each point dot in pixels
prompt   pointDotRadius : 3,
prompt   
prompt   //Number - Pixel width of point dot stroke
prompt   pointDotStrokeWidth : 1,
prompt   
prompt   //Boolean - Whether to show a stroke for datasets
prompt   datasetStroke : true,
prompt   
prompt   //Number - Pixel width of dataset stroke
prompt   datasetStrokeWidth : 2,
prompt   
prompt   //Boolean - Whether to fill the dataset with a colour
prompt   datasetFill : true,
prompt   
prompt   //Boolean - Whether to animate the chart
prompt   animation : true,
prompt 
prompt   //Number - Number of animation steps
prompt   animationSteps : 1,
prompt   
prompt   //String - Animation easing effect
prompt   animationEasing : "easeOutQuart",
prompt 
prompt   //Function - Fires when the animation is complete
prompt   onAnimationComplete : null,
prompt       responsive: true
prompt     });

prompt     var ctx141 = document.getElementById("pga-area").getContext("2d");
prompt     window.myLine = new Chart(ctx141).Line(pga_data, {
prompt         scaleOverlay : false,
prompt   
prompt   //Boolean - If we want to override with a hard coded scale
prompt      scaleOverlay : false,
prompt   
prompt   //Boolean - If we want to override with a hard coded scale 
prompt   scaleOverride : true,
prompt   
prompt   
prompt   //Number - The number of steps in a hard coded scale  
prompt   scaleSteps : 10,
prompt   //Number - The value jump in the hard coded scale 
prompt   scaleStepWidth : 10,
prompt   //Number - The scale starting value 
prompt   scaleStartValue : 0,
prompt 
prompt   //String - Colour of the scale line  
prompt   scaleLineColor : "rgba(0,0,0,.1)",
prompt   
prompt   //Number - Pixel width of the scale line  
prompt   scaleLineWidth : 1,
prompt 
prompt   //Boolean - Whether to show labels on the scale  
prompt   scaleShowLabels : true,
prompt   
prompt   //Interpolated JS string - can access value
prompt   scaleLabel : "<%=value%>",
prompt   
prompt   //String - Scale label font declaration for the scale label
prompt   scaleFontFamily : "'Arial'",
prompt   
prompt   //Number - Scale label font size in pixels  
prompt   scaleFontSize : 12,
prompt   
prompt   //String - Scale label font weight style  
prompt   scaleFontStyle : "normal",
prompt   
prompt   //String - Scale label font colour  
prompt   scaleFontColor : "#666",  
prompt   
prompt   ///Boolean - Whether grid lines are shown across the chart
prompt   scaleShowGridLines : true,
prompt   
prompt   //String - Colour of the grid lines
prompt   scaleGridLineColor : "rgba(0,0,0,.05)",
prompt   
prompt   //Number - Width of the grid lines
prompt   scaleGridLineWidth : 1,  
prompt   
prompt   //Boolean - Whether the line is curved between points 
prompt   bezierCurve : false,
prompt   
prompt   //Boolean - Whether to show a dot for each point
prompt   pointDot : false,
prompt   
prompt   //Number - Radius of each point dot in pixels
prompt   pointDotRadius : 3,
prompt   
prompt   //Number - Pixel width of point dot stroke
prompt   pointDotStrokeWidth : 1,
prompt   
prompt   //Boolean - Whether to show a stroke for datasets
prompt   datasetStroke : true,
prompt   
prompt   //Number - Pixel width of dataset stroke
prompt   datasetStrokeWidth : 2,
prompt   
prompt   //Boolean - Whether to fill the dataset with a colour
prompt   datasetFill : true,
prompt   
prompt   //Boolean - Whether to animate the chart
prompt   animation : true,
prompt 
prompt   //Number - Number of animation steps
prompt   animationSteps : 1,
prompt   
prompt   //String - Animation easing effect
prompt   animationEasing : "easeOutQuart",
prompt 
prompt   //Function - Fires when the animation is complete
prompt   onAnimationComplete : null,
prompt       responsive: true
prompt     });

prompt     var ctx140 = document.getElementById("library-area").getContext("2d");
prompt     window.myLine = new Chart(ctx140).Line(library_data, {
prompt         scaleOverlay : false,
prompt   
prompt   //Boolean - If we want to override with a hard coded scale
prompt      scaleOverlay : false,
prompt   
prompt   //Boolean - If we want to override with a hard coded scale 
prompt   scaleOverride : true,
prompt   
prompt   
prompt   //Number - The number of steps in a hard coded scale  
prompt   scaleSteps : 10,
prompt   //Number - The value jump in the hard coded scale 
prompt   scaleStepWidth : 10,
prompt   //Number - The scale starting value 
prompt   scaleStartValue : 0,
prompt 
prompt   //String - Colour of the scale line  
prompt   scaleLineColor : "rgba(0,0,0,.1)",
prompt   
prompt   //Number - Pixel width of the scale line  
prompt   scaleLineWidth : 1,
prompt 
prompt   //Boolean - Whether to show labels on the scale  
prompt   scaleShowLabels : true,
prompt   
prompt   //Interpolated JS string - can access value
prompt   scaleLabel : "<%=value%>",
prompt   
prompt   //String - Scale label font declaration for the scale label
prompt   scaleFontFamily : "'Arial'",
prompt   
prompt   //Number - Scale label font size in pixels  
prompt   scaleFontSize : 12,
prompt   
prompt   //String - Scale label font weight style  
prompt   scaleFontStyle : "normal",
prompt   
prompt   //String - Scale label font colour  
prompt   scaleFontColor : "#666",  
prompt   
prompt   ///Boolean - Whether grid lines are shown across the chart
prompt   scaleShowGridLines : true,
prompt   
prompt   //String - Colour of the grid lines
prompt   scaleGridLineColor : "rgba(0,0,0,.05)",
prompt   
prompt   //Number - Width of the grid lines
prompt   scaleGridLineWidth : 1,  
prompt   
prompt   //Boolean - Whether the line is curved between points 
prompt   bezierCurve : false,
prompt   
prompt   //Boolean - Whether to show a dot for each point
prompt   pointDot : false,
prompt   
prompt   //Number - Radius of each point dot in pixels
prompt   pointDotRadius : 3,
prompt   
prompt   //Number - Pixel width of point dot stroke
prompt   pointDotStrokeWidth : 1,
prompt   
prompt   //Boolean - Whether to show a stroke for datasets
prompt   datasetStroke : true,
prompt   
prompt   //Number - Pixel width of dataset stroke
prompt   datasetStrokeWidth : 2,
prompt   
prompt   //Boolean - Whether to fill the dataset with a colour
prompt   datasetFill : true,
prompt   
prompt   //Boolean - Whether to animate the chart
prompt   animation : true,
prompt 
prompt   //Number - Number of animation steps
prompt   animationSteps : 1,
prompt   
prompt   //String - Animation easing effect
prompt   animationEasing : "easeOutQuart",
prompt 
prompt   //Function - Fires when the animation is complete
prompt   onAnimationComplete : null,
prompt       responsive: true
prompt     });

prompt var ctx151 = document.getElementById("latch_hit-area").getContext("2d")
prompt window.myLine = new Chart(ctx151).Line(latch_hit_data, {
prompt scaleOverlay : false,
prompt 
prompt //Boolean - If we want to override with a hard coded scale
prompt scaleOverlay : false,
prompt 
prompt //Boolean - If we want to override with a hard coded scale  
prompt scaleOverride : true,
prompt 
prompt //Number - The number of steps in a hard coded scale  
prompt scaleSteps : 10,
prompt //Number - The value jump in the hard coded scale 
prompt scaleStepWidth : 0.5,
prompt //Number - The scale starting value
prompt scaleStartValue : 95,
prompt 
prompt //String - Colour of the scale line
prompt scaleLineColor : "rgba(0,0,0,.1)",
prompt 
prompt //Number - Pixel width of the scale line
prompt scaleLineWidth : 1,
prompt 
prompt //Boolean - Whether to show labels on the scale
prompt scaleShowLabels : true,
prompt 
prompt //Interpolated JS string - can access value
prompt scaleLabel : "<%=value%>",
prompt 
prompt //String - Scale label font declaration for the scale label
prompt scaleFontFamily : "'Arial'",
prompt 
prompt //Number - Scale label font size in pixels
prompt scaleFontSize : 12,
prompt 
prompt //String - Scale label font weight style
prompt scaleFontStyle : "normal",
prompt 
prompt //String - Scale label font colour
prompt scaleFontColor : "#666",
prompt 
prompt ///Boolean - Whether grid lines are shown across the chart
prompt scaleShowGridLines : true,
prompt 
prompt //String - Colour of the grid lines
prompt scaleGridLineColor : "rgba(0,0,0,.05)",
prompt 
prompt //Number - Width of the grid lines
prompt scaleGridLineWidth : 1,
prompt 
prompt //Boolean - Whether the line is curved between points 
prompt bezierCurve : false,
prompt 
prompt //Boolean - Whether to show a dot for each point
prompt pointDot : false,
prompt 
prompt //Number - Radius of each point dot in pixels
prompt pointDotRadius : 3,
prompt 
prompt //Number - Pixel width of point dot stroke
prompt pointDotStrokeWidth : 1,
prompt 
prompt //Boolean - Whether to show a stroke for datasets
prompt datasetStroke : true,
prompt 
prompt //Number - Pixel width of dataset stroke
prompt datasetStrokeWidth : 2,
prompt 
prompt //Boolean - Whether to fill the dataset with a colour
prompt datasetFill : true,
prompt 
prompt //Boolean - Whether to animate the chart
prompt animation : true,
prompt 
prompt //Number - Number of animation steps
prompt animationSteps : 1,
prompt 
prompt //String - Animation easing effect
prompt animationEasing : "easeOutQuart",
prompt 
prompt //Function - Fires when the animation is complete
prompt onAnimationComplete : null,
prompt responsive: true
prompt })

prompt var ctx15 = document.getElementById("latch_sp-area").getContext("2d")
prompt window.myLine = new Chart(ctx15).Line(latch_sp_data, {
prompt scaleOverlay : false,
prompt 
prompt //Boolean - If we want to override with a hard coded scale
prompt scaleOverlay : false,
prompt 
prompt //Boolean - If we want to override with a hard coded scale
prompt scaleOverride : false,
prompt 
prompt 
prompt //Number - The number of steps in a hard coded scale
prompt scaleSteps : 10,
prompt //Number - The value jump in the hard coded scale
prompt scaleStepWidth : 10,
prompt //Number - The scale starting value
prompt scaleStartValue : 0,
prompt 
prompt //String - Colour of the scale line
prompt scaleLineColor : "rgba(0,0,0,.1)",
prompt 
prompt //Number - Pixel width of the scale line
prompt scaleLineWidth : 1,
prompt 
prompt //Boolean - Whether to show labels on the scale
prompt scaleShowLabels : true,
prompt 
prompt //Interpolated JS string - can access value
prompt scaleLabel : "<%=value%>",
prompt 
prompt //String - Scale label font declaration for the scale label
prompt scaleFontFamily : "'Arial'",
prompt 
prompt //Number - Scale label font size in pixels
prompt scaleFontSize : 12,
prompt 
prompt //String - Scale label font weight style
prompt scaleFontStyle : "normal",
prompt 
prompt //String - Scale label font colour
prompt scaleFontColor : "#666",
prompt 
prompt ///Boolean - Whether grid lines are shown across the chart
prompt scaleShowGridLines : true,
prompt 
prompt //String - Colour of the grid lines
prompt scaleGridLineColor : "rgba(0,0,0,.05)",
prompt 
prompt //Number - Width of the grid lines
prompt scaleGridLineWidth : 1,
prompt 
prompt //Boolean - Whether the line is curved between points
prompt bezierCurve : false,
prompt 
prompt //Boolean - Whether to show a dot for each point
prompt pointDot : false,
prompt 
prompt //Number - Radius of each point dot in pixels
prompt pointDotRadius : 3,
prompt 
prompt //Number - Pixel width of point dot stroke
prompt pointDotStrokeWidth : 1,
prompt 
prompt //Boolean - Whether to show a stroke for datasets
prompt datasetStroke : true,
prompt 
prompt //Number - Pixel width of dataset stroke
prompt datasetStrokeWidth : 2,
prompt 
prompt //Boolean - Whether to fill the dataset with a colour
prompt datasetFill : true,
prompt 
prompt //Boolean - Whether to animate the chart
prompt animation : true,
prompt 
prompt //Number - Number of animation steps
prompt animationSteps : 1,
prompt 
prompt //String - Animation easing effect
prompt animationEasing : "easeOutQuart",
prompt 
prompt //Function - Fires when the animation is complete
prompt onAnimationComplete : null,
prompt responsive: true
prompt })
prompt 
prompt var ctx16 = document.getElementById("latch_rco-area").getContext("2d")
prompt window.myLine = new Chart(ctx16).Line(latch_rco_data, {
prompt scaleOverlay : false,
prompt 
prompt //Boolean - If we want to override with a hard coded scale
prompt scaleOverlay : false,
prompt 
prompt //Boolean - If we want to override with a hard coded scale
prompt scaleOverride : false,
prompt 
prompt 
prompt //Number - The number of steps in a hard coded scale
prompt scaleSteps : 10,
prompt //Number - The value jump in the hard coded scale
prompt scaleStepWidth : 10,
prompt //Number - The scale starting value
prompt scaleStartValue : 0,
prompt 
prompt //String - Colour of the scale line
prompt scaleLineColor : "rgba(0,0,0,.1)",
prompt 
prompt //Number - Pixel width of the scale line
prompt scaleLineWidth : 1,
prompt 
prompt //Boolean - Whether to show labels on the scale
prompt scaleShowLabels : true,
prompt 
prompt //Interpolated JS string - can access value
prompt scaleLabel : "<%=value%>",
prompt 
prompt //String - Scale label font declaration for the scale label
prompt scaleFontFamily : "'Arial'",
prompt 
prompt //Number - Scale label font size in pixels
prompt scaleFontSize : 12,
prompt 
prompt //String - Scale label font weight style
prompt scaleFontStyle : "normal",
prompt 
prompt //String - Scale label font colour
prompt scaleFontColor : "#666",
prompt 
prompt ///Boolean - Whether grid lines are shown across the chart
prompt scaleShowGridLines : true,
prompt 
prompt //String - Colour of the grid lines
prompt scaleGridLineColor : "rgba(0,0,0,.05)",
prompt 
prompt //Number - Width of the grid lines
prompt scaleGridLineWidth : 1,
prompt 
prompt //Boolean - Whether the line is curved between points
prompt bezierCurve : false,
prompt 
prompt //Boolean - Whether to show a dot for each point
prompt pointDot : false,
prompt 
prompt //Number - Radius of each point dot in pixels
prompt pointDotRadius : 3,
prompt 
prompt //Number - Pixel width of point dot stroke
prompt pointDotStrokeWidth : 1,
prompt 
prompt //Boolean - Whether to show a stroke for datasets
prompt datasetStroke : true,
prompt 
prompt //Number - Pixel width of dataset stroke
prompt datasetStrokeWidth : 2,
prompt 
prompt //Boolean - Whether to fill the dataset with a colour
prompt datasetFill : true,
prompt 
prompt //Boolean - Whether to animate the chart
prompt animation : true,
prompt 
prompt //Number - Number of animation steps
prompt animationSteps : 1,
prompt 
prompt //String - Animation easing effect
prompt animationEasing : "easeOutQuart",
prompt 
prompt //Function - Fires when the animation is complete
prompt onAnimationComplete : null,
prompt responsive: true
prompt })
prompt 
prompt var ctx17 = document.getElementById("latch_cbc-area").getContext("2d")
prompt window.myLine = new Chart(ctx17).Line(latch_cbc_data, {
prompt scaleOverlay : false,
prompt 
prompt //Boolean - If we want to override with a hard coded scale
prompt scaleOverlay : false,
prompt 
prompt //Boolean - If we want to override with a hard coded scale
prompt scaleOverride : false,
prompt 
prompt 
prompt //Number - The number of steps in a hard coded scale
prompt scaleSteps : 10,
prompt //Number - The value jump in the hard coded scale
prompt scaleStepWidth : 10,
prompt //Number - The scale starting value
prompt scaleStartValue : 0,
prompt 
prompt //String - Colour of the scale line
prompt scaleLineColor : "rgba(0,0,0,.1)",
prompt 
prompt //Number - Pixel width of the scale line
prompt scaleLineWidth : 1,
prompt 
prompt //Boolean - Whether to show labels on the scale
prompt scaleShowLabels : true,
prompt 
prompt //Interpolated JS string - can access value
prompt scaleLabel : "<%=value%>",
prompt 
prompt //String - Scale label font declaration for the scale label
prompt scaleFontFamily : "'Arial'",
prompt 
prompt //Number - Scale label font size in pixels
prompt scaleFontSize : 12,
prompt 
prompt //String - Scale label font weight style
prompt scaleFontStyle : "normal",
prompt 
prompt //String - Scale label font colour
prompt scaleFontColor : "#666",
prompt 
prompt ///Boolean - Whether grid lines are shown across the chart
prompt scaleShowGridLines : true,
prompt 
prompt //String - Colour of the grid lines
prompt scaleGridLineColor : "rgba(0,0,0,.05)",
prompt 
prompt //Number - Width of the grid lines
prompt scaleGridLineWidth : 1,
prompt 
prompt //Boolean - Whether the line is curved between points
prompt bezierCurve : false,
prompt 
prompt //Boolean - Whether to show a dot for each point
prompt pointDot : false,
prompt 
prompt //Number - Radius of each point dot in pixels
prompt pointDotRadius : 3,
prompt 
prompt //Number - Pixel width of point dot stroke
prompt pointDotStrokeWidth : 1,
prompt 
prompt //Boolean - Whether to show a stroke for datasets
prompt datasetStroke : true,
prompt 
prompt //Number - Pixel width of dataset stroke
prompt datasetStrokeWidth : 2,
prompt 
prompt //Boolean - Whether to fill the dataset with a colour
prompt datasetFill : true,
prompt 
prompt //Boolean - Whether to animate the chart
prompt animation : true,
prompt 
prompt //Number - Number of animation steps
prompt animationSteps : 1,
prompt 
prompt //String - Animation easing effect
prompt animationEasing : "easeOutQuart",
prompt 
prompt //Function - Fires when the animation is complete
prompt onAnimationComplete : null,
prompt responsive: true
prompt })
prompt 
prompt var ctx18 = document.getElementById("latch_lru-area").getContext("2d")
prompt window.myLine = new Chart(ctx18).Line(latch_lru_data, {
prompt scaleOverlay : false,
prompt 
prompt //Boolean - If we want to override with a hard coded scale
prompt scaleOverlay : false,
prompt 
prompt //Boolean - If we want to override with a hard coded scale
prompt scaleOverride : false,
prompt 
prompt 
prompt //Number - The number of steps in a hard coded scale
prompt scaleSteps : 10,
prompt //Number - The value jump in the hard coded scale
prompt scaleStepWidth : 10,
prompt //Number - The scale starting value
prompt scaleStartValue : 0,
prompt 
prompt //String - Colour of the scale line
prompt scaleLineColor : "rgba(0,0,0,.1)",
prompt 
prompt //Number - Pixel width of the scale line
prompt scaleLineWidth : 1,
prompt 
prompt //Boolean - Whether to show labels on the scale
prompt scaleShowLabels : true,
prompt 
prompt //Interpolated JS string - can access value
prompt scaleLabel : "<%=value%>",
prompt 
prompt //String - Scale label font declaration for the scale label
prompt scaleFontFamily : "'Arial'",
prompt 
prompt //Number - Scale label font size in pixels
prompt scaleFontSize : 12,
prompt 
prompt //String - Scale label font weight style
prompt scaleFontStyle : "normal",
prompt 
prompt //String - Scale label font colour
prompt scaleFontColor : "#666",
prompt 
prompt ///Boolean - Whether grid lines are shown across the chart
prompt scaleShowGridLines : true,
prompt 
prompt //String - Colour of the grid lines
prompt scaleGridLineColor : "rgba(0,0,0,.05)",
prompt 
prompt //Number - Width of the grid lines
prompt scaleGridLineWidth : 1,
prompt 
prompt //Boolean - Whether the line is curved between points
prompt bezierCurve : false,
prompt 
prompt //Boolean - Whether to show a dot for each point
prompt pointDot : false,
prompt 
prompt //Number - Radius of each point dot in pixels
prompt pointDotRadius : 3,
prompt 
prompt //Number - Pixel width of point dot stroke
prompt pointDotStrokeWidth : 1,
prompt 
prompt //Boolean - Whether to show a stroke for datasets
prompt datasetStroke : true,
prompt 
prompt //Number - Pixel width of dataset stroke
prompt datasetStrokeWidth : 2,
prompt 
prompt //Boolean - Whether to fill the dataset with a colour
prompt datasetFill : true,
prompt 
prompt //Boolean - Whether to animate the chart
prompt animation : true,
prompt 
prompt //Number - Number of animation steps
prompt animationSteps : 1,
prompt 
prompt //String - Animation easing effect
prompt animationEasing : "easeOutQuart",
prompt 
prompt //Function - Fires when the animation is complete
prompt onAnimationComplete : null,
prompt responsive: true
prompt })
prompt 
prompt var ctx19 = document.getElementById("latch_gc-area").getContext("2d")
prompt window.myLine = new Chart(ctx19).Line(latch_gc_data, {
prompt scaleOverlay : false,
prompt 
prompt //Boolean - If we want to override with a hard coded scale
prompt scaleOverlay : false,
prompt 
prompt //Boolean - If we want to override with a hard coded scale
prompt scaleOverride : false,
prompt 
prompt 
prompt //Number - The number of steps in a hard coded scale
prompt scaleSteps : 10,
prompt //Number - The value jump in the hard coded scale
prompt scaleStepWidth : 10,
prompt //Number - The scale starting value
prompt scaleStartValue : 0,
prompt 
prompt //String - Colour of the scale line
prompt scaleLineColor : "rgba(0,0,0,.1)",
prompt 
prompt //Number - Pixel width of the scale line
prompt scaleLineWidth : 1,
prompt 
prompt //Boolean - Whether to show labels on the scale
prompt scaleShowLabels : true,
prompt 
prompt //Interpolated JS string - can access value
prompt scaleLabel : "<%=value%>",
prompt 
prompt //String - Scale label font declaration for the scale label
prompt scaleFontFamily : "'Arial'",
prompt 
prompt //Number - Scale label font size in pixels
prompt scaleFontSize : 12,
prompt 
prompt //String - Scale label font weight style
prompt scaleFontStyle : "normal",
prompt 
prompt //String - Scale label font colour
prompt scaleFontColor : "#666",
prompt 
prompt ///Boolean - Whether grid lines are shown across the chart
prompt scaleShowGridLines : true,
prompt 
prompt //String - Colour of the grid lines
prompt scaleGridLineColor : "rgba(0,0,0,.05)",
prompt 
prompt //Number - Width of the grid lines
prompt scaleGridLineWidth : 1,
prompt 
prompt //Boolean - Whether the line is curved between points
prompt bezierCurve : false,
prompt 
prompt //Boolean - Whether to show a dot for each point
prompt pointDot : false,
prompt 
prompt //Number - Radius of each point dot in pixels
prompt pointDotRadius : 3,
prompt 
prompt //Number - Pixel width of point dot stroke
prompt pointDotStrokeWidth : 1,
prompt 
prompt //Boolean - Whether to show a stroke for datasets
prompt datasetStroke : true,
prompt 
prompt //Number - Pixel width of dataset stroke
prompt datasetStrokeWidth : 2,
prompt 
prompt //Boolean - Whether to fill the dataset with a colour
prompt datasetFill : true,
prompt 
prompt //Boolean - Whether to animate the chart
prompt animation : true,
prompt 
prompt //Number - Number of animation steps
prompt animationSteps : 1,
prompt 
prompt //String - Animation easing effect
prompt animationEasing : "easeOutQuart",
prompt 
prompt //Function - Fires when the animation is complete
prompt onAnimationComplete : null,
prompt responsive: true
prompt })
prompt 
prompt var ctx20 = document.getElementById("latch_dml-area").getContext("2d")
prompt window.myLine = new Chart(ctx20).Line(latch_rco_data, {
prompt scaleOverlay : false,
prompt 
prompt //Boolean - If we want to override with a hard coded scale
prompt scaleOverlay : false,
prompt 
prompt //Boolean - If we want to override with a hard coded scale
prompt scaleOverride : false,
prompt 
prompt 
prompt //Number - The number of steps in a hard coded scale
prompt scaleSteps : 10,
prompt //Number - The value jump in the hard coded scale
prompt scaleStepWidth : 10,
prompt //Number - The scale starting value
prompt scaleStartValue : 0,
prompt 
prompt //String - Colour of the scale line
prompt scaleLineColor : "rgba(0,0,0,.1)",
prompt 
prompt //Number - Pixel width of the scale line
prompt scaleLineWidth : 1,
prompt 
prompt //Boolean - Whether to show labels on the scale
prompt scaleShowLabels : true,
prompt 
prompt //Interpolated JS string - can access value
prompt scaleLabel : "<%=value%>",
prompt 
prompt //String - Scale label font declaration for the scale label
prompt scaleFontFamily : "'Arial'",
prompt 
prompt //Number - Scale label font size in pixels
prompt scaleFontSize : 12,
prompt 
prompt //String - Scale label font weight style
prompt scaleFontStyle : "normal",
prompt 
prompt //String - Scale label font colour
prompt scaleFontColor : "#666",
prompt 
prompt ///Boolean - Whether grid lines are shown across the chart
prompt scaleShowGridLines : true,
prompt 
prompt //String - Colour of the grid lines
prompt scaleGridLineColor : "rgba(0,0,0,.05)",
prompt 
prompt //Number - Width of the grid lines
prompt scaleGridLineWidth : 1,
prompt 
prompt //Boolean - Whether the line is curved between points
prompt bezierCurve : false,
prompt 
prompt //Boolean - Whether to show a dot for each point
prompt pointDot : false,
prompt 
prompt //Number - Radius of each point dot in pixels
prompt pointDotRadius : 3,
prompt 
prompt //Number - Pixel width of point dot stroke
prompt pointDotStrokeWidth : 1,
prompt 
prompt //Boolean - Whether to show a stroke for datasets
prompt datasetStroke : true,
prompt 
prompt //Number - Pixel width of dataset stroke
prompt datasetStrokeWidth : 2,
prompt 
prompt //Boolean - Whether to fill the dataset with a colour
prompt datasetFill : true,
prompt 
prompt //Boolean - Whether to animate the chart
prompt animation : true,
prompt 
prompt //Number - Number of animation steps
prompt animationSteps : 1,
prompt 
prompt //String - Animation easing effect
prompt animationEasing : "easeOutQuart",
prompt 
prompt //Function - Fires when the animation is complete
prompt onAnimationComplete : null,
prompt responsive: true
prompt })

prompt   var ctx211 = document.getElementById("p-area").getContext("2d");
prompt     window.myBar = new Chart(ctx211).Bar(p_data, {
prompt         scaleOverlay : false,
prompt   
prompt   //Boolean - If we want to override with a hard coded scale
prompt   scaleOverride : false,
prompt   
prompt   
prompt   //Number - The number of steps in a hard coded scale
prompt   scaleSteps : null,
prompt   //Number - The value jump in the hard coded scale
prompt   scaleStepWidth : null,
prompt   //Number - The scale starting value
prompt   scaleStartValue : null,
prompt 
prompt   //String - Colour of the scale line  
prompt   scaleLineColor : "rgba(0,0,0,.1)",
prompt   
prompt   //Number - Pixel width of the scale line  
prompt   scaleLineWidth : 1,
prompt 
prompt   //Boolean - Whether to show labels on the scale
prompt   scaleShowLabels : true,
prompt   
prompt   //Interpolated JS string - can access value
prompt   scaleLabel : "<%=value%>",
prompt   
prompt   //String - Scale label font declaration for the scale label
prompt   scaleFontFamily : "'Arial'",
prompt   
prompt   //Number - Scale label font size in pixels  
prompt   scaleFontSize : 12,
prompt   
prompt   //String - Scale label font weight style  
prompt   scaleFontStyle : "normal",
prompt   
prompt   //String - Scale label font colour  
prompt   scaleFontColor : "#666",  
prompt   
prompt   ///Boolean - Whether grid lines are shown across the chart
prompt   scaleShowGridLines : true,
prompt   
prompt   //String - Colour of the grid lines
prompt   scaleGridLineColor : "rgba(0,0,0,.05)",
prompt   
prompt   //Number - Width of the grid lines
prompt   scaleGridLineWidth : 1,  
prompt 
prompt   //Boolean - If there is a stroke on each bar  
prompt   barShowStroke : true,
prompt   
prompt   //Number - Pixel width of the bar stroke  
prompt   barStrokeWidth : 2,
prompt   
prompt   //Number - Spacing between each of the X value sets
prompt   barValueSpacing : 5,
prompt   
prompt   //Number - Spacing between data sets within X values
prompt   barDatasetSpacing : 1,
prompt   
prompt   //Boolean - Whether to animate the chart
prompt   animation : true,
prompt 
prompt   //Number - Number of animation steps
prompt   animationSteps : 1,
prompt   
prompt   //String - Animation easing effect
prompt   animationEasing : "easeOutQuart",
prompt 
prompt   //Function - Fires when the animation is complete
prompt   onAnimationComplete : null,
prompt       responsive : true
prompt     });

prompt   var ctx212 = document.getElementById("hp-area").getContext("2d");
prompt     window.myBar = new Chart(ctx212).Bar(hp_data, {
prompt         scaleOverlay : false,
prompt   
prompt   //Boolean - If we want to override with a hard coded scale
prompt   scaleOverride : false,
prompt   
prompt   
prompt   //Number - The number of steps in a hard coded scale
prompt   scaleSteps : null,
prompt   //Number - The value jump in the hard coded scale
prompt   scaleStepWidth : null,
prompt   //Number - The scale starting value
prompt   scaleStartValue : null,
prompt 
prompt   //String - Colour of the scale line  
prompt   scaleLineColor : "rgba(0,0,0,.1)",
prompt   
prompt   //Number - Pixel width of the scale line  
prompt   scaleLineWidth : 1,
prompt 
prompt   //Boolean - Whether to show labels on the scale
prompt   scaleShowLabels : true,
prompt   
prompt   //Interpolated JS string - can access value
prompt   scaleLabel : "<%=value%>",
prompt   
prompt   //String - Scale label font declaration for the scale label
prompt   scaleFontFamily : "'Arial'",
prompt   
prompt   //Number - Scale label font size in pixels  
prompt   scaleFontSize : 12,
prompt   
prompt   //String - Scale label font weight style  
prompt   scaleFontStyle : "normal",
prompt   
prompt   //String - Scale label font colour  
prompt   scaleFontColor : "#666",  
prompt   
prompt   ///Boolean - Whether grid lines are shown across the chart
prompt   scaleShowGridLines : true,
prompt   
prompt   //String - Colour of the grid lines
prompt   scaleGridLineColor : "rgba(0,0,0,.05)",
prompt   
prompt   //Number - Width of the grid lines
prompt   scaleGridLineWidth : 1,  
prompt 
prompt   //Boolean - If there is a stroke on each bar  
prompt   barShowStroke : true,
prompt   
prompt   //Number - Pixel width of the bar stroke  
prompt   barStrokeWidth : 2,
prompt   
prompt   //Number - Spacing between each of the X value sets
prompt   barValueSpacing : 5,
prompt   
prompt   //Number - Spacing between data sets within X values
prompt   barDatasetSpacing : 1,
prompt   
prompt   //Boolean - Whether to animate the chart
prompt   animation : true,
prompt 
prompt   //Number - Number of animation steps
prompt   animationSteps : 1,
prompt   
prompt   //String - Animation easing effect
prompt   animationEasing : "easeOutQuart",
prompt 
prompt   //Function - Fires when the animation is complete
prompt   onAnimationComplete : null,
prompt       responsive : true
prompt     });


prompt var ctx21 = document.getElementById("top3f-area").getContext("2d")
prompt window.myLine = new Chart(ctx21).Line(top3f_data, {
prompt scaleOverlay : false,
prompt 
prompt //Boolean - If we want to override with a hard coded scale
prompt scaleOverlay : false,
prompt 
prompt //Boolean - If we want to override with a hard coded scale
prompt scaleOverride : false,
prompt 
prompt 
prompt //Number - The number of steps in a hard coded scale
prompt scaleSteps : 10,
prompt //Number - The value jump in the hard coded scale
prompt scaleStepWidth : 10,
prompt //Number - The scale starting value
prompt scaleStartValue : 0,
prompt 
prompt //String - Colour of the scale line
prompt scaleLineColor : "rgba(0,0,0,.1)",
prompt 
prompt //Number - Pixel width of the scale line
prompt scaleLineWidth : 1,
prompt 
prompt //Boolean - Whether to show labels on the scale
prompt scaleShowLabels : true,
prompt 
prompt //Interpolated JS string - can access value
prompt scaleLabel : "<%=value%>",
prompt 
prompt //String - Scale label font declaration for the scale label
prompt scaleFontFamily : "'Arial'",
prompt 
prompt //Number - Scale label font size in pixels
prompt scaleFontSize : 12,
prompt 
prompt //String - Scale label font weight style
prompt scaleFontStyle : "normal",
prompt 
prompt //String - Scale label font colour
prompt scaleFontColor : "#666",
prompt 
prompt ///Boolean - Whether grid lines are shown across the chart
prompt scaleShowGridLines : true,
prompt 
prompt //String - Colour of the grid lines
prompt scaleGridLineColor : "rgba(0,0,0,.05)",
prompt 
prompt //Number - Width of the grid lines
prompt scaleGridLineWidth : 1,
prompt 
prompt //Boolean - Whether the line is curved between points
prompt bezierCurve : false,
prompt 
prompt //Boolean - Whether to show a dot for each point
prompt pointDot : false,
prompt 
prompt //Number - Radius of each point dot in pixels
prompt pointDotRadius : 3,
prompt 
prompt //Number - Pixel width of point dot stroke
prompt pointDotStrokeWidth : 1,
prompt 
prompt //Boolean - Whether to show a stroke for datasets
prompt datasetStroke : true,
prompt 
prompt //Number - Pixel width of dataset stroke
prompt datasetStrokeWidth : 2,
prompt 
prompt //Boolean - Whether to fill the dataset with a colour
prompt datasetFill : true,
prompt 
prompt //Boolean - Whether to animate the chart
prompt animation : true,
prompt 
prompt //Number - Number of animation steps
prompt animationSteps : 1,
prompt 
prompt //String - Animation easing effect
prompt animationEasing : "easeOutQuart",
prompt 
prompt //Function - Fires when the animation is complete
prompt onAnimationComplete : null,
prompt responsive: true
prompt });

prompt var ctx22 = document.getElementById("top5-area").getContext("2d");
prompt         window.myPie = new Chart(ctx22).Pie(top5_data, {
prompt             segmentShowStroke : true,
prompt   //String - The colour of each segment stroke
prompt   segmentStrokeColor : "#fff",
prompt   //Number - The width of each segment stroke
prompt   segmentStrokeWidth : 2,
prompt   segmentShowStroke : true,
prompt   //Boolean - Whether we should animate the chart  
prompt   animation : true,
prompt   //Number - Amount of animation steps
prompt   animationSteps : 100,
prompt   //String - Animation easing effect
prompt   animationEasing : "easeOutBounce",
prompt   //Boolean - Whether we animate the rotation of the Pie
prompt   animateRotate : true,
prompt   //Boolean - Whether we animate scaling the Pie from the centre
prompt   animateScale : false,
prompt   //Function - Will fire on animation completion.
prompt   onAnimationComplete : null
prompt           });

prompt  var ctx23 = document.getElementById("tfetch-area").getContext("2d");
prompt    window.myLine = new Chart(ctx23).Line(tfetchdata, {
prompt        scaleOverlay : false,
prompt  
prompt  //Boolean - If we want to override with a hard coded scale
prompt     scaleOverlay : false,
prompt  
prompt  //Boolean - If we want to override with a hard coded scale 
prompt  scaleOverride : false,
prompt  
prompt  
prompt  //Number - The number of steps in a hard coded scale  
prompt  scaleSteps : 10,
prompt  //Number - The value jump in the hard coded scale 
prompt  scaleStepWidth : 10,
prompt  //Number - The scale starting value 
prompt  scaleStartValue : 0,
prompt
prompt  //String - Colour of the scale line  
prompt  scaleLineColor : "rgba(0,0,0,.1)",
prompt  
prompt  //Number - Pixel width of the scale line  
prompt  scaleLineWidth : 1,
prompt
prompt  //Boolean - Whether to show labels on the scale  
prompt  scaleShowLabels : true,
prompt  
prompt  //Interpolated JS string - can access value
prompt  scaleLabel : "<%=value%>",
prompt  
prompt  //String - Scale label font declaration for the scale label
prompt  scaleFontFamily : "'Arial'",
prompt  
prompt  //Number - Scale label font size in pixels  
prompt  scaleFontSize : 12,
prompt  
prompt  //String - Scale label font weight style  
prompt  scaleFontStyle : "normal",
prompt  
prompt  //String - Scale label font colour  
prompt  scaleFontColor : "#666",  
prompt  
prompt  ///Boolean - Whether grid lines are shown across the chart
prompt  scaleShowGridLines : true,
prompt  
prompt  //String - Colour of the grid lines
prompt  scaleGridLineColor : "rgba(0,0,0,.05)",
prompt  
prompt  //Number - Width of the grid lines
prompt  scaleGridLineWidth : 1,  
prompt  
prompt  //Boolean - Whether the line is curved between points 
prompt  bezierCurve : false,
prompt  
prompt  //Boolean - Whether to show a dot for each point
prompt  pointDot : false,
prompt  
prompt  //Number - Radius of each point dot in pixels
prompt  pointDotRadius : 3,
prompt  
prompt  //Number - Pixel width of point dot stroke
prompt  pointDotStrokeWidth : 1,
prompt  
prompt  //Boolean - Whether to show a stroke for datasets
prompt  datasetStroke : true,
prompt  
prompt  //Number - Pixel width of dataset stroke
prompt  datasetStrokeWidth : 2,
prompt  
prompt  //Boolean - Whether to fill the dataset with a colour
prompt  datasetFill : true,
prompt  
prompt  //Boolean - Whether to animate the chart
prompt  animation : true,
prompt
prompt  //Number - Number of animation steps
prompt  animationSteps : 1,
prompt  
prompt  //String - Animation easing effect
prompt  animationEasing : "easeOutQuart",
prompt
prompt  //Function - Fires when the animation is complete
prompt  onAnimationComplete : null,
prompt      responsive: true
prompt    });

prompt  var ctx24 = document.getElementById("dirty-area").getContext("2d");
prompt    window.myLine = new Chart(ctx24).Line(dirtydata, {
prompt        scaleOverlay : false,
prompt  
prompt  //Boolean - If we want to override with a hard coded scale
prompt     scaleOverlay : false,
prompt  
prompt  //Boolean - If we want to override with a hard coded scale 
prompt  scaleOverride : false,
prompt  
prompt  
prompt  //Number - The number of steps in a hard coded scale  
prompt  scaleSteps : 10,
prompt  //Number - The value jump in the hard coded scale 
prompt  scaleStepWidth : 10,
prompt  //Number - The scale starting value 
prompt  scaleStartValue : 0,
prompt
prompt  //String - Colour of the scale line  
prompt  scaleLineColor : "rgba(0,0,0,.1)",
prompt  
prompt  //Number - Pixel width of the scale line  
prompt  scaleLineWidth : 1,
prompt
prompt  //Boolean - Whether to show labels on the scale  
prompt  scaleShowLabels : true,
prompt  
prompt  //Interpolated JS string - can access value
prompt  scaleLabel : "<%=value%>",
prompt  
prompt  //String - Scale label font declaration for the scale label
prompt  scaleFontFamily : "'Arial'",
prompt  
prompt  //Number - Scale label font size in pixels  
prompt  scaleFontSize : 12,
prompt  
prompt  //String - Scale label font weight style  
prompt  scaleFontStyle : "normal",
prompt  
prompt  //String - Scale label font colour  
prompt  scaleFontColor : "#666",  
prompt  
prompt  ///Boolean - Whether grid lines are shown across the chart
prompt  scaleShowGridLines : true,
prompt  
prompt  //String - Colour of the grid lines
prompt  scaleGridLineColor : "rgba(0,0,0,.05)",
prompt  
prompt  //Number - Width of the grid lines
prompt  scaleGridLineWidth : 1,  
prompt  
prompt  //Boolean - Whether the line is curved between points 
prompt  bezierCurve : false,
prompt  
prompt  //Boolean - Whether to show a dot for each point
prompt  pointDot : false,
prompt  
prompt  //Number - Radius of each point dot in pixels
prompt  pointDotRadius : 3,
prompt  
prompt  //Number - Pixel width of point dot stroke
prompt  pointDotStrokeWidth : 1,
prompt  
prompt  //Boolean - Whether to show a stroke for datasets
prompt  datasetStroke : true,
prompt  
prompt  //Number - Pixel width of dataset stroke
prompt  datasetStrokeWidth : 2,
prompt  
prompt  //Boolean - Whether to fill the dataset with a colour
prompt  datasetFill : true,
prompt  
prompt  //Boolean - Whether to animate the chart
prompt  animation : true,
prompt
prompt  //Number - Number of animation steps
prompt  animationSteps : 1,
prompt  
prompt  //String - Animation easing effect
prompt  animationEasing : "easeOutQuart",
prompt
prompt  //Function - Fires when the animation is complete
prompt  onAnimationComplete : null,
prompt      responsive: true
prompt    });

prompt  var ctx50 = document.getElementById("cellpredicate-area").getContext("2d");
prompt    window.myLine = new Chart(ctx50).Line(cellpredicatedata, {
prompt        scaleOverlay : false,
prompt  
prompt  //Boolean - If we want to override with a hard coded scale
prompt     scaleOverlay : false,
prompt  
prompt  //Boolean - If we want to override with a hard coded scale 
prompt  scaleOverride : false,
prompt  
prompt  
prompt  //Number - The number of steps in a hard coded scale  
prompt  scaleSteps : 10,
prompt  //Number - The value jump in the hard coded scale 
prompt  scaleStepWidth : 10,
prompt  //Number - The scale starting value 
prompt  scaleStartValue : 0,
prompt
prompt  //String - Colour of the scale line  
prompt  scaleLineColor : "rgba(0,0,0,.1)",
prompt  
prompt  //Number - Pixel width of the scale line  
prompt  scaleLineWidth : 1,
prompt
prompt  //Boolean - Whether to show labels on the scale  
prompt  scaleShowLabels : true,
prompt  
prompt  //Interpolated JS string - can access value
prompt  scaleLabel : "<%=value%>",
prompt  
prompt  //String - Scale label font declaration for the scale label
prompt  scaleFontFamily : "'Arial'",
prompt  
prompt  //Number - Scale label font size in pixels  
prompt  scaleFontSize : 12,
prompt  
prompt  //String - Scale label font weight style  
prompt  scaleFontStyle : "normal",
prompt  
prompt  //String - Scale label font colour  
prompt  scaleFontColor : "#666",  
prompt  
prompt  ///Boolean - Whether grid lines are shown across the chart
prompt  scaleShowGridLines : true,
prompt  
prompt  //String - Colour of the grid lines
prompt  scaleGridLineColor : "rgba(0,0,0,.05)",
prompt  
prompt  //Number - Width of the grid lines
prompt  scaleGridLineWidth : 1,  
prompt  
prompt  //Boolean - Whether the line is curved between points 
prompt  bezierCurve : false,
prompt  
prompt  //Boolean - Whether to show a dot for each point
prompt  pointDot : false,
prompt  
prompt  //Number - Radius of each point dot in pixels
prompt  pointDotRadius : 3,
prompt  
prompt  //Number - Pixel width of point dot stroke
prompt  pointDotStrokeWidth : 1,
prompt  
prompt  //Boolean - Whether to show a stroke for datasets
prompt  datasetStroke : true,
prompt  
prompt  //Number - Pixel width of dataset stroke
prompt  datasetStrokeWidth : 2,
prompt  
prompt  //Boolean - Whether to fill the dataset with a colour
prompt  datasetFill : true,
prompt  
prompt  //Boolean - Whether to animate the chart
prompt  animation : true,
prompt
prompt  //Number - Number of animation steps
prompt  animationSteps : 1,
prompt  
prompt  //String - Animation easing effect
prompt  animationEasing : "easeOutQuart",
prompt
prompt  //Function - Fires when the animation is complete
prompt  onAnimationComplete : null,
prompt      responsive: true
prompt    });

prompt  var ctx51 = document.getElementById("storageidx-area").getContext("2d");
prompt    window.myLine = new Chart(ctx51).Line(storageidxdata, {
prompt        scaleOverlay : false,
prompt  
prompt  //Boolean - If we want to override with a hard coded scale
prompt     scaleOverlay : false,
prompt  
prompt  //Boolean - If we want to override with a hard coded scale 
prompt  scaleOverride : false,
prompt  
prompt  
prompt  //Number - The number of steps in a hard coded scale  
prompt  scaleSteps : 10,
prompt  //Number - The value jump in the hard coded scale 
prompt  scaleStepWidth : 10,
prompt  //Number - The scale starting value 
prompt  scaleStartValue : 0,
prompt
prompt  //String - Colour of the scale line  
prompt  scaleLineColor : "rgba(0,0,0,.1)",
prompt  
prompt  //Number - Pixel width of the scale line  
prompt  scaleLineWidth : 1,
prompt
prompt  //Boolean - Whether to show labels on the scale  
prompt  scaleShowLabels : true,
prompt  
prompt  //Interpolated JS string - can access value
prompt  scaleLabel : "<%=value%>",
prompt  
prompt  //String - Scale label font declaration for the scale label
prompt  scaleFontFamily : "'Arial'",
prompt  
prompt  //Number - Scale label font size in pixels  
prompt  scaleFontSize : 12,
prompt  
prompt  //String - Scale label font weight style  
prompt  scaleFontStyle : "normal",
prompt  
prompt  //String - Scale label font colour  
prompt  scaleFontColor : "#666",  
prompt  
prompt  ///Boolean - Whether grid lines are shown across the chart
prompt  scaleShowGridLines : true,
prompt  
prompt  //String - Colour of the grid lines
prompt  scaleGridLineColor : "rgba(0,0,0,.05)",
prompt  
prompt  //Number - Width of the grid lines
prompt  scaleGridLineWidth : 1,  
prompt  
prompt  //Boolean - Whether the line is curved between points 
prompt  bezierCurve : false,
prompt  
prompt  //Boolean - Whether to show a dot for each point
prompt  pointDot : false,
prompt  
prompt  //Number - Radius of each point dot in pixels
prompt  pointDotRadius : 3,
prompt  
prompt  //Number - Pixel width of point dot stroke
prompt  pointDotStrokeWidth : 1,
prompt  
prompt  //Boolean - Whether to show a stroke for datasets
prompt  datasetStroke : true,
prompt  
prompt  //Number - Pixel width of dataset stroke
prompt  datasetStrokeWidth : 2,
prompt  
prompt  //Boolean - Whether to fill the dataset with a colour
prompt  datasetFill : true,
prompt  
prompt  //Boolean - Whether to animate the chart
prompt  animation : true,
prompt
prompt  //Number - Number of animation steps
prompt  animationSteps : 1,
prompt  
prompt  //String - Animation easing effect
prompt  animationEasing : "easeOutQuart",
prompt
prompt  //Function - Fires when the animation is complete
prompt  onAnimationComplete : null,
prompt      responsive: true
prompt    });

prompt  var ctx52 = document.getElementById("smart-area").getContext("2d");
prompt    window.myLine = new Chart(ctx52).Line(smartdata, {
prompt        scaleOverlay : false,
prompt  
prompt  //Boolean - If we want to override with a hard coded scale
prompt     scaleOverlay : false,
prompt  
prompt  //Boolean - If we want to override with a hard coded scale 
prompt  scaleOverride : false,
prompt  
prompt  
prompt  //Number - The number of steps in a hard coded scale  
prompt  scaleSteps : 10,
prompt  //Number - The value jump in the hard coded scale 
prompt  scaleStepWidth : 10,
prompt  //Number - The scale starting value 
prompt  scaleStartValue : 0,
prompt
prompt  //String - Colour of the scale line  
prompt  scaleLineColor : "rgba(0,0,0,.1)",
prompt  
prompt  //Number - Pixel width of the scale line  
prompt  scaleLineWidth : 1,
prompt
prompt  //Boolean - Whether to show labels on the scale  
prompt  scaleShowLabels : true,
prompt  
prompt  //Interpolated JS string - can access value
prompt  scaleLabel : "<%=value%>",
prompt  
prompt  //String - Scale label font declaration for the scale label
prompt  scaleFontFamily : "'Arial'",
prompt  
prompt  //Number - Scale label font size in pixels  
prompt  scaleFontSize : 12,
prompt  
prompt  //String - Scale label font weight style  
prompt  scaleFontStyle : "normal",
prompt  
prompt  //String - Scale label font colour  
prompt  scaleFontColor : "#666",  
prompt  
prompt  ///Boolean - Whether grid lines are shown across the chart
prompt  scaleShowGridLines : true,
prompt  
prompt  //String - Colour of the grid lines
prompt  scaleGridLineColor : "rgba(0,0,0,.05)",
prompt  
prompt  //Number - Width of the grid lines
prompt  scaleGridLineWidth : 1,  
prompt  
prompt  //Boolean - Whether the line is curved between points 
prompt  bezierCurve : false,
prompt  
prompt  //Boolean - Whether to show a dot for each point
prompt  pointDot : false,
prompt  
prompt  //Number - Radius of each point dot in pixels
prompt  pointDotRadius : 3,
prompt  
prompt  //Number - Pixel width of point dot stroke
prompt  pointDotStrokeWidth : 1,
prompt  
prompt  //Boolean - Whether to show a stroke for datasets
prompt  datasetStroke : true,
prompt  
prompt  //Number - Pixel width of dataset stroke
prompt  datasetStrokeWidth : 2,
prompt  
prompt  //Boolean - Whether to fill the dataset with a colour
prompt  datasetFill : true,
prompt  
prompt  //Boolean - Whether to animate the chart
prompt  animation : true,
prompt
prompt  //Number - Number of animation steps
prompt  animationSteps : 1,
prompt  
prompt  //String - Animation easing effect
prompt  animationEasing : "easeOutQuart",
prompt
prompt  //Function - Fires when the animation is complete
prompt  onAnimationComplete : null,
prompt      responsive: true
prompt    });

prompt  var ctx53 = document.getElementById("uncom-area").getContext("2d");
prompt    window.myLine = new Chart(ctx53).Line(uncomdata, {
prompt        scaleOverlay : false,
prompt  
prompt  //Boolean - If we want to override with a hard coded scale
prompt     scaleOverlay : false,
prompt  
prompt  //Boolean - If we want to override with a hard coded scale 
prompt  scaleOverride : false,
prompt  
prompt  
prompt  //Number - The number of steps in a hard coded scale  
prompt  scaleSteps : 10,
prompt  //Number - The value jump in the hard coded scale 
prompt  scaleStepWidth : 10,
prompt  //Number - The scale starting value 
prompt  scaleStartValue : 0,
prompt
prompt  //String - Colour of the scale line  
prompt  scaleLineColor : "rgba(0,0,0,.1)",
prompt  
prompt  //Number - Pixel width of the scale line  
prompt  scaleLineWidth : 1,
prompt
prompt  //Boolean - Whether to show labels on the scale  
prompt  scaleShowLabels : true,
prompt  
prompt  //Interpolated JS string - can access value
prompt  scaleLabel : "<%=value%>",
prompt  
prompt  //String - Scale label font declaration for the scale label
prompt  scaleFontFamily : "'Arial'",
prompt  
prompt  //Number - Scale label font size in pixels  
prompt  scaleFontSize : 12,
prompt  
prompt  //String - Scale label font weight style  
prompt  scaleFontStyle : "normal",
prompt  
prompt  //String - Scale label font colour  
prompt  scaleFontColor : "#666",  
prompt  
prompt  ///Boolean - Whether grid lines are shown across the chart
prompt  scaleShowGridLines : true,
prompt  
prompt  //String - Colour of the grid lines
prompt  scaleGridLineColor : "rgba(0,0,0,.05)",
prompt  
prompt  //Number - Width of the grid lines
prompt  scaleGridLineWidth : 1,  
prompt  
prompt  //Boolean - Whether the line is curved between points 
prompt  bezierCurve : false,
prompt  
prompt  //Boolean - Whether to show a dot for each point
prompt  pointDot : false,
prompt  
prompt  //Number - Radius of each point dot in pixels
prompt  pointDotRadius : 3,
prompt  
prompt  //Number - Pixel width of point dot stroke
prompt  pointDotStrokeWidth : 1,
prompt  
prompt  //Boolean - Whether to show a stroke for datasets
prompt  datasetStroke : true,
prompt  
prompt  //Number - Pixel width of dataset stroke
prompt  datasetStrokeWidth : 2,
prompt  
prompt  //Boolean - Whether to fill the dataset with a colour
prompt  datasetFill : true,
prompt  
prompt  //Boolean - Whether to animate the chart
prompt  animation : true,
prompt
prompt  //Number - Number of animation steps
prompt  animationSteps : 1,
prompt  
prompt  //String - Animation easing effect
prompt  animationEasing : "easeOutQuart",
prompt
prompt  //Function - Fires when the animation is complete
prompt  onAnimationComplete : null,
prompt      responsive: true
prompt    });

prompt       };
prompt   </script>
prompt <hr>
prompt     </p>

prompt The License of Awr Chart
prompt <br>
prompt Permission is hereby granted by Author, free of charge, to any person abotaining a copy of this software,
prompt <br>
prompt to deal in the software without restriction, including without limitation the rights to use,copy or distribute .
prompt <br>
prompt The copy right of Chart javascript belongs to its author Nick Downie (http://www.nickdownie.com/)  . This js is an open source project which
prompt <br>
prompt is under MIT license. 
prompt <br>
prompt Author : Wenjie Wang (Valen Wong) From 
prompt <H4 class='awr'>
prompt Oracle Advanced Customer Support 
prompt </H4>
prompt <br>
prompt You can reach me by send email to valen.wang@oracle.com
prompt <br>
prompt Version : 1.2
prompt <br>
prompt Date    : 2016-10
prompt </body>
prompt </html>
spool off
set termout       on
