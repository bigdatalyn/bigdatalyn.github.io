drop db srcdb;
drop db tgt1db;
drop db tgt2db;
drop db tgt3db;
drop db tgt4db;