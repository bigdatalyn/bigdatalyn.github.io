connect to srcdb user db2admin using db2admin;
update employee set workdept = 'D21' where empno = '111111';
terminate;