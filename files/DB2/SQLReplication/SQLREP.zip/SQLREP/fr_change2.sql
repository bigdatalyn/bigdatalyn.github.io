connect to srcdb user db2admin using db2admin;
update department set location = 'HAKOZAKI' where deptno = 'B01';
terminate;