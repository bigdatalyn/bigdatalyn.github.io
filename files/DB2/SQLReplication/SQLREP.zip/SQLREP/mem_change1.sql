connect to srcdb user db2admin using db2admin;
delete from org where deptnumb = 99;
insert into department values ('999','ISE','111111','D01',null);
terminate;