connect to srcdb user db2admin using db2admin;
update department set location = 'MAKUHARI' where deptno = 'A00';
terminate;