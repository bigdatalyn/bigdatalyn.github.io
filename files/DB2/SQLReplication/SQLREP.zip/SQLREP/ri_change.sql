update command options using c off ;

connect to srcdb user db2admin using db2admin;
insert into department values ('100','ISE','111111','D01',null);
insert into employee values ('111111','DB2ADMIN0','','DB2ADMIN','100','5432',current date,'MANAGER',20,'M',current date,0,0,0);
insert into employee values ('111112','DB2ADMIN1','','DB2ADMIN','100','5432',current date,'MANAGER',20,'M',current date,0,0,0);
insert into employee values ('111113','DB2ADMIN2','','DB2ADMIN','100','5432',current date,'MANAGER',20,'M',current date,0,0,0);
commit;
terminate;
