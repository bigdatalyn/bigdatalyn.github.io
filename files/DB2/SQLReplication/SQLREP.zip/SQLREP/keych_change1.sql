connect to srcdb user db2admin using db2admin;
update employee set empno = '111111' where empno = '000060';
terminate;