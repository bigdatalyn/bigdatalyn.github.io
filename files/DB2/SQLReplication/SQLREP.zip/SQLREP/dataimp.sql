connect to srcdb;
import from c:\sqlrep\employee.ixf of ixf create into employee;
import from c:\sqlrep\sales.ixf of ixf create into sales;
import from c:\sqlrep\project.ixf of ixf create into project;
import from c:\sqlrep\department.ixf of ixf create into department;
import from c:\sqlrep\staff.ixf of ixf create into staff;
import from c:\sqlrep\org.ixf of ixf create into org;
terminate;