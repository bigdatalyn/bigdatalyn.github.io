connect to srcdb user db2admin using db2admin;
alter table employee foreign key (workdept) references department (deptno) on delete cascade;
terminate;