connect to srcdb user db2admin using db2admin;
insert into org values (99,'ISE',300,'Midwest','MAKUHARI');
update org set location = 'HAKOZAKI' where deptnumb = 99;
delete from org where deptnumb = 84;
terminate;