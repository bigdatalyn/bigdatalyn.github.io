connect to srcdb user db2admin using db2admin;
insert into db2admin.sales values ('2000-01-01','DB2ADMIN','MAKUHARI',20);
update db2admin.sales set sales = 50 where sales_date = '2000-01-01';
delete from db2admin.sales where sales_date = '2000-01-01';
connect to srcdb user repladmin using repladmin;
insert into db2admin.sales values ('2000-02-01','REPLADMIN','MKUHARI',99);
terminate;