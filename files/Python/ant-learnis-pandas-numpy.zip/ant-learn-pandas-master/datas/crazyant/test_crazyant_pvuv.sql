use test;

CREATE TABLE `crazyant_pvuv` (
  `pdate` varchar(100) DEFAULT NULL,
  `pv` bigint(20) DEFAULT NULL,
  `uv` bigint(20) DEFAULT NULL
) ENGINE=InnoDB;

INSERT INTO crazyant_pvuv (pdate, pv, uv) VALUES ('2019-09-10', 139, 92);
INSERT INTO crazyant_pvuv (pdate, pv, uv) VALUES ('2019-09-09', 185, 153);
INSERT INTO crazyant_pvuv (pdate, pv, uv) VALUES ('2019-09-08', 123, 59);
INSERT INTO crazyant_pvuv (pdate, pv, uv) VALUES ('2019-09-07', 65, 40);
INSERT INTO crazyant_pvuv (pdate, pv, uv) VALUES ('2019-09-06', 157, 98);
INSERT INTO crazyant_pvuv (pdate, pv, uv) VALUES ('2019-09-05', 205, 151);
INSERT INTO crazyant_pvuv (pdate, pv, uv) VALUES ('2019-09-04', 196, 167);
INSERT INTO crazyant_pvuv (pdate, pv, uv) VALUES ('2019-09-03', 216, 176);
INSERT INTO crazyant_pvuv (pdate, pv, uv) VALUES ('2019-09-02', 227, 148);
INSERT INTO crazyant_pvuv (pdate, pv, uv) VALUES ('2019-09-01', 105, 61);
