 ========================================================================
 =======             DBeaver Enterprise License Crack             =======
 =======                     https://zhile.io                     =======
 =======              v1.0.0, Build Date: 2019-05-08              =======
 ========================================================================

 本项目在DBeaver Enterprise 6.0上测试通过（简称DBeaverEE）

 使用方法:
 0. 先安装DBeaverEE。
 1. 先下载压缩包解压后得到dbeaver-agent.jar，把它放到你认为合适的文件夹内。
    下载页面：https://zhile.io/2019/05/08/dbeaver-license-crack.html
 2. 在DBeaverEE安装目录下找到Eclipse\dbeaver.ini文件
 3. 在打开的dbeaver.ini编辑窗口末行添加："-javaagent:/absolute/path/to/dbeaver-agent.jar"
    一定要自己确认好路径，填错会导致DBeaverEE打不开！！！最好使用绝对路径。
    示例:
      mac:      -javaagent:/Users/neo/dbeaver-agent.jar
      linux:    -javaagent:/home/neo/dbeaver-agent.jar
      windows:  -javaagent:C:\Users\neo\dbeaver-agent.jar
 4. 启动DBeaverEE即可。
 5. 如果提示错误: 
    "Error opening zip file or JAR manifest missing : dbeaver-agent.jar"
    这种情况请试着填上jar文件的绝对路径.

 本项目只做学习研究之用，不得用于商业用途！
 若资金允许，请购买正版，谢谢合作！

