#!/bin/sh
# ***********************************************************************
# Licensed Materials - Property of IBM
# IBM Cognos Products: DOCS
# (C) Copyright IBM Corp. 2010, 2012
# US Government Users Restricted Rights - Use, duplication or disclosure 
# restricted by GSA ADP Schedule Contract with IBM Corp.
# ***********************************************************************
#  SetupGSDB.sh
#
# This script accepts the following optional parameters in order
# to allow for automation :
#   -createdb          => creates the database, bufferpools and tablespaces
#                         assumption is made that a userid with permission
#                         to create a database is running this script.
#                         This option will drop any existing database with
#                         the same name before creating the database
#   -database <name>   => overrides the database name
#   -userid <admin userid> => overrides the administrative userid
#   -password <admin passwd> => sets the password for the administrative
#                         userid
#   -noprompt          => indicates that the user should not be prompted
#                         for any information
#   -addComments       => Will only add table comments to existing tables.
#   
#
# Notes
#
# 1) If any of the command line arguments are used, then the script
#    will not prompt the user to confirm information with the exception
#    that if the -userid parameter is used without the -password
#    parameter, the user will be prompted for the password
#
#
#
#
####################################################################

echo "Starting script"

GOSALES_PARENT_DIR=`pwd`
GOSALES_SCRIPT_DIR="${GOSALES_PARENT_DIR}/GS_SCRIPTS"
GOSALES_START=1

#Change to script directory
cd "${GOSALES_SCRIPT_DIR}"

# Call the main run script 
. ./RUN_GOSALES_IMPORT_BLU.sh $*

cd ..
