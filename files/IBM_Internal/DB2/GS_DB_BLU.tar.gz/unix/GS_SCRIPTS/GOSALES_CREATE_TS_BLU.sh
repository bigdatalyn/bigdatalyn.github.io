#!/bin/sh
# ***********************************************************************
# Licensed Materials - Property of IBM
# IBM Cognos Products: DOCS
# (C) Copyright IBM Corp. 2010, 2012
# US Government Users Restricted Rights - Use, duplication or disclosure 
# restricted by GSA ADP Schedule Contract with IBM Corp.
# ***********************************************************************
echo "-- ***********************************************************************"
echo "-- Licensed Materials - Property of IBM "
echo "-- IBM Cognos Products: DOCS "
echo "-- \(C\) Copyright IBM Corp. 2010, 2012 "
echo "-- US Government Users Restricted Rights - Use, duplication or disclosure  "
echo "-- restricted by GSA ADP Schedule Contract with IBM Corp. "
echo "-- *********************************************************************** "
echo "--"
echo ------------------------------------------------
echo -- CREATE THE "${GOSALES_BP}" BUFFERPOOL
echo ------------------------------------------------
echo
echo CREATE BUFFERPOOL "${GOSALES_BP}" IMMEDIATE SIZE 250 AUTOMATIC PAGESIZE 32 K
echo @
echo ------------------------------------------------
echo -- CREATE THE "${GOSALES_TS}" TABLESPACE
echo ------------------------------------------------
echo
echo CREATE REGULAR TABLESPACE \"${GOSALES_TS}\" PAGESIZE 32 K BUFFERPOOL ${GOSALES_BP}
echo @
echo
