#!/bin/sh
# ***********************************************************************
# Licensed Materials - Property of IBM
# IBM Cognos Products: DOCS
# (C) Copyright IBM Corp. 2010, 2012
# US Government Users Restricted Rights - Use, duplication or disclosure 
# restricted by GSA ADP Schedule Contract with IBM Corp.
# ***********************************************************************

#########################################################################
# Utility functions
#########################################################################

terminate()
{
   case $1 in
      MISSING_VALUE)
          echo "Missing value - you can assign default values in GOSalesConfig.sh" ;;

      EDIT_SCHEMAS)
          echo "You can edit the schema names in the file GOSalesConfig.sh" ;;

      NORESPONSE)
          echo "No value was provided for a required field" ;;

      UNKNOWN_ARGUMENT)
	  echo "Unknown argument $GOSALES_ARG " ;;

      *)
          echo "Exiting in error - see logs" ;;
   esac

   cleanup 1
}



cleanup()
{
   if [ -f "${GOSALES_ERROR_LOG}" ] ; then
      echo ""
      echo "GOSALES SAMPLE DATABASE SETUP ERRORS:"
      echo "(Please check the log files for more details)"
      echo "Log directory: ${GOSALES_LOG_DIR}"
      echo ---------------------------------------------
      echo ""
      cat "${GOSALES_ERROR_LOG}"
      echo ""
      echo Exiting script.  rc=$1
   fi

   exit $1
}

displaySummary()
{

  echo
  echo -----------------------------------------------------------
  echo
  
  if [ "${GOSALES_PROMPTS}" = "Y" ] ; then
    #################################################################
    # Display the summary and get a final confirmation before starting
    #################################################################

    echo Please confirm the following settings :
    echo
  else
    echo This is the configuration for the database setup :
    echo
  fi

  echo "Database Name                      : ${GOSALES_INST}"
  echo "Drop and Recreate database    : ${GOSALES_CREATEDB}"
  echo "DPF environment                    : ${GOSALES_DPF}"

  if [ "${GOSALES_CREATE_BP_AND_TS}" = "Y" ] ; then
     echo "Create a 32k Bufferpool named : ${GOSALES_BP}"
     echo "Create a 32k Tablespace named : ${GOSALES_TS}"
  fi
  echo "Grant permissions on the GOSALES objects to   : ${GOSALES_GRANTEES}"
  echo "Grant permissions on the GOSALESDW objects to : ${GOSALESDW_GRANTEES}"
  echo "DB2 Administration User name  : ${GOSALES_ADMIN_USERNAME}"

  if [ "${GOSALES_ONLY_GENERATE_SQL}" = "Y" ] ; then
    echo "Only generate the SQL files   : ${GOSALES_ONLY_GENERATE_SQL}"
  fi
  if [ "${GOSALES_ONLY_VERIFY}" = "Y" ] ; then
    echo "Only verify row counts        : ${GOSALES_ONLY_VERIFY}"
  fi
  echo
  if [ "${GOSALES_SKIP_IMPORT}" = "Y" ] ; then
     echo "Use the following schemas but do not import the sample data:"
  else
     echo "Import the sample data into the following schemas :"
  fi

  echo "       ${GOSALES_SCHEMA}"
  echo "       ${GOSALESHR_SCHEMA}"
  echo "       ${GOSALESMR_SCHEMA}"
  echo "       ${GOSALESRT_SCHEMA}"
  echo "       ${GOSALESDW_SCHEMA}"
  echo

  if [ "${GOSALES_CLEAN}" = "Y" ] ; then
    echo "WARNING: Existing objects in the schemas listed above will be dropped"
    echo
  fi
  if [ "${GOSALES_CREATEDB}" = "Y" ] ; then
    echo WARNING: If the database ${GOSALES_DB} already exists it will be dropped
    echo
  fi
}

# Set variables based on the DB2 version
getDB2SupportLevel()
{
   GOSALES_DB2LEVEL=`db2level | grep -c "DB2 v8."`

   if [ "${GOSALES_DB2LEVEL}" = "1" ] ; then
       # Versions 8.1 and 8.2 - do not use automatic storage
       echo DB2 Version 8 detected - using DB2 Version 8 syntax
       GOSALES_DB_CREATE_AUTO_STORAGE=""
       GOSALES_DB_PAGESIZE=""
       GOSALES_XML_SUPPORT="N"
   else
       # Make the current version the default
       # Versions 9.1, 9.5 and 9.5 support automatic storage
       echo DB2 Version 9 or later detected - using DB2 Version 9 syntax
       GOSALES_DB_CREATE_AUTO_STORAGE="AUTOMATIC STORAGE YES"
       GOSALES_DB_PAGESIZE="pagesize 32 K"
       GOSALES_XML_SUPPORT="Y"
   fi
}


#########################################################################
# Main script logic starts here
# - verify the script was called correctly
#########################################################################

if [ "${GOSALES_START}" != "1" ] ; then
   echo This script must be called from setupGSDB.sh - Quitting
   exit 1
fi


#########################################################################
# Call the file containing the instance, usernames and schema variables
#########################################################################
. "${GOSALES_PARENT_DIR}/GOSalesConfig.sh"


#########################################################################
# Get the operating system level
# AIX doesn't need the -e option to process the \c, but Linux does
#########################################################################
GOSALES_OS=`uname`
GOSALES_ECHO_PROMPT="-e"
echo Operating system : ${GOSALES_OS}
if [ "${GOSALES_OS}" = "AIX" ] ; then
  GOSALES_ECHO_PROMPT=""
fi
if [ "${GOSALES_OS}" = "HP-UX" ] ; then
  GOSALES_ECHO_PROMPT=""
fi
if [ "${GOSALES_OS}" = "SunOS" ] ; then
  GOSALES_ECHO_PROMPT=""
fi
#########################################################################
# Process the command line arguments
#########################################################################

GOSALES_PROMPTS="Y"
GOSALES_CREATE_BP_AND_TS="N"
GOSALES_ONLY_GENERATE_SQL="N"
GOSALES_CLEAN="Y"
GOSALES_ONLY_VERIFY="N"
GOSALES_ONLY_COMMENTS="N"
GOSALES_NODENAME=""
GOSALES_SKIP_IMPORT="N"
GOSALES_DISPLAY="Y"

echo

while [ $# -ge 1 ]; do
    # Convert to lowercase
    GOSALES_ARG=`echo $1 | tr '[:upper:]' '[:lower:]'`
    case $GOSALES_ARG in
      -createdb)
          GOSALES_CREATEDB="Y" ;;
      -database)
          shift
          if [ "$1" != "" ] ; then GOSALES_INST=$1; fi; ;;
#      -node)
#          shift
#          if [ "$1" != "" ] ; then GOSALES_NODENAME=$1; fi ;;
      -userid)
          shift
          if [ "$1" != "" ] ; then GOSALES_ADMIN_USERNAME=$1; fi ;;
      -password)
          shift
          if [ "$1" != "" ] ; then GOSALES_ADMIN_PASSWORD=$1; fi ;;
      -noprompt)
          GOSALES_PROMPTS="N" ;;
      -gensql)
          GOSALES_ONLY_GENERATE_SQL="Y" ;;
      -addcomments)
          GOSALES_ONLY_COMMENTS="Y" ;;
      -verify)
          GOSALES_ONLY_VERIFY="Y" ;;
      -noimport)
          GOSALES_SKIP_IMPORT="Y" ;;
      *)
          terminate UNKNOWN_ARGUMENT ;;
    esac
    shift
done

#########################################################################
# Set up directory variables
#########################################################################
GOSALES_CURRENT_DIR=`pwd`
GOSALES_IMPORT_FILE_DIR=${GOSALES_PARENT_DIR}/../data/
GOSALES_LOG_DIR=${GOSALES_PARENT_DIR}/../logs/
GOSALES_ERROR_LOG=${GOSALES_LOG_DIR}/GOSALES_ERROR_LOG.LOG

mkdir "${GOSALES_LOG_DIR}" > /dev/null 2>&1

#########################################################################
# Delete existing log files
#########################################################################
cd "${GOSALES_LOG_DIR}"
rm -f GOSALES*.LOG > /dev/null 2>&1
cd "${GOSALES_CURRENT_DIR}"

#########################################################################
# Change the LOAD command to IMPORT in a DPF environment
#########################################################################
case ${GOSALES_DPF} in
Y|y) GOSALES_DPF="Y" ;;
*) GOSALES_DPF="N" ;;
esac

if [ "${GOSALES_DPF}" = "Y" ] ; then
   GOSALES_LOAD_CMD="IMPORT"
else
   GOSALES_LOAD_CMD="LOAD"
fi



#########################################################################
# Get the database level which is used to set the AUTOMATIC STORAGE
# option for a CREATE DATABASE
#########################################################################

getDB2SupportLevel;

########################################################################
# If only adding comments, get the username and skip prompts
########################################################################
if [ "${GOSALES_ONLY_COMMENTS}" = "Y" ] ; then
   GOSALES_CREATEDB="N"
   GOSALES_CREATE_BP_AND_TS="N"
   GOSALES_CLEAN="N"
   GOSALES_PROMPTS="N"
   GOSALES_DISPLAY="N"
   
   #################################################################
   # Display database name
   #################################################################
   echo
   echo "Only add table comments:"
   echo "Database:    ${GOSALES_INST}"

   #################################################################
   # Prompt for the username to use to add the table comments
   #################################################################
   if [ "${GOSALES_ADMIN_USERNAME}" = "" ] ; then
      echo
      echo Enter the db2 administration username to use for adding  
      echo the table comments. 
      echo ${GOSALES_ECHO_PROMPT} "Please enter the DB2 admin user name : \c"
      read GOSALES_ADMIN_USERNAME
   fi
fi;

########################################################################
# If only verifying row counts, get the username and skip prompts
########################################################################
if [ "${GOSALES_ONLY_VERIFY}" = "Y" ] ; then
   GOSALES_CREATEDB="N"
   GOSALES_CREATE_BP_AND_TS="N"
   GOSALES_CLEAN="N"
   GOSALES_PROMPTS="N"
   GOSALES_DISPLAY="N"
   
   #################################################################
   # Display database name
   #################################################################
   echo
   echo "Only verify row counts:"
   echo "Database:    ${GOSALES_INST}"

   #################################################################
   # Prompt for the username to use to add the table comments
   #################################################################
   if [ "${GOSALES_ADMIN_USERNAME}" = "" ] ; then
      echo
      echo Enter the db2 administration username to use for verifying  
      echo the row counts. 
      echo ${GOSALES_ECHO_PROMPT} "Please enter the DB2 admin user name : \c"
      read GOSALES_ADMIN_USERNAME
   fi
fi;

if [ "${GOSALES_PROMPTS}" = "Y" ] ; then

   echo -------------------------------------------------------------------
   echo "Press Enter at the prompts to accept the default value shown"
   echo "Default values can be specifed in the file GOSalesConfig.sh"
   echo ""
   if [ "${GOSALES_ONLY_GENERATE_SQL}" = "Y" ] ; then
       echo "Please provide values required to generate the sql files. "
       echo "(SQL will not be executed)"
       echo ""
   fi

   echo -------------------------------------------------------------------
   echo "Please enter the name of the database ( or the alias ) to be used for the"
   echo ${GOSALES_ECHO_PROMPT} "GOSales sample data (default=${GOSALES_INST}) : \c"
   read GOSALES_USERINPUT
   if [ "${GOSALES_USERINPUT}" != "" ] ; then
      GOSALES_INST=${GOSALES_USERINPUT}
   fi

   if [ "${GOSALES_ONLY_COMMENTS}" = "Y" ] ; then
      GOSALES_CREATEDB="N"
      GOSALES_CREATE_BP_AND_TS="N"
   fi

   if [ "${GOSALES_CREATEDB}" = "" ] ; then
      echo ""
      echo -------------------------------------------------------------------
      echo This script can create the ${GOSALES_INST} database.  Creating the database
      echo will cause any existing databases with the same name to be dropped.
      echo ${GOSALES_ECHO_PROMPT} "Would you like to create the database ${GOSALES_INST}? (Y/N) Default=Y : \c"
      read GOSALES_CREATEDB
      case ${GOSALES_CREATEDB} in
         Y|y|"") GOSALES_CREATEDB="Y" ;;
              *) GOSALES_CREATEDB="N" ;;
      esac
   fi

#   if [ "${GOSALES_CREATEDB}" = "Y" ] ; then
#      if [ "${GOSALES_NODENAME}" = "" ] ; then
#         # Prompt the user for the NODE
#         echo ""
#         echo -------------------------------------------------------------------
#         echo Please enter the NODE name that will contain the database.  If you are
#         echo logged in as a DB2 administrator you do not need to provide a NODE
#         echo name and the local node will be used.
#         echo ${GOSALES_ECHO_PROMPT} "Enter the NODE name (or leave empty for local node) : \c"
#         read GOSALES_NODENAME
#      fi
#   fi

   ############################################
   #Check if the values are all set
   ############################################
   if [ "${GOSALES_INST}" = "" ] ; then
      echo ${GOSALES_ECHO_PROMPT} "Missing value(GOSALES_INST) \n => Enter a value for the DB2 database name: \c"
      read GOSALES_INST;
      if [ "${GOSALES_INST}" = "" ] ; then terminate MISSING_VALUE;  fi;
   fi

   if [ "${GOSALES_GRANTEES}" = "" ] ; then
      echo ${GOSALES_ECHO_PROMPT} "Missing value ( GOSALES_GRANTEES ) \n => Enter the "GRANT TO" option for the GOSALES schema: \c"
      read GOSALES_GRANTEES;
      if [ "${GOSALES_GRANTEES}" = "" ] ; then terminate MISSING_VALUE;  fi;
   fi

   if [ "${GOSALESDW_GRANTEES}" = "" ] ; then
      echo ${GOSALES_ECHO_PROMPT} "Missing value ( GOSALESDW_GRANTEES ) \n => Enter the "GRANT TO" option for the GOSALESDW schema: \c"
      read GOSALESDW_GRANTEES;
      if [ "${GOSALESDW_GRANTEES}" = "" ] ; then terminate MISSING_VALUE;  fi;
   fi

   if [ "${GOSALES_SCHEMA}" = "" ] ; then
      echo ${GOSALES_ECHO_PROMPT} "Missing value ( GOSALES_SCHEMA ) \n => Enter a name for the GOSALES schema: \c"
      read GOSALES_SCHEMA;
      if [ "${GOSALES_SCHEMA}" = "" ] ; then terminate MISSING_VALUE;  fi;
   fi

   if [ "${GOSALESHR_SCHEMA}" = "" ] ; then
      echo ${GOSALES_ECHO_PROMPT} "Missing value ( GOSALESHR_SCHEMA ) \n => Enter a name for the GOSALESHR schema: \c"
      read GOSALESHR_SCHEMA;
      if [ "${GOSALESHR_SCHEMA}" = "" ] ; then terminate MISSING_VALUE;  fi;
   fi

   if [ "${GOSALESMR_SCHEMA}" = "" ] ; then
      echo ${GOSALES_ECHO_PROMPT} "Missing value ( GOSALESMR_SCHEMA ) \n => Enter a name for the GOSALESMR schema: \c"
      read GOSALESMR_SCHEMA;
      if [ "${GOSALESMR_SCHEMA}" = "" ] ; then terminate MISSING_VALUE;  fi;
   fi

   if [ "${GOSALESRT_SCHEMA}" = "" ] ; then
      echo ${GOSALES_ECHO_PROMPT} "Missing value ( GOSALESRT_SCHEMA ) \n => Enter a name for the GOSALESRT schema: \c"
      read GOSALESRT_SCHEMA;
      if [ "${GOSALESRT_SCHEMA}" = "" ] ; then terminate MISSING_VALUE;  fi;
   fi

   if [ "${GOSALESDW_SCHEMA}" = "" ] ; then
      echo ${GOSALES_ECHO_PROMPT} "Missing value ( GOSALESDW_SCHEMA ) \n => Enter a name for the GOSALESDW schema: \c"
      read GOSALESDW_SCHEMA;
      if [ "${GOSALESDW_SCHEMA}" = "" ] ; then terminate MISSING_VALUE;  fi;
   fi
else
   # if GOSALES_PROMPTS = N
   if [ "${GOSALES_CREATEDB}" = "" ] ; then
      GOSALES_CREATEDB="N";
   fi
fi


###########################################################################
#Skip the prompts if the user provided the information in GOSalesConfig.sh
############################################################################

if [ "${GOSALES_PROMPTS}" = "Y" ] ; then

   #################################################################
   # Test for the existence of an existing database.  If a database do not
   # exist then we will get a SQL1013 error.  Any other error or
   # success indicates the database exists
   #################################################################
   if [ "${GOSALES_CREATEDB}" = "Y" ] ; then
      connectResult=`db2 connect to ${GOSALES_INST}`
      case $connectResult in
         SQL1013N*) ;;
           *)
            echo
            # echo Connect Result : ${connectResult}
            echo The database ${GOSALES_INST} already exists and will be dropped.
            echo ${GOSALES_ECHO_PROMPT} "Are you sure you want to drop the existing database? (Y/N) Default=Y: \c"
            read GOSALES_CREATEDB
            case ${GOSALES_CREATEDB} in
               Y|y|"") GOSALES_CREATEDB="Y" ;;
                    *) GOSALES_CREATEDB="N" ;;
            esac ;;
      esac
   fi
   db2 connect reset > /dev/null  2>&1

   if [ "${GOSALES_ONLY_COMMENTS}" = "N" ] ; then

     #################################################################
     # Ask if user wants to create the buffer pool and tablespaces
     # Only prompt if we are not already creating the database
     #################################################################

     GOSALES_CREATE_BP_AND_TS="Y"
     if [ "${GOSALES_CREATEDB}" = "N" ] ; then
        echo
        echo To import the data the database needs to contain a 16K bufferpool
        echo and tablespace. Do you want to create the buffer pool and
        echo ${GOSALES_ECHO_PROMPT} "tablespace now? (Y/N) Default=Y : \c"
        read GOSALES_CREATE_BP_AND_TS;
        case ${GOSALES_CREATE_BP_AND_TS} in
           Y|y|"") GOSALES_CREATE_BP_AND_TS="Y" ;;
                *) GOSALES_CREATE_BP_AND_TS="N" ;;
        esac
     fi
   fi

    if [ "${GOSALES_CREATE_BP_AND_TS}" = "Y" ] ; then
      # Ensure we have a name for the buffer pool
      if [ "${GOSALES_BP}" = "" ] ; then
         echo
         echo ${GOSALES_ECHO_PROMPT} "Enter the name for the new buffer pool : \c"
         read GOSALES_BP
         if [ "${GOSALES_BP}" = "" ] ; then terminate MISSING_VALUE; fi;
      fi

      # Ensure we have a name for the table space
      if [ "${GOSALES_TS}" = "" ] ; then
         echo
         echo ${GOSALES_ECHO_PROMPT} "Enter the name for the new table space : \c"
         read GOSALES_TS
         if [ "${GOSALES_TS}" = "" ] ; then terminate MISSING_VALUE; fi;
      fi
   fi

   #################################################################
   # Prompt for the username to use to run import
   #################################################################
   if [ "${GOSALES_ADMIN_USERNAME}" = "" ] ; then
      echo
      if [ "${GOSALES_ONLY_COMMENTS}" = "Y" ] ; then
        echo Enter the db2 administration username for adding the table
        echo comments.
      else
        echo Enter the db2 administration username for creating the database
        echo and importing the data. 
      fi
      echo If no value is provided, then the local
      echo user will attempt to connect without a password.
      echo ${GOSALES_ECHO_PROMPT} "Please enter the DB2 admin user name : \c"
      read GOSALES_ADMIN_USERNAME
   fi


   #################################################################
   # Display the summary and get a final confirmation before starting
   #################################################################

   echo
   echo -----------------------------------------------------------
   echo
   echo Please confirm the following settings :
   echo
else
   echo This is the configuration for the database setup :
   echo
fi

if [ "${GOSALES_CREATEDB}" = "Y" ] ; then
   GOSALES_CREATE_BP_AND_TS="Y"
   GOSALES_CLEAN="N"
fi;


if [ "${GOSALES_ONLY_GENERATE_SQL}" = "Y" ] ; then
   echo "Only generating the SQL files : ${GOSALES_ONLY_GENERATE_SQL}"
fi
if [ "${GOSALES_ONLY_COMMENTS}" = "Y" ] ; then
   echo "Only adding table comments    : ${GOSALES_ONLY_COMMENTS}"
   GOSALES_DISPLAY="N"
fi
if [ "${GOSALES_ONLY_VERIFY}" = "Y" ] ; then
   echo "Only verifying row counts     : ${GOSALES_ONLY_VERIFY}"
   GOSALES_DISPLAY="N"
fi

echo "Database Name                 : ${GOSALES_INST}"
if [ "${GOSALES_DISPLAY}" = "Y" ] ; then
  echo "Drop and Recreate database    : ${GOSALES_CREATEDB}"

  if [ "${GOSALES_NODENAME}" != "" ] ; then
     echo "Node Name                     : ${GOSALES_NODENAME}"
  fi

  if [ "${GOSALES_CREATE_BP_AND_TS}" = "Y" ] ; then
     echo "Create a 16k Bufferpool named : ${GOSALES_BP}"
     echo "Create a 16k Tablespace named : ${GOSALES_TS}"
  fi

  echo "GOSALES   Grant users/groups  : ${GOSALES_GRANTEES}"
  echo "GOSALESDW Grant users/groups  : ${GOSALESDW_GRANTEES}"
  echo "Administration User name      : ${GOSALES_ADMIN_USERNAME}"

  echo

  if [ "${GOSALES_SKIP_IMPORT}" = "Y" ] ; then
     echo "Data will NOT be imported into the following schemas :"
  else
     echo "Import the sample data into the following schemas :"
  fi

else
     echo "Schema list: "
fi

echo "       ${GOSALES_SCHEMA}"
echo "       ${GOSALESHR_SCHEMA}"
echo "       ${GOSALESMR_SCHEMA}"
echo "       ${GOSALESRT_SCHEMA}"
echo "       ${GOSALESDW_SCHEMA}"
echo
echo ============================
if [ "${GOSALES_DISPLAY}" = "Y" ] ; then
	displaySummary
fi;

if [ "${GOSALES_PROMPTS}" = "Y" ] ; then
  if [ "${GOSALES_ONLY_GENERATE_SQL}" = "N" ] ; then
    echo ${GOSALES_ECHO_PROMPT} "Continue creating the sample data with these settings? (Y/N) Default=Y :\c"
  else
    echo ${GOSALES_ECHO_PROMPT} "Generate but do not execute the sql for these settings? (Y/N) Default=Y :\c"
  fi;

   read GOSALES_USER_RESPONSE
   case ${GOSALES_USER_RESPONSE} in
      Y|y|"") echo "" ;;
           *) terminate USER_EXIT ;;
   esac

fi

echo Please wait ...
echo

################################################
# Create the sql files by running the batch files
################################################

if [ "${GOSALES_CREATEDB}" = "Y" -a -f GOSALES_CREATE_DB.sh ] ; then
   . ./GOSALES_CREATE_DB.sh > GOSALES_CREATE_DB.SQL
fi

if [ "${GOSALES_CREATE_BP_AND_TS}" = "Y" -a -f GOSALES_CREATE_TS_BLU.sh ] ; then
   . ./GOSALES_CREATE_TS_BLU.sh > GOSALES_CREATE_TS.SQL
fi

#TABLES
if [ -f GOSALES_TABLES.sh ] ; then . ./GOSALES_TABLES.sh > GOSALES_TABLES.SQL ; fi;
if [ -f GOSALESHR_TABLES.sh ] ; then . ./GOSALESHR_TABLES.sh > GOSALESHR_TABLES.SQL ; fi;
if [ -f GOSALESMR_TABLES.sh ] ; then . ./GOSALESMR_TABLES.sh > GOSALESMR_TABLES.SQL ; fi;
if [ -f GOSALESRT_TABLES.sh ] ; then . ./GOSALESRT_TABLES.sh > GOSALESRT_TABLES.SQL ; fi;
if [ -f GOSALESDW_TABLES.sh ] ; then . ./GOSALESDW_TABLES.sh > GOSALESDW_TABLES.SQL ; fi;

#LOAD THE TABLES
. ./GOSALES_LOAD.sh > GOSALES_LOAD.SQL

#DROP TABLES
. ./GOSALES_DROP.sh 
#GRANTS
if [ -f GOSALES_GRANTS.sh ] ; then . ./GOSALES_GRANTS.sh > GOSALES_GRANTS.SQL ; fi;
if [ -f GOSALESHR_GRANTS.sh ] ; then . ./GOSALESHR_GRANTS.sh > GOSALESHR_GRANTS.SQL ; fi;
if [ -f GOSALESMR_GRANTS.sh ] ; then . ./GOSALESMR_GRANTS.sh > GOSALESMR_GRANTS.SQL ; fi;
if [ -f GOSALESRT_GRANTS.sh ] ; then . ./GOSALESRT_GRANTS.sh > GOSALESRT_GRANTS.SQL ; fi;
if [ -f GOSALESDW_GRANTS.sh ] ; then . ./GOSALESDW_GRANTS.sh > GOSALESDW_GRANTS.SQL ; fi;

#PRIMARY KEYS
if [ -f GOSALES_PK.sh ] ; then . ./GOSALES_PK.sh > GOSALES_PK.SQL ; fi;
if [ -f GOSALESHR_PK.sh ] ; then . ./GOSALESHR_PK.sh > GOSALESHR_PK.SQL ; fi;
if [ -f GOSALESMR_PK.sh ] ; then . ./GOSALESMR_PK.sh > GOSALESMR_PK.SQL ; fi;
if [ -f GOSALESRT_PK.sh ] ; then . ./GOSALESRT_PK.sh > GOSALESRT_PK.SQL ; fi;
if [ -f GOSALESDW_PK.sh ] ; then . ./GOSALESDW_PK.sh > GOSALESDW_PK.SQL ; fi;

#INDEXES
#if [ -f GOSALES_INDEXES.sh ] ; then . ./GOSALES_INDEXES.sh > GOSALES_INDEXES.SQL ; fi;
#if [ -f GOSALESHR_INDEXES.sh ] ; then . ./GOSALESHR_INDEXES.sh > GOSALESHR_INDEXES.SQL ; fi;
#if [ -f GOSALESMR_INDEXES.sh ] ; then . ./GOSALESMR_INDEXES.sh > GOSALESMR_INDEXES.SQL ; fi;
#if [ -f GOSALESRT_INDEXES.sh ] ; then . ./GOSALESRT_INDEXES.sh > GOSALESRT_INDEXES.SQL ; fi;
#if [ -f GOSALESDW_INDEXES.sh ] ; then . ./GOSALESDW_INDEXES.sh > GOSALESDW_INDEXES.SQL ; fi;

#CONSTRAINTS
if [ -f GOSALES_CONSTRAINTS_BLU.sh ] ; then . ./GOSALES_CONSTRAINTS_BLU.sh > GOSALES_CONSTRAINTS.SQL ; fi;
if [ -f GOSALESHR_CONSTRAINTS_BLU.sh ] ; then . ./GOSALESHR_CONSTRAINTS_BLU.sh > GOSALESHR_CONSTRAINTS.SQL ; fi;
if [ -f GOSALESMR_CONSTRAINTS_BLU.sh ] ; then . ./GOSALESMR_CONSTRAINTS_BLU.sh > GOSALESMR_CONSTRAINTS.SQL ; fi;
if [ -f GOSALESRT_CONSTRAINTS_BLU.sh ] ; then . ./GOSALESRT_CONSTRAINTS_BLU.sh > GOSALESRT_CONSTRAINTS.SQL ; fi;
if [ -f GOSALESDW_CONSTRAINTS_BLU.sh ] ; then . ./GOSALESDW_CONSTRAINTS_BLU.sh > GOSALESDW_CONSTRAINTS.SQL ; fi;

#STORED PROCEDURES
if [ -f GOSALES_SP.sh ] ; then . ./GOSALES_SP.sh > GOSALES_SP.SQL ; fi;
if [ -f GOSALESHR_SP.sh ] ; then . ./GOSALESHR_SP.sh > GOSALESHR_SP.SQL ; fi;
if [ -f GOSALESMR_SP.sh ] ; then . ./GOSALESMR_SP.sh > GOSALESMR_SP.SQL ; fi;
if [ -f GOSALESRT_SP.sh ] ; then . ./GOSALESRT_SP.sh > GOSALESRT_SP.SQL ; fi;
if [ -f GOSALESDW_SP.sh ] ; then . ./GOSALESDW_SP.sh > GOSALESDW_SP.SQL ; fi;

#VIEWS
if [ -f GOSALES_VIEWS.sh ] ; then . ./GOSALES_VIEWS.sh > GOSALES_VIEWS.SQL ; fi;
if [ -f GOSALESHR_VIEWS.sh ] ; then . ./GOSALESHR_VIEWS.sh > GOSALESHR_VIEWS.SQL ; fi;
if [ -f GOSALESMR_VIEWS.sh ] ; then . ./GOSALESMR_VIEWS.sh > GOSALESMR_VIEWS.SQL ; fi;
if [ -f GOSALESRT_VIEWS.sh ] ; then . ./GOSALESRT_VIEWS.sh > GOSALESRT_VIEWS.SQL ; fi;
if [ -f GOSALESDW_VIEWS.sh ] ; then . ./GOSALESDW_VIEWS.sh > GOSALESDW_VIEWS.SQL ; fi;

#STATS
#if [ -f GOSALES_RUNSTATS.sh ] ; then . ./GOSALES_RUNSTATS.sh > GOSALES_RUNSTATS.SQL ; fi;
#if [ -f GOSALESHR_RUNSTATS.sh ] ; then . ./GOSALESHR_RUNSTATS.sh > GOSALESHR_RUNSTATS.SQL ; fi;
#if [ -f GOSALESMR_RUNSTATS.sh ] ; then . ./GOSALESMR_RUNSTATS.sh > GOSALESMR_RUNSTATS.SQL ; fi;
#if [ -f GOSALESRT_RUNSTATS.sh ] ; then . ./GOSALESRT_RUNSTATS.sh > GOSALESRT_RUNSTATS.SQL ; fi;
#if [ -f GOSALESDW_RUNSTATS.sh ] ; then . ./GOSALESDW_RUNSTATS.sh > GOSALESDW_RUNSTATS.SQL ; fi;

#Add comments
if [ -f GOSALES_ADD_COMMENTS.sh ] ; then . ./GOSALES_ADD_COMMENTS.sh > GOSALES_ADD_COMMENTS.SQL ;
fi

#Verify Table
if [ -f GOSALES_VERIFY.sh ] ; then . ./GOSALES_VERIFY.sh > GOSALES_VERIFY.SQL ; fi;

############################################
# Run the scripts to execute the generated SQL
############################################

if [ "${GOSALES_ONLY_GENERATE_SQL}" = "N" ] ; then
   . ./GOSALES_RUN_SCRIPTS_BLU.sh
else
  echo "Sql files are located in ${GOSALES_SCRIPT_DIR}"
fi

# Finished - invoke the cleanup routine.
cleanup 0;
