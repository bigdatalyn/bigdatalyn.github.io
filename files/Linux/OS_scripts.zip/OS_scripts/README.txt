##############################################################################
# Author        : Jony Safi - Oracle Corporation
# Creation Date : 18-November-2011
# Revised By	: Filippos Boufis - Oracle Corporation
# Revision Date : 17-March-2021
# Version       : 2.2
# Purpose       : System statistics collection
##############################################################################
#  Disclaimer:
#  Although this program has been tested and used successfully, it is not supported by Oracle Support Services.
#  It has been tested internally, however, and works as documented. We do not guarantee that it will work for you,
#  so be sure to test it in your environment before relying on it.  We do not claim any responsibility for any problems
#  and/or damage caused by this program.  This program comes "as is" and any use of this program is at your own risk!!
#  Proofread this script before using it! due to the differences in the way text editors, e-mail packages and operating systems
#  handle text formatting (spaces, tabs and carriage returns).

This packaged zipfile contains also two scripts: 

1.     monisys_xxx.ksh - run this UNIX/Linux shell script at system peak load, it returns UNIX prompt immediately and for next 60 minutes gathers UNIX performance 
	   information in background (select the appropriate script for the OS: monisys_lin.ksh --> Linux, monisys_aix.ksh --> AIX, monisys_sol.ksh --> Solaris)

2.     ps_aux.ksh - it is called by monisys.ksh (not to be run individually)   
  
In an ultimate case, you can ask your system/storage administrators to provide us a report (IO, MEMORY, CPU, etc.) from the tools they have internally 
(for the period we will be analyzing). 
  
