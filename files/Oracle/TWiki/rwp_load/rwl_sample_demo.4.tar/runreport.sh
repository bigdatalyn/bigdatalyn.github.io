#!/bin/sh

# This shell script will create a complete html report
# from a scalability run with some key.  So after doing 
# something like:
#
# for p in 1 2 3 4 5; do ./runmany.sh $p key comment for the run; done
#
# your results database will contain data for five individual
# runs that all have the same key.  When the key is provided
# to this script, a file name key.html will be produced in 
# the awrdiretory
#
# Make sure you never use each key more than once, which
# can be verified by doing
#
# ./check_for_key.sh key
#
# which should show that the key isn't found.

# You MUST have gnuplot installed

if test $# -lt 2
then
  echo Usage: $0 key report title 1>&2
  exit 1
fi

key=$1
shift
runtitle="$*"

# Get directory names from parameters.rwl

eval `rwloadsim -q parameters2shell.rwl`

echo "You can safely ignore font errors from gnuplot"

# Remove the total througput vs time file
rm -f $resultsdir/$key.csv

# Loop through all results for this key
# and create the individual run graphs
# with runtime on the x-axis, throughput
# on the left y axis and various cpu 
# figures on the right y-axis
rwloadsim -q -x 'string key:="'$key'";' key2runs.rwl |
while read runnumber proccount komment
do
  #We take the proccount and runtitle separate as runtitle is used below
  # This awk script makes the y2axis have top at 1.8 time db cpu to avoid the
  # range being totally dominated by a potentially very high db time.
  # The factor 1.8 means there is some room for dbtime being larger than db cpu
  awk -f dbtime2axis.awk $resultsdir/${runnumber}_dbtime.csv > $resultsdir/$runnumber.plot
  cat >> $resultsdir/$runnumber.plot <<END
  set title "$runnumber $komment"
  set yrange [0:*]
  set y2tics
  set key bottom left
  set y2label "seconds / s"
  set ytics nomirror
  set terminal png
  set output "$awrdirectory/$runnumber.png"

  plot "$resultsdir/${runnumber}_tps.csv" using 1:2 with lines lw 2 axes x1y1 title "tps", \
    "$resultsdir/${runnumber}_dbtime.csv" using 1:3 with lines lw 2 lc 3 axes x1y2 title "dbtime", \
    "$resultsdir/${runnumber}_dbtime.csv" using 1:2 with lines lw 2 lc 2 axes x1y2 title "dbcpu", \
    "$resultsdir/${runnumber}_cli.csv" using 1:(\$2+\$3) with lines lw 2 axes x1y2 title "clicpu"

  set terminal svg
  set output "$awrdirectory/$runnumber.svg"
  replot
END
  gnuplot $resultsdir/$runnumber.plot

  # add a line to the total througput vs time file via
  # an awk script that simply takes the average of 
  # column values from some csv.  This is simpler
  # than using rwloadsim to do the same
  set -- `awk -f col234avg.awk $resultsdir/${runnumber}_tps.csv`
  tps=$1
  set -- `awk -f col234avg.awk $resultsdir/${runnumber}_dbtime.csv`
  dbcpu=$1; dbtime=$2
  echo $proccount $tps $dbcpu $dbtime >> $resultsdir/$key.csv

done

# Now create the plot that shows scalability
# i.e. througput vs time
cat > $resultsdir/${key}.plot <<END
set title "$runtitle"

set ylabel "tps"
set y2label "seconds / second"
set yrange [0:*]
set y2range [0:*]
set xrange [0:*]
set y2tics
set ytics nomirror
set key left

set terminal png
set output "$awrdirectory/${key}.png"

plot "$resultsdir/${key}.csv" using 1:2 with lines lw 2 axis x1y1 title "tps" \
, "$resultsdir/${key}.csv" using 1:4 with lines lw 2 lc 3 axis x1y2 title "dbtime" \
, "$resultsdir/${key}.csv" using 1:3 with lines lw 2 lc 2 axis x1y2 title "dbcpu"

set terminal svg
set output "$awrdirectory/${key}.svg"
replot

END

# Actually create the plot
gnuplot -persist $resultsdir/${key}.plot

# And finally make the html file
rwloadsim -q -x 'string key := "'${key}'";' -x 'string runtitle := "'"${runtitle}"'";' key2html.rwl

