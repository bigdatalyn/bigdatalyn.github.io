rem
rem Copyright (c) 2018, Oracle Corporation.  All rights reserved.
rem
rem NAME
rem   oe_user.sql - RWL create Order Entry USER
rem
rem DESCRIPTION
rem   Create the rwl_oe user for the order entry simulation
rem   based on a cut-down version of the standard OE demo
rem
rem MODIFIED  (MM/DD/YYYY)
rem bengsig    08/19/2018 - Creation
rem
create user rwl_oe identified by rwl_oe
default tablespace users
quota unlimited on users
/
grant
  create table
, create view
, create sequence
, create session
, create procedure
to rwl_oe
/
