break on runnumber
set pagesi 999
select * from runres_a where runnumber>=(select max(runnumber) from rwlrun)-3
order by runnumber, vname
/
