rem
rem Copyright (c) 2018, Oracle Corporation.  All rights reserved.
rem
rem Owner  : bengsig
rem
rem NAME
rem   oe_drop.sql - RWL Order Entry DROP objects
rem
rem DESCRIPTON
rem   Creates database objects.
rem
rem MODIFIED   (MM/DD/YY)
rem   bengsig   09/18/2018 - Creationmschema_to_rdbms

drop table ORDER_ITEMS purge;
drop table ORDERS purge;
drop table INVENTORIES purge;
drop table WAREHOUSES purge;
drop table products purge;
drop table CUSTOMERS purge;
drop sequence ORDERS_SEQ ;
