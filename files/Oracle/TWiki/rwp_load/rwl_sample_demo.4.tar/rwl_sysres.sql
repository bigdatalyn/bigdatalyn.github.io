--drop table sysres purge;
create table sysres 
-- This table is used to store various data gathered 
-- every second (or other interval) by queries against
-- v$views or the like. You should run a query 
-- every so often (say once per second) and then insert
-- a row into this table that includes the runnumber
-- and the value returned by runseconds, plus some
-- result name and interesting values.  An example
-- is to query v$sys_time_model pick values
-- which could be inserted into val1, val2, etc
-- with resname e.g. TIMM
--
-- The table is created in the repository schema
-- schema
( runnumber number not null
, second number not null
, resname varchar2(10) not null
, constraint sysres_pk primary key(runnumber, resname, second)
, val1 number
, val2 number
, val3 number
, val4 number
, val5 number
, val6 number
, val7 number
, val8 number
, val9 number
)
/
