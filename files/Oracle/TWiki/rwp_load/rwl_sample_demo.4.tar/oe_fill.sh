#!/bin/bash

eval `rwloadsim -q parameters2shell.rwl`

echo exit | sqlplus rwl_oe/rwl_oe@$connect_string @oe_drop 
echo exit | sqlplus rwl_oe/rwl_oe@$connect_string @oe_schema

rwloadsim runtest.rwl oe_fillcustomers.rwl
rwloadsim runtest.rwl oe_fillproducts.rwl
rwloadsim runtest.rwl oe_fillwarehouses.rwl
