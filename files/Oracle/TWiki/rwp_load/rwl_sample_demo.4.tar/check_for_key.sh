#!/bin/sh

# Verify that the keys provided as arguments
# are not already found in the repository schema
#
# Run this before starting a scalability run such
# that you don't get mixed results from several runs

for x in "$@"
do
  rwloadsim -q -x 'string key:="'$x'";' check_for_key.rwl
done
