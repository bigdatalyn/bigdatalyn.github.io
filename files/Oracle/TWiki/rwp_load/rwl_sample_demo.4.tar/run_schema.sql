create or replace synonym customers for rwl_oe.customers;
create or replace synonym order_items for rwl_oe.order_items;
create or replace synonym orders for rwl_oe.orders;
create or replace synonym warehouses for rwl_oe.warehouses;
create or replace synonym inventories for rwl_oe.inventories;
create or replace synonym products for rwl_oe.products;
create or replace synonym orders_seq for rwl_oe.orders_seq;

create or replace synonym cd_ses for rwl_cd.cd_ses;
create or replace synonym cd_det for rwl_cd.cd_det;
create or replace synonym cd_gam for rwl_cd.cd_gam;
create or replace synonym cd_bon for rwl_cd.cd_bon;

