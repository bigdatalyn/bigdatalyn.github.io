#!/bin/sh

# Provide three arguments:
# 1: Number of processes to start
# 2: key to be saved in the repository
# 3: komment for the repository - the process count will be prepended

if test $# -lt 3
then
  echo Usage: $0 count key komment 1>&2
  exit 1
fi

proccount=$1
key=$2
shift
shift
komment="$proccount $*"

# If you have X-Windows and gnuplot, this tells how
# frequent the running plot is being updated
flushevery=2 # You can try 1 if you have fast X-windows 

# Chose a total run period as little under a multiple
# of 100 seconds for nice graphs
runperiod=295 # just under 5 minutes

# verify that it compiles
rwloadsim -e -- '-x $mute:141' run.rwl || exit $?

# Truncate the connection demo tables
rwloadsim cd_truncate.rwl

procnumber=1;

# Rampup 5 seconds plus 0.5 * process count
rampup=`expr 5 + $proccount / 2`

prepfile=.runmany.txt

# Prepare the run
rwloadsim -sss -P $prepfile -k $key -K "$komment" -q results.rwl -- '-x printline "Preparing runnumber",runnumber;'

quiet=''

# Start all in background
while test $procnumber -le $proccount
do
  rwloadsim --flush-every=$flushevery --flush-stop=$runperiod -i runperiod:=$runperiod -i proccount:=$proccount -i procnumber:=$procnumber -R $prepfile $quiet run.rwl &
  sleep 0.2
  quiet='-q' # only messages from first
  procnumber=`expr $procnumber + 1`
done

# Are we running X?
if test x$DISPLAY = x
then
  echo '$DISPLAY is not set, cannot show running plot'
else
  # And does gnuplot exist?
  type gnuplot > /dev/null 2> /dev/null
  if test $? != 0
  then
    echo '"gnuplot" is not available, cannot show running plot'
  else
    # YES - Start the running plot
    rwloadsim -q -i flushevery:=$flushevery -i runperiod:=$runperiod -R $prepfile runningplot.rwl | gnuplot -noraise -persist &
  fi
fi


wait


