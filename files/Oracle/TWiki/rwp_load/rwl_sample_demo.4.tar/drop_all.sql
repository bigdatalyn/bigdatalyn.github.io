rem
rem Copyright (c) 2018, Oracle Corporation.  All rights reserved.
rem
rem NAME
rem   drop_all.sql - RWL DROP ALL related to demo
rem
rem DESCRIPTON
rem   Drops schemas unconditionally
rem
rem MODIFIED   (MM/DD/YY)
rem   bengsig   09/18/2018 - Creation
rem
drop user rwl_oe cascade;
drop user rwl_cd cascade;
drop user rwl_run cascade;
