rem
rem Copyright (c) 2018, Oracle Corporation.  All rights reserved.
rem
rem Owner  : bengsig
rem
rem NAME
rem   cd_schema.sql - RWL create Connection Demo SCHEMA
rem
rem DESCRIPTON
rem   Creates database objects in the rwl_cd schema
rem   which is a close reimplementation of the RWP
rem   connection demo 
rem
rem MODIFIED   (MM/DD/YY)
rem   bengsig   09/18/2018 - Creation

create table cd_ses
( sesid number not null
, col1 number
, fill varchar2(50)
, constraint cd_ses_pk primary key(sesid)
)
/

create table cd_det
( sesid number not null
, seqid number not null
, runid number not null
, val number(*)
, dat date not null
, fill varchar2(100)
, constraint cd_det_pk primary key(seqid, runid)
)
/

create table cd_gam
( sesid number not null
, seqid number not null
, runid number not null
, val number(*)
, dat date not null
, fill varchar2(100)
, constraint cd_gam_pk primary key(seqid, runid)
)
/

create table cd_bon
( sesid number not null
, seqid number not null
, runid number not null
, val number(*)
, dat date not null
, fill varchar2(100)
, constraint cd_bon_pk primary key(seqid, runid)
)
/

begin
  -- Note that the number used here
  -- must match the setting in cd_declarations.rwl
  for i in 0..200000
  loop
    insert into cd_ses values 
      ( i 
      , round(dbms_random.value(0,100000))
      , dbms_random.string('a',50));
  end loop;
  commit;
end;
/

grant all on cd_ses to rwl_run;
grant all on cd_det to rwl_run;
grant all on cd_gam to rwl_run;
grant all on cd_bon to rwl_run;
