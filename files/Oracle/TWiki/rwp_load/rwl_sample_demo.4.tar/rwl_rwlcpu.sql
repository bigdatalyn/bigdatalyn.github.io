--drop table rwlcpu purge
--/
create table rwlcpu
( runnumber number not null
-- this table is used to save usr and sys 
-- CPU of the rwloadsim process itself
-- see run.rwl
, procno number not null
, second number not null
, cliusr     number(*,6)
, clisys    number(*,6)
, constraint rwlcpu_pk primary key(runnumber, procno, second)
)
/
create or replace view rwlcpu_a
-- aggregate multi process runs
as
select
  runnumber
-- the actual second value is not exactly
-- the same in all processes so we 
-- calculate the average  ...
, avg(second) second
, count(*) pcount
, sum(cliusr) cliusr
, sum(clisys) clisys
from rwlcpu
group by runnumber
-- ... and do the group by on the rounded value
, round(second)
/
