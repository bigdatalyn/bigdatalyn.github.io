rem 
rem Copyright (c) 2018, Oracle Corporation.  All rights reserved.
rem
rem NAME
rem  cd_user.sql - RWL Connection Demo create USER 
rem
rem DESCRIPTION
rem   Create the rwl_cd user for the connection demo simulation
rem
rem MODIFIED  (MM/DD/YYYY)
rem bengsig    08/19/2018 - Creation
rem
create user rwl_cd identified by rwl_cd
default tablespace users
quota unlimited on users
/
grant
  create table
, create view
, create sequence
, create session
, create procedure
to rwl_cd
/
