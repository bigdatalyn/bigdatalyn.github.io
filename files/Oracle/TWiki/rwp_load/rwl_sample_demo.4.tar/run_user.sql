rem
rem Copyright (c) 2018, Oracle Corporation.  All rights reserved.
rem
rem NAME
rem   run_user.sql - RWL create RUNtime USER
rem
rem DESCRIPTON
rem   Creates the user that is used at runtime
rem
rem MODIFIED   (MM/DD/YY)
rem   bengsig   09/18/2018 - Creation
rem
create user rwl_run identified by rwl_run
/
grant
  create session, create synonym
to rwl_run
/
