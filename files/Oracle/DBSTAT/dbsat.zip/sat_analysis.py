#
# Security Assessment Analysis Framework
#
# Copyright (c) 2015, 2016, Oracle and/or its affiliates. All rights reserved.
#

from __future__ import print_function
import sys
import os
import json
import textwrap
import codecs
import xlsxwriter
import xml.sax.saxutils as saxutils

#
# Exported constants
#

SEV_OK = 0
SEV_UNKNOWN = 1
SEV_ENHANCEMENT = 2
SEV_LOW = 3
SEV_MEDIUM = 4
SEV_HIGH = 5

#
# Internal (private) data and functions
#

# Result tables
data_root = {}

# Severity level names
sev_labels = ['Pass', 'Evaluate', 'Opportunity', 'Some Risk',
    'Significant Risk', 'Severe Risk']
sev_colors = ['#00ff00', '#cccccc', '#00bfff', '#ffff00', '#ffa500', '#f80000'] 

# Base of input and output file names
io_prefix = None

# 
# print_file
#   fp - open file handle
#   args - list of arguments to be printed
#
# Print to an open file object. This uses the Python 3 print function,
# which is available (with the import from __future__) in Python 2.6
# and later.
#
def print_file(fp, *args):
    print(*args, file=fp)

#
# Exported functions
#

# all_tables
#   no parameters
# Returns
#   names - list of all result table names
#
def all_tables():
    return data_root.keys()

# all_columns
#   name - name of result table
# Returns
#   columns - list of call column names for this table
#
def all_columns(name):
    item = data_root.get(name, None)
    if item == None:
        return None
    else:
        return item['columns'][:]

# show_all
#   no parameters
#
# Print a list of all result table names and their columns.
#
def show_all():
    for name in data_root.keys():
        print(name)
        for col in data_root[name]['columns']:
            print("  ", col)

# read_json
#   pathname - pathname to input file (without .json suffix)
#
# Read a JSON file containing result tables into memory.
#
def read_json(pathname):
    global data_root

    fp = codecs.open(pathname+'.json', 'r', 'latin-1')
    data_root = json.load(fp, strict=False)
    fp.close()

# get_data
#   name - name of desired result table
#   version - minimum version number required
# Returns
#   table - two-dimensional array representing query result
#
# Return the rows and columns of a result table.
#
def get_data(name, version):
    item = data_root.get(name, None)
    if item == None or item['version'] < version:
        return None
    return item['data']

# get_index
#   name - name of result table
#   column - name of desired column
# Returns
#   index - numerical index of column in array returned by get_data()
#
def get_index(name, column):
    item = data_root.get(name, None)
    if item == None:
        return None
    cols = item['columns']
    for i in range(len(cols)):
        if cols[i] == column:
            return i
    return None

#
# Report output
#

report_sections = []
current_section = None
report_diags = []

textfp = None
htmlfp = None
xls_book = None
xls_sheet = None
xls_row = 0

wrap_block_shift = textwrap.TextWrapper(width=75,
    initial_indent='    ', subsequent_indent='    ')
wrap_indent_shift = textwrap.TextWrapper(width=75,
    initial_indent='    ', subsequent_indent='        ')
wrap_indent = textwrap.TextWrapper(width=75, subsequent_indent='    ')

section_fmt = None
wrap_fmt = None
table_fmt = None
status_fmt = {}

HTML_STYLE = textwrap.dedent('''
    <style>

    table {
        font-family: Lucida Sans Unicode, Lucida Grande, Sans-Serif;
        font-size:14px;
        border-collapse:collapse;
        border:1px solid #8DA6B1;
        margin:20px;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    }

    thead {
        background-color: #eeeeee;
        font-weight:normal;
        color:black;
        border-bottom:3px double grey;
        padding:12px 17px
    }

    tfoot {
        background-color: #eeeeee;
    }

    h1 {
        font-family: Lucida Sans Unicode, Lucida Grande, Sans-Serif;
        text-align: center;
    }
    h2 {
        font-family: Lucida Sans Unicode, Lucida Grande, Sans-Serif;
        text-decoration: underline;
    }
    h3 {
        font-family: Lucida Sans Unicode, Lucida Grande, Sans-Serif;
    }
    p {
        font-family: Lucida Sans Unicode, Lucida Grande, Sans-Serif;
    }
    p.footnote {
        font-size: 12px
    }

    table.finding {
        font-family:Lucida Sans Unicode, Lucida Grande, Sans-Serif;
        font-size:14px;
        border-collapse:collapse;
        border:1px solid #8DA6B1;
        margin:20px;
        width:800px;
    }

    tr.ruleid {
        font-size:10px;
        background-color: #eeeeee;
        border-collapse:collapse;
        border:1px solid #8DA6B1;
        margin:20px;
        text-align:left;
        font-weight:bold;
    }

    td.number {
        text-align: right;
    }
    td.total {
        text-align: right;
        font-weight: bold;
    }
    td.finding_head {
        text-align: left;
        vertical-align: top;
        font-weight: bold;
    }
    td.finding_cell {
        text-align: left;
        vertical-align: top;
    }

    a.home {
        width: 30px;
        height: 22px;
        line-height:20px;
        position: fixed;
        text-indent: 7px;
        z-index: 999;
        right: 50px;
        bottom: 25px;
        background: #dddddd no-repeat center 43%;
        font-family: Lucida Sans Unicode, Lucida Grande, Sans-Serif;
        font-size:10px;
        color: black;
        cursor:pointer;
        -webkit-border-radius: 30px;
        -moz-border-radius: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    }
    a.up {
        width: 30px;
        height: 22px;
        position: fixed;
        text-indent: 7px;
        z-index: 999;
        right: 80px;
        bottom: 25px;
        background: #dddddd no-repeat center 43%;
        font-weight:bold;
        font-family: Lucida Sans Unicode, Lucida Grande, Sans-Serif;
        font-size:16px;
        color: black;
        cursor:pointer;
        -webkit-border-radius: 30px;
        -moz-border-radius: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    }
    a.down {
        width: 30px;
        height: 22px;
        position: fixed;
        text-indent: 7px;
        z-index: 999;
        right: 20px;
        bottom: 25px;
        background: #dddddd no-repeat center 43%;
        font-weight:bold;
        font-family: Lucida Sans Unicode, Lucida Grande, Sans-Serif;
        font-size:16px;
        color: black;
        cursor:pointer;
        -webkit-border-radius: 30px;
        -moz-border-radius: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    }
    </style>
    <script>
    var sectionStart = [0];

    // find offset
    function findPos(obj) {
        var curtop = 0;

        do {
            curtop += obj.offsetTop;
        } while (obj = obj.offsetParent);
        return curtop;
    }

    // navigate the array
    function go(p_action) {
        var epsilon = 20; // considered at section start if within a few pixels
        var curpos = window.pageYOffset;

        if (p_action == "up") {
            for (var i = sectionStart.length-1; i >= 0; i--) {
                if (sectionStart[i] < curpos-epsilon) {
                    window.scroll(0, sectionStart[i]);
                    break;
                }
            }
        } else if (p_action == "down") {
            for (var i = 0; i < sectionStart.length; i++) {
                if (sectionStart[i] > curpos+epsilon) {
                    window.scroll(0, sectionStart[i]);
                    break;
                }
            }
        } else if (p_action == "top") {
            window.scroll(0, 0);
        }
    }

    var beforePrint = function() {
        document.getElementById("up").style.visibility = "hidden";
        document.getElementById("down").style.visibility = "hidden";
        document.getElementById("home").style.visibility = "hidden";
    };
    var afterPrint = function() {
        document.getElementById("up").style.visibility = "";
        document.getElementById("down").style.visibility = "";
        document.getElementById("home").style.visibility = "";
    };

    function init() {
        // populate array with H2 elements
        var elements = document.getElementsByTagName("h2");
        for (var i = 0; i < elements.length; i++) {
            sectionStart.push(findPos(elements[i]));
        }

        // prevent navigation buttons from printing
        if (window.matchMedia) {
            var mediaQueryList = window.matchMedia('print');
            mediaQueryList.addListener(function(mql) {
                if (mql.matches) {
                    beforePrint();
                } else {
                    afterPrint();
                }
            });
        }
        window.onbeforeprint = beforePrint;
        window.onafterprint = afterPrint;
    }
    </script>
''')

DISCLAIMER = [
    'This report is focused on detecting areas of potential ' + \
    'security vulnerabilities or misconfigurations and ' + \
    'providing recommendations on how to mitigate those ' + \
    'potential vulnerabilities.',
    'The report provides a view on the current status. These ' + \
    'recommendations are provided for informational purposes ' + \
    'only and should not be used as a substitute for a ' + \
    'thorough analysis or interpreted to contain any legal ' + \
    'or regulatory advice or guidance.',
    'You are solely responsible for your system, and the ' + \
    'data and information gathered during the production of ' + \
    'this report. You are also solely responsible for the ' + \
    'execution of software to produce this report, and for ' + \
    'the effect and results of the execution of any ' + \
    'mitigating actions identified herein.',
    'Oracle provides this analysis on an "as is" basis ' + \
    'without warranty of any kind and Oracle hereby ' + \
    'disclaims all warranties and conditions whether ' + \
    'express, implied or statutory.'
]

# start_report
#   pathname - base of output filenames (without suffixes)
#
# Prepare output files for all report formats: text, HTML, spreadsheet.
#
def start_report(pathname):
    global io_prefix, textfp, htmlfp, xls_sheet, xls_book, xls_row
    global section_fmt, wrap_fmt, table_fmt

    io_prefix = pathname
    # Text
    textfp = codecs.open(pathname+'.txt', 'w', encoding='utf-8')
    os.chmod(pathname+'.txt', 0o600)
    print_file(textfp,
        '### Oracle Database Security Risk Assessment ' + \
        '- Highly Confidential ###')
    print_file(textfp, '')
    # HTML
    htmlfp = codecs.open(pathname+'.html', 'w',
        encoding='ascii', errors='xmlcharrefreplace')
    os.chmod(pathname+'.html', 0o600)
    print_file(htmlfp, '<!DOCTYPE html><html lang="en"><head>')
    print_file(htmlfp, '<title>', pathname,
        '- Oracle Database Security Risk Assessment </title></head>')
    print_file(htmlfp, '<style>')
    for i, color in enumerate(sev_colors):
        print_file(htmlfp, 'td.sev%d {' % i)
        print_file(htmlfp, '    background-color:%s;' % color)
        print_file(htmlfp, '    border-collapse:collapse;')
        print_file(htmlfp, '    border:1px solid #8DA6B1;')
        print_file(htmlfp, '    margin:20px;')
        print_file(htmlfp, '}')
    print_file(htmlfp, '</style>')
    print_file(htmlfp, HTML_STYLE)
    print_file(htmlfp, '<body onload="init();">')
    print_file(htmlfp,
        '<a id="up" class="up" onclick="go(\'up\');">&#8679;</a>')
    print_file(htmlfp,
        '<a id="home" class="home" onclick="go(\'top\');">Top</a>')
    print_file(htmlfp,
        '<a id="down" class="down" onclick="go(\'down\');">&#8681;</a>')
    print_file(htmlfp, '<h1>Oracle Database Security Risk Assessment</h1>')
    print_file(htmlfp, '<h3><center>Highly Confidential</center></h3>')
    # Spreadsheet
    xls_book = xlsxwriter.Workbook(pathname+'.xlsx')
    xls_sheet = xls_book.add_worksheet()
    xls_sheet.set_landscape()
    xls_sheet.set_column(0, 0, 20)
    xls_sheet.set_column(1, 1, 15)
    xls_sheet.set_column(2, 2, 12)
    xls_sheet.set_column(3, 3, 28)
    xls_sheet.set_column(4, 4, 35)
    section_fmt = xls_book.add_format({'bold': True, 'font_size': 14,
        'bottom': 1})
    table_fmt = xls_book.add_format({'font_name': 'Courier New', 'top': 1,
        'valign': 'top', 'text_wrap': True})
    wrap_fmt = xls_book.add_format({'text_wrap': True, 'valign': 'top',
        'top': 1})
    for i, color in enumerate(sev_colors):
        status_fmt[i] = xls_book.add_format({'text_wrap': True,
            'bg_color': color, 'valign': 'top', 'top': 1})
    xls_sheet.set_row(0, 30)
    xls_sheet.merge_range(0, 0, 0, 4, 
        'Oracle Database Security Risk Assessment - Highly Confidential',
        section_fmt)
    xls_row = 2

# print_summary
#   no parameters
#
# Print a summary showing the number of findings in each section.
#
def print_summary():
    print_file(htmlfp, '<h2>Summary</h2>')
    print_file(htmlfp, '<table border="1" cellpadding="4" rules="cols" ' +
        'summary="Summary of report sections">')
    print_file(htmlfp, '<thead><tr>')
    print_file(htmlfp, '<th align="left" scope="col"> Section </th>')
    sum_table = [['Section'] + sev_labels + ['Total Findings']]
    for label in sev_labels:
        print_file(htmlfp, '<th align="left" scope="col">' + label + '</th>')
    print_file(htmlfp, '<th align="left" scope="col"> Total Findings </th>')
    print_file(htmlfp, '</tr></thead>')
    totals = [0] * len(sev_labels)
    for s in report_sections:
        row = [s['title']]
        print_file(htmlfp, '<tr>')
        print_file(htmlfp, '<td align="left"><a href="#%s">' % s['link'],
            s['title'], '</a></td>')
        for cnt in s['warnings']:
            row.append(str(cnt))
            print_file(htmlfp, '<td class="number">', cnt, '</td>')
        sect_total = sum(s['warnings'])
        row.append(str(sect_total))
        sum_table.append(row)
        print_file(htmlfp, '<td class="total">', sect_total, '</td>')
        print_file(htmlfp, '</tr>')
        totals = [x+y for x, y in zip(totals, s['warnings'])]
    row = ['Total']
    print_file(htmlfp, '<tfoot><tr>')
    print_file(htmlfp, '<th align="left" scope="row">Total</th>')
    for cnt in totals:
        row.append(str(cnt))
        print_file(htmlfp, '<td class="total">', cnt, '</td>')
    grand_total = sum(totals)
    row.append(str(grand_total))
    sum_table.append(row)
    print_file(htmlfp, '<td class="total">', grand_total, '</td>')
    print_file(htmlfp, '</tr></tfoot>')
    print_file(htmlfp, '</table>')
    print_file(textfp, '###', 'Summary', '###')
    print_file(textfp, '')
    alignment = ['left'] + ['right'] * (len(sev_labels)+1)
    lines = fmt_table(sum_table, True, alignment)
    for l in lines:
        print_file(textfp, l)
    print_file(textfp, '')

# end_report
#   no parameters
#
# Write the stored report content to each report file.
#
def end_report():
    global xls_row

    print_summary()
    for s in report_sections:
        print_section(s['title'], s['link'])
        for item in s['items']:
            if item['type'] == 'info':
                print_info(item)
            elif item['type'] == 'finding':
                print_finding(item)
            elif item['type'] == 'table':
                print_table(item)
    
    # Diagnostic messages
    if len(report_diags) > 0:
        print_file(textfp, '### Diagnostics ###', '\n')
        print_file(htmlfp, '<h2>Diagnostics</h2>')
        for msg in report_diags:
            print_file(textfp, msg, '\n')
            print_file(htmlfp, '<p>', msg, '</p>')

    # Close files
    print_file(textfp, '\n----------')
    for para in DISCLAIMER:
        print_file(textfp, wrap_block_shift.fill(para), '\n')
    textfp.close()
    print_file(htmlfp, '<hr>')
    for para in DISCLAIMER:
        print_file(htmlfp, '<p class="footnote">')
        print_file(htmlfp, para)
        print_file(htmlfp, '</p>')
    print_file(htmlfp, '</body></html>')
    htmlfp.close()
    xls_row += 1
    xls_sheet.set_row(xls_row, 200)
    xls_sheet.merge_range(xls_row, 0, xls_row, 4,
        '\n\n'.join(DISCLAIMER), wrap_fmt)
    xls_book.close()
    os.chmod(io_prefix+'.xlsx', 0o600)

# start_section
#   title - section title
#
# Begin a new report section, used to group findings.
#
def start_section(title):
    global current_section
    link = title.replace(' ', '_')
    current_section = {'title': title, 'link': link,
        'warnings': [0, 0, 0, 0, 0, 0], 'items': []}

def print_section(title, link):
    global xls_row
    print_file(textfp, '###', title, '###')
    print_file(textfp, '')
    print_file(htmlfp, '<h2><a name="%s">%s</a></h2>' % (link, title))
    xls_row += 1
    xls_sheet.set_row(xls_row, 30)
    xls_sheet.merge_range(xls_row, 0, xls_row, 4, title, section_fmt)
    xls_row += 1
    xls_sheet.write_row(xls_row, 0,
        ('Item', 'ID', 'Status', 'Result', 'Remarks'), section_fmt)
    xls_row += 1

# end_section
#   no parameters
#
# End the current report section.
#
def end_section():
    global current_section
    report_sections.append(current_section)
    current_section = None

# finding
#   title - name of rule
#   id - unique ID for rule
#   summary - short summary of finding
#   severity - result of check
#   details - detailed results
#   remarks - descriptive text explaining importance and/or remediation
#
# Record the result of a rule text and format appropriately for each type
# of report. Basic information is included in all report formats, while
# some details only appear in a subset of the reports.
#
def finding(title, id, summary, severity=SEV_UNKNOWN, details=None,
remarks=None):
    item = {'type': 'finding', 'id': id, 'title': title,
        'summary': summary, 'severity': severity, 'details': details,
        'remarks': remarks}
    if current_section == None:
        print_finding(item)
    else:
        current_section['warnings'][severity] += 1
        current_section['items'].append(item)

def print_finding(item):
    global xls_row
    id = item['id']
    title = item['title']
    summary = item['summary']
    severity = item['severity']
    details = item['details']
    remarks = item['remarks']
    # Text
    print_file(textfp, '*', title, '*')
    print_file(textfp, 'Status:', sev_labels[severity])
    print_file(textfp, 'Summary:')
    print_file(textfp, wrap_block_shift.fill(summary))
    if details:
        print_file(textfp, 'Details:')
        for line in details.splitlines():
            print_file(textfp, wrap_indent_shift.fill(line))
    if remarks:
        print_file(textfp, 'Remarks:')
        for line in remarks.splitlines():
            print_file(textfp, wrap_block_shift.fill(line))
    print_file(textfp, '')
    # HTML
    print_file(htmlfp, '<h3>', title, '</h3>')
    print_file(htmlfp, '<table class="finding" cellpadding="4" border="0" ' +
        'role="presentation">')
    print_file(htmlfp, '<tr class="ruleid"><td></td>')
    print_file(htmlfp, '<td colspan="3">', id, '</td>')
    print_file(htmlfp, '</tr><tr>')
    print_file(htmlfp, '<td class="sev%d" colspan="4"></td>' % severity)
    print_file(htmlfp, '</tr>')
    print_file(htmlfp, '<tr><td></td>')
    print_file(htmlfp, '<td class="finding_head">Status</td>',
        '<td class="finding_cell">', sev_labels[severity],
        '</td><td></td></tr>')
    print_file(htmlfp, '<tr><td></td><td class="finding_head">Summary</td>')
    print_file(htmlfp, '<td class="finding_cell">', summary,
        '</td><td></td></tr>')
    if details:
        print_file(htmlfp, '<tr><td></td>')
        print_file(htmlfp, '<td class="finding_head">Details</td>')
        print_file(htmlfp, '<td class="finding_cell"><pre>')
        for line in details.splitlines():
            line = saxutils.escape(line) # escape HTML characters
            print_file(htmlfp, wrap_indent.fill(line))
        print_file(htmlfp, '</pre></td><td></td></tr>')
    if remarks:
        print_file(htmlfp, '<tr><td></td>')
        print_file(htmlfp, '<td class="finding_head">Remarks</td>')
        print_file(htmlfp, '<td class="finding_cell">', remarks, '</td><td></td></tr>')
    print_file(htmlfp, '</table>')
    # Spreadsheet
    xls_sheet.write(xls_row, 0, title, wrap_fmt)
    xls_sheet.write(xls_row, 1, id, wrap_fmt)
    fmt = status_fmt.get(severity, wrap_fmt)
    xls_sheet.write(xls_row, 2, sev_labels[severity], fmt)
    xls_sheet.write(xls_row, 3, summary, wrap_fmt)
    if remarks:
        xls_sheet.write(xls_row, 4, remarks, wrap_fmt)
    xls_row += 1

# diag
#   message - diagnostic message
#
# Report an unexpected error with the analysis, such as a missing result
# table. This routine should not be used to report results of a rule
# check. These messages appear only in the text format report.
#
def diag(message):
    report_diags.append(message)

# info
#   message - message text
#
# Report an informational message, suitable for explanatory text about
# other rule and table output.
#
def info(message):
    item = {'type': 'info', 'message': message}
    if current_section == None:
        print_info(item)
    else:
        current_section['items'].append(item)

def print_info(item):
    message = item['message']
    print_file(textfp, wrap_block_shift.fill(message))
    print_file(textfp, '')
    print_file(htmlfp, '<p>')
    print_file(htmlfp, message)

# fmt_table
#   rows - list of table rows
#   header - True if first row is a table header
# Returns
#   lines - list of formatted lines
#
# Format a plain-text table. Returns a list of constant-width lines.
# Used for text and spreadsheet reports but not HTML.
#
def fmt_table(rows, header, alignment):
    widths = []
    lines = []
    for col in zip(*rows):
        widths.append(max(map(len, col)))
    for row in rows:
        out = []
        for i in range(len(row)):
            if alignment is not None and alignment[i] == 'center':
                out.append(row[i].center(widths[i]))
            elif alignment is not None and alignment[i] == 'right':
                out.append(row[i].rjust(widths[i]))
            else:
                out.append(row[i].ljust(widths[i]))
        lines.append(' '.join(out))
        if header:
            out = ['-' * w for w in widths]
            lines.append(' '.join(out))
            header = False
    return lines

# table
#   title - name of table
#   rows - list of table rows
#   header - True if first row is a table header
#   alignment - list of alignment options for each column (default left)
#
# Include tabular information in output reports. There is no status reported
# with this output. If needed, use finding() to report judgments about the
# information reported in the table.
#
def table(title, rows, header=True, alignment=None):
    item = {'type': 'table', 'title': title, 'rows': rows, 'header': header,
        'alignment': alignment}
    if current_section == None:
        print_table(item)
    else:
        current_section['items'].append(item)

def print_table(item):
    global xls_row
    title = item['title']
    rows = item['rows']
    header = item['header']
    alignment = item['alignment']
    # Text
    print_file(textfp, '*', title, '*')
    lines = fmt_table(rows, header, alignment)
    for l in lines:
        print_file(textfp, l)
    print_file(textfp, '')
    # HTML
    print_file(htmlfp, '<h3>', title, '</h3>')
    if header:
        print_file(htmlfp, '<table cellpadding="4" border="1" rules="cols" ' +
            'summary="Data table for ' + title +'">')
    else:
        print_file(htmlfp, '<table cellpadding="4" border="1" rules="cols">')
    for row in rows:
        if header:
            print_file(htmlfp, '<thead><tr>')
        else:
            print_file(htmlfp, '<tr>')
        for i in range(len(row)):
            c = saxutils.escape(row[i]) # escape HTML characters
            if header:
                print_file(htmlfp, '<th align="left" scope="col">', c, '</th>')
            else:
                if alignment is None:
                    align = 'left'
                else:
                    align = alignment[i]
                print_file(htmlfp, '<td align="%s">' % align, c, '</td>')
        print_file(htmlfp, '</tr>')
        if header:
            print_file(htmlfp, '</thead>')
        header = False
    print_file(htmlfp, '</table>')
    # Spreadsheet
    xls_sheet.write(xls_row, 0, title, wrap_fmt)
    xls_sheet.set_row(xls_row, 15*max(1, len(lines)))
    xls_sheet.merge_range(xls_row, 1, xls_row, 4,
        '\n'.join(lines), table_fmt)
    xls_row += 1
