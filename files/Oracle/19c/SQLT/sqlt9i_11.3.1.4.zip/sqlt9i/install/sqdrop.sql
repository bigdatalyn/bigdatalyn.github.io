SET ECHO ON TERM ON NUMF "";
REM
REM $Header: 215187.1 sqdrop.sql 11.2.9.2 2009/05/27 csierra $
REM
REM Copyright (c) 2000-2009, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   carlos.sierra@oracle.com
REM
REM SCRIPT
REM   sqdrop.sql
REM
REM DESCRIPTION
REM   This script uninstalls a prior version of the SQLT tool dropping
REM   first existing SQLTXPLAIN objects, then the SQLTXPLAIN user
REM   itself.
REM
REM PRE-REQUISITES
REM   1. This script must be executed connected INTERNAL (SYS) as
REM      SYSDBA
REM
REM PARAMETERS
REM   1. None
REM
REM EXECUTION
REM   1. Navigate to sqlt/install directory
REM   2. Start SQL*Plus connecting INTERNAL (SYS) as SYSDBA
REM   3. Execute script sqdrop.sql
REM
REM EXAMPLE
REM   # cd sqlt/install
REM   # sqlplus /nolog
REM   SQL> connect / as sysdba
REM   SQL> start sqdrop.sql
REM
REM NOTES
REM   1. This script is executed automatically by sqcreate.sql
REM
SET ECHO OFF TERM OFF;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
BEGIN
  IF USER != 'SYS' THEN
    RAISE_APPLICATION_ERROR(-20100, 'Drop script failed - sqdrop.sql should be executed connected as SYS, not as '||USER);
  END IF;
END;
/
WHENEVER SQLERROR CONTINUE;

@@sqdtab.sql
@@sqdusr.sql

PRO SQDROP completed.
