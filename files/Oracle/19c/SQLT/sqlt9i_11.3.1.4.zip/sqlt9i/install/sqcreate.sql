SET ECHO ON TERM ON;
SPOOL sqcreate.lis;
REM
REM $Header: 215187.1 sqcreate.sql 11.3.1.4 2010/04/11 csierra $
REM
REM Copyright (c) 2000-2010, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   carlos.sierra@oracle.com
REM
REM SCRIPT
REM   sqcreate.sql
REM
REM DESCRIPTION
REM   This script installs the SQLT tool into its own schema.
REM
REM PRE-REQUISITES
REM   1. This script must be executed connected INTERNAL (SYS) as
REM      SYSDBA
REM   2. During the installation you will be asked to enter the
REM      follwing:
REM        o  SQLTXPLAIN password - Required and it has no default
REM           Case sensitive on 11g.
REM        o  Schema name of main application that will use the
REM           SQLT tool. For example APPS. If there are more than one
REM           application schema owners, enter the main one
REM        o  SQLTXPLAIN default tablespace - You will be presented
REM           with a list, then you will have to enter one tablespace
REM           name from that list
REM        o  SQLTXPLAIN temporary tablespace - Similar as above
REM
REM PARAMETERS
REM   1. None inline. During the installation you will be asked for
REM      the values of the 4 parameters described under
REM      pre-requisites section above
REM
REM EXECUTION
REM   1. Navigate to sqlt/install directory
REM   2. Start SQL*Plus connecting INTERNAL (SYS) as SYSDBA
REM   3. Execute script sqcreate.sql and respond to values requested
REM
REM EXAMPLE
REM   # cd sqlt/install
REM   # sqlplus /nolog
REM   SQL> connect / as sysdba
REM   SQL> start sqcreate.sql
REM
REM NOTES
REM   1. For possible errors see *.lis files
REM
SET ECHO OFF TERM OFF;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
ALTER SESSION SET NLS_NUMERIC_CHARACTERS = ".,";
DECLARE
  rdbms_release NUMBER;
BEGIN
  IF USER != 'SYS' THEN
    RAISE_APPLICATION_ERROR(-20100, 'Install failed - SQLTXPLAIN should be installed connected as SYS, not as '||USER);
  END IF;
  SELECT TO_NUMBER(SUBSTR(version, 1, INSTR(version, '.', 1, 2) - 1))
    INTO rdbms_release
    FROM v$instance;
  IF rdbms_release < 9.2 THEN
    RAISE_APPLICATION_ERROR(-20200, 'Install failed - SQLTXPLAIN should be installed in 9i(9.2) or higher, not in '||rdbms_release);
  END IF;
END;
/
WHENEVER SQLERROR CONTINUE;

@@sqdrop.sql
SPOOL OFF;
@@sqcusr.sql

SET VER OFF;
CONNECT sqltxplain/&&SQLTXPLAIN_PASSWORD
UNDEFINE SQLTXPLAIN_PASSWORD
SET VER ON;
--ALTER SESSION DISABLE GUARD;

@@squtltest.sql
@@sqctab.sql
@@sqcpkg.sql

PRO SQCREATE completed. Installation completed successfully.
