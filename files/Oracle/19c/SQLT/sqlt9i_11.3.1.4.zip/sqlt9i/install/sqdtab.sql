SET ECHO ON TERM ON;
REM
REM $Header: 215187.1 sqdtab.sql 11.3.1.0 2009/11/21 csierra $
REM
REM Copyright (c) 2000-2009, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   carlos.sierra@oracle.com
REM
REM SCRIPT
REM   sqdtab.sql
REM
REM DESCRIPTION
REM   This script drops existing SQLTXPLAIN objects.
REM
REM PRE-REQUISITES
REM   1. This script must be executed connected INTERNAL (SYS) as
REM      SYSDBA or as SQLTXPLAIN
REM
REM PARAMETERS
REM   1. None
REM
REM EXECUTION
REM   1. Navigate to sqlt/install directory
REM   2. Start SQL*Plus connecting INTERNAL (SYS) as SYSDBA or as
REM      SQLTXPLAIN
REM   3. Execute script sqdtab.sql
REM
REM EXAMPLE
REM   # cd sqlt/install
REM   # sqlplus /nolog
REM   SQL> connect / as sysdba
REM   SQL> start sqdtab.sql
REM
REM NOTES
REM   1. This script is executed automatically by sqdrop.sql
REM
SET ECHO OFF TERM OFF;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
BEGIN
  IF USER NOT IN ('SYS', 'SQLTXPLAIN') THEN
    RAISE_APPLICATION_ERROR(-20100, 'Drop script failed - sqdtab.sql should be executed connected as SYS or SQLTXPLAIN, not as '||USER);
  END IF;
END;
/
WHENEVER SQLERROR CONTINUE;
SET ECHO ON;

/* - packages - */
DROP PACKAGE BODY sqltxplain.sqlt$c;
DROP PACKAGE BODY sqltxplain.sqlt$m;
DROP PACKAGE BODY sqltxplain.sqlt$r;
DROP PACKAGE BODY sqltxplain.sqlt$p;
DROP PACKAGE BODY sqltxplain.sqlt$i;
DROP PACKAGE BODY sqltxplain.sqlt$a;
DROP PACKAGE BODY sqltxplain.sqlt$d;
DROP PACKAGE      sqltxplain.sqlt$c;
DROP PACKAGE      sqltxplain.sqlt$m;
DROP PACKAGE      sqltxplain.sqlt$r;
DROP PACKAGE      sqltxplain.sqlt$p;
DROP PACKAGE      sqltxplain.sqlt$i;
DROP PACKAGE      sqltxplain.sqlt$a;
DROP PACKAGE      sqltxplain.sqlt$d;

/* - procedures - */
DROP PROCEDURE sqltxplain.sqlt$_execute_tuning_task;

/* - views - */
DROP VIEW sqltxplain.sqlt$_v$sqltext_with_newlines;
DROP VIEW sqltxplain.sqlt$_v$sql_workarea;
DROP VIEW sqltxplain.sqlt$_v$sql_plan_statistics;
DROP VIEW sqltxplain.sqlt$_v$sql_plan;
DROP VIEW sqltxplain.sqlt$_v$sql;
DROP VIEW sqltxplain.sqlt$_v$session;
DROP VIEW sqltxplain.sqlt$_gv$system_parameter2;
DROP VIEW sqltxplain.sqlt$_gv$sqltext_with_newlines;
DROP VIEW sqltxplain.sqlt$_gv$sql_workarea;
DROP VIEW sqltxplain.sqlt$_gv$sql_plan_statistics;
DROP VIEW sqltxplain.sqlt$_gv$sql_plan;
DROP VIEW sqltxplain.sqlt$_gv$sql;
DROP VIEW sqltxplain.sqlt$_gv$parameter2;
DROP VIEW sqltxplain.sqlt$_dba_tab_cols;
DROP VIEW sqltxplain.sqlt$_dba_subpart_col_stats;
DROP VIEW sqltxplain.sqlt$_dba_segments;
DROP VIEW sqltxplain.sqlt$_dba_part_col_stats;
DROP VIEW sqltxplain.sqlt$_dba_outlines;
DROP VIEW sqltxplain.sqlt$_dba_outline_nodes;
DROP VIEW sqltxplain.sqlt$_dba_outline_hints;
DROP VIEW sqltxplain.sqlt$_dba_tab_statistics;
DROP VIEW sqltxplain.sqlt$_dba_ind_statistics;
DROP VIEW sqltxplain.sqlt$_dba_tab_col_statistics;
DROP VIEW sqltxplain.sqlg$_join_order_v1;
DROP VIEW sqltxplain.sqlg$_join_order_v2;

/* - tables - */
DROP TABLE sqltxplain.sqlg$_10053_parse;
DROP TABLE sqltxplain.sqlt$_10053_parse;
DROP TABLE sqltxplain.sqlg$_adv_rationale;
DROP TABLE sqltxplain.sqlt$_adv_rationale;
DROP TABLE sqltxplain.sqlt$_constraints;
DROP TABLE sqltxplain.sqlg$_dba_hist_snapshot;
DROP TABLE sqltxplain.sqlt$_dba_hist_snapshot;
DROP TABLE sqltxplain.sqlg$_dba_hist_sql_plan;
DROP TABLE sqltxplain.sqlt$_dba_hist_sql_plan;
DROP TABLE sqltxplain.sqlt$_dba_hist_sqlstat;
DROP TABLE sqltxplain.sqlg$_dba_hist_sqlstat;
DROP TABLE sqltxplain.sqlg$_dba_hist_sqltext;
DROP TABLE sqltxplain.sqlt$_dba_hist_sqltext;
DROP TABLE sqltxplain.sqlg$_dba_part_histograms;
DROP TABLE sqltxplain.sqlt$_dba_part_histograms;
DROP TABLE sqltxplain.sqlg$_dba_subpart_histograms;
DROP TABLE sqltxplain.sqlt$_dba_subpart_histograms;
DROP TABLE sqltxplain.sqlg$_dba_tab_histograms;
DROP TABLE sqltxplain.sqlt$_dba_tab_histograms;
DROP TABLE sqltxplain.sqlg$_dbms_xplan;
DROP TABLE sqltxplain.sqlt$_dbms_xplan;
DROP TABLE sqltxplain.sqlg$_error;
DROP TABLE sqltxplain.sqlt$_error;
DROP TABLE sqltxplain.sqlg$_gv$sql_bind_capture;
DROP TABLE sqltxplain.sqlt$_gv$sql_bind_capture;
DROP TABLE sqltxplain.sqlg$_histogram_cols;
DROP TABLE sqltxplain.sqlt$_histogram_cols;
DROP TABLE sqltxplain.sqlt$_ind_columns;
DROP TABLE sqltxplain.sqlt$_ind_partitions;
DROP TABLE sqltxplain.sqlt$_ind_subpartitions;
DROP TABLE sqltxplain.sqlt$_indexes;
DROP TABLE sqltxplain.sqlt$_ind_statistics;
DROP TABLE sqltxplain.sqlg$_object_dependency;
DROP TABLE sqltxplain.sqlt$_object_dependency;
DROP TABLE sqltxplain.sqlg$_objects;
DROP TABLE sqltxplain.sqlt$_objects;
DROP TABLE sqltxplain.sqlg$_optstat_ind_history;
DROP TABLE sqltxplain.sqlt$_optstat_ind_history;
DROP TABLE sqltxplain.sqlg$_optstat_tab_history;
DROP TABLE sqltxplain.sqlt$_optstat_tab_history;
DROP TABLE sqltxplain.sqlg$_optstat_histgrm_history;
DROP TABLE sqltxplain.sqlg$_optstat_histhead_history;
DROP TABLE sqltxplain.sqlg$_optstat_aux_history;
DROP TABLE sqltxplain.sqlg$_optstat_opr;
DROP TABLE sqltxplain.sqlt$_outline_hints;
DROP TABLE sqltxplain.sqlt$_outlines;
DROP TABLE sqltxplain.sqlt$_parameter2;
DROP TABLE sqltxplain.sqli$_parameter_apps;
DROP TABLE sqltxplain.sqlt$_parameter_apps;
DROP TABLE sqltxplain.sqlg$_peeked_binds;
DROP TABLE sqltxplain.sqlt$_peeked_binds;
DROP TABLE sqltxplain.sqlt$_plan_table;
DROP TABLE sqltxplain.sqlt$_segment_statistics;
DROP TABLE sqltxplain.sqli$_segments;
DROP TABLE sqltxplain.sqlt$_segments;
DROP TABLE sqltxplain.sqlt$_session_event;
DROP TABLE sqltxplain.sqlt$_sesstat;
DROP TABLE sqltxplain.sqlg$_sql;
DROP TABLE sqltxplain.sqlt$_sql;
DROP TABLE sqltxplain.sqlg$_sql_monitor;
DROP TABLE sqltxplain.sqlt$_sql_monitor;
DROP TABLE sqltxplain.sqlg$_sql_plan;
DROP TABLE sqltxplain.sqlt$_sql_plan;
DROP TABLE sqltxplain.sqlg$_sql_plan_monitor;
DROP TABLE sqltxplain.sqlt$_sql_plan_monitor;
DROP TABLE sqltxplain.sqlg$_sql_plan_statistics;
DROP TABLE sqltxplain.sqlt$_sql_plan_statistics;
DROP TABLE sqltxplain.sqlt$_sql_profile_hints;
DROP TABLE sqltxplain.sqlt$_sql_profiles;
DROP TABLE sqltxplain.sqlg$_sql_workarea;
DROP TABLE sqltxplain.sqlt$_sql_workarea;
DROP TABLE sqltxplain.sqlt$_statement;
DROP TABLE sqltxplain.sqlg$_statement_tune;
DROP TABLE sqltxplain.sqlt$_statement_tune;
DROP TABLE sqltxplain.sqlt$_stattab;
DROP TABLE sqltxplain.sqli$_stattab_temp;
DROP TABLE sqltxplain.sqlt$_stattab_temp;
DROP TABLE sqltxplain.sqlt$_tab_columns;
DROP TABLE sqltxplain.sqlt$_tab_col_statistics;
DROP TABLE sqltxplain.sqlg$_tab_part_columns;
DROP TABLE sqltxplain.sqlt$_tab_part_columns;
DROP TABLE sqltxplain.sqlt$_tab_partitions;
DROP TABLE sqltxplain.sqlg$_tab_subpart_columns;
DROP TABLE sqltxplain.sqlt$_tab_subpart_columns;
DROP TABLE sqltxplain.sqlt$_tab_subpartitions;
DROP TABLE sqltxplain.sqlt$_tables;
DROP TABLE sqltxplain.sqlt$_tab_statistics;
DROP TABLE sqltxplain.sqlg$_tablespaces;
DROP TABLE sqltxplain.sqlt$_tablespaces;
DROP TABLE sqltxplain.sqli$_tool_parameter;
DROP TABLE sqltxplain.sqlt$_tool_parameter;
DROP TABLE sqltxplain.sqlg$_warning;
DROP TABLE sqltxplain.sqlt$_warning;
DROP TABLE sqltxplain.sqlt$_hist_files;
DROP TABLE sqltxplain.sqlg$_gv$sql_shared_cursor;
DROP TABLE sqltxplain.sqlt$_other_xml;
DROP TABLE sqltxplain.sqlt$_other_xml_hints;
DROP TABLE sqltxplain.sqlg$_xplore_test;
DROP TABLE sqltxplain.sqlg$_join_order;

/* - sequences - */
DROP SEQUENCE sqltxplain.sqlg$_error_id_s;
DROP SEQUENCE sqltxplain.sqlt$_error_id_s;
DROP SEQUENCE sqltxplain.sqlt$_line_id_s;
DROP SEQUENCE sqltxplain.sqlt$_statement_id_s;
DROP SEQUENCE sqltxplain.sqlt$_pk_id_s;

/* - types */
DROP TYPE sqltxplain.varchar2_table;
DROP TYPE sqltxplain.bind_nt;
DROP TYPE sqltxplain.bind_t;

SET ECHO OFF TERM ON;
PRO SQDTAB completed. Ignore errors from this script
