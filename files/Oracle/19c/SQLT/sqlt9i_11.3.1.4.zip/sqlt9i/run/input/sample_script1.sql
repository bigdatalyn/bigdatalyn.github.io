REM
REM Sample SCRIPT to be used as input to sqltxecute.sql
REM
REM Bind variables (optional)
REM ~~~~~~~~~~~~~~
REM

VAR b0 VARCHAR2(200);
VAR b1 NUMBER;

EXEC :b0 := 'MRP-M1-PRD';
EXEC :b1 := 207;

REM
REM ONE DML SQL statement to be executed (required)
REM ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
REM

SELECT /* ^^unique_id */
  comps.component_item_id ,
  bill.organization_id ,
  bill.assembly_item_id ,
  comps.operation_seq_num ,
  subs.substitute_component_id ,
  substitute_item_quantity
FROM
  bom_bill_of_materials bill ,
  mrp_plan_organizations_v orgs ,
  mrp_system_items msi ,
  bom_inventory_components comps ,
  bom_substitute_components subs
WHERE
  ((((((((((bill.common_bill_sequence_id=
  decode(orgs.planned_organization,
  null ,null ,comps.bill_sequence_id)
  and bill.organization_id=orgs.planned_organization)
  and orgs.compile_designator=:b0)
  and orgs.organization_id=:b1)
  and msi.organization_id=orgs.planned_organization)
  and msi.compile_designator=orgs.compile_designator)
  and msi.inventory_item_id=comps.component_item_id)
  and TRUNC(comps.effectivity_date)<=TRUNC(sysdate ))
  and comps.implementation_date is  not null )
  and NVL(comps.disable_date,(sysdate +1))<sysdate )
  and comps.component_sequence_id=subs.component_sequence_id)
ORDER BY
  bill.organization_id,
  comps.component_item_id;

REM
REM Notes:
REM 1. Input script must contain one and only one SQL.
REM 2. To precisely identify the SQL, add optional
REM    token ^^unique_id within a comment
REM    (required on 9i and recommended on 10g and 11g).
REM 3. To force a hard-parse, add a space in any valid place
REM    of the SQL before each use of XECUTE.
REM    (required if ^^unique_id token is not used).
REM 4. The SQL must end with a semi-colon ";"
REM    in order to be complete and executable (required).
REM 5. The input script must be able to execute stand-alone.
REM    SQL> START sample_script1.sql
REM 6. The script can include ALTER SESSION commands.
REM
