REM
REM Sample SCRIPT to be used as input to sqltxecute.sql
REM
REM Bind variables (optional)
REM ~~~~~~~~~~~~~~
REM

VAR b1 CHAR(1);

EXEC :b1 := '1';

REM
REM ONE DML SQL statement to be executed (required)
REM ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
REM

select v.*, (orders_total - credit_limit) over_limit
from customer_v v /* ^^unique_id */
where orders_total > credit_limit
and customer_type = :b1
order by over_limit desc;

REM
REM Notes:
REM 1. Input script must contain one and only one SQL.
REM 2. To precisely identify the SQL, add optional
REM    token ^^unique_id within a comment
REM    (required on 9i and recommended on 10g and 11g).
REM 3. To force a hard-parse, add a space in any valid place
REM    of the SQL before each use of XECUTE.
REM    (required if ^^unique_id token is not used).
REM 4. The SQL must end with a semi-colon ";"
REM    in order to be complete and executable (required).
REM 5. The input script must be able to execute stand-alone.
REM    SQL> START sample_script0.sql
REM 6. The script can include ALTER SESSION commands.
REM
