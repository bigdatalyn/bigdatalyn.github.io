SET DEF ^ ECHO ON TERM ON SERVEROUT ON SIZE 1000000 NUMF "" SQLP SQL>;
SPO sqltxtract.log;
REM
REM $Header: 215187.1 sqltxtract2.sql 11.3.1.4 2010/04/11 csierra $
REM
REM Copyright (c) 2000-2010, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   carlos.sierra@oracle.com
REM
REM SCRIPT
REM   sqltxtract2.sql
REM
REM DESCRIPTION
REM   This script generates a set of comprehensive reports with query
REM   tuning diagnostic details. It requires as input a combination
REM   of one or more of these identifiers for one SQL: hash_value,
REM   address, child_number, sql_id or plan_hash_value. The SQL must
REM   be memory-resident (gv$sql).
REM
REM PRE-REQUISITES
REM   1. Install the SQLT tool as per instructions.txt provided
REM   2. Determine a combination of identifiers that uniquely
REM      identify one SQL that still resides in memory (gv$sql).
REM   3. To get plan statistics, STATISTICS_LEVEL must be set to ALL
REM      before the desired SQL is executed
REM   4. The user that executes this method must comply with:
REM        o  Be the application schema owner that originated the SQL
REM        o  Must be granted those privileges shown in script
REM           sqlt/install/sqguser.sql
REM
REM PARAMETERS
REM   Combination of one or many IDs of the SQL to be extracted
REM     1. hash_value (optional)
REM     2. address (optional)
REM     3. child_number (optional)
REM     4. sql_id (optional)
REM     5. plan_hash_value (optional)
REM   To skip any parameter enter keyword NULL in its inline position
REM
REM EXECUTION
REM   1. Navigate to sqlt/run server directory
REM   2. Start SQL*Plus in server connecting as application user
REM   3. Execute script sqltxtract2.sql passing a combination of one
REM      or many IDs of one memory-resident SQL
REM   4. Provide all generated files to the requestor
REM
REM EXAMPLE
REM   # cd sqlt/run
REM   # sqlplus [apps user]
REM   SQL> start sqltxtract2.sql [hash_value] NULL NULL NULL NULL;
REM   SQL> start sqltxtract2.sql 168272285 NULL NULL NULL NULL;
REM   SQL> start sqltxtract2.sql [hash_value] [address] NULL NULL NULL;
REM   SQL> start sqltxtract2.sql 168272285 57E1B6A0 NULL NULL NULL;
REM   SQL> start sqltxtract2.sql NULL NULL [child_number] [sql_id] NULL;
REM   SQL> start sqltxtract2.sql NULL NULL 0 0w6uydn50g8cx NULL;
REM   SQL> start sqltxtract2.sql NULL NULL NULL NULL [plan_hash_value];
REM   SQL> start sqltxtract2.sql NULL NULL NULL NULL 1126297136;
REM
REM NOTES
REM   1. For hash_value or sql_id parameters use sqltxtract.sql
REM   2. For possible errors see sqltxtract.log
REM
SET ECHO OFF;
PRO
PRO Parameter 1: HASH_VALUE (optional)
PRO Parameter 2: ADDRESS (optional)
PRO Parameter 3: CHILD_NUMBER (optional)
PRO Parameter 4: SQL_ID (optional)
PRO Parameter 5: PLAN_HASH_VALUE (optional)
PRO
DEF opt_hash_value = '^1';
DEF opt_address = '^2';
DEF opt_child_number = '^3';
DEF opt_sql_id = '^4';
DEF opt_plan_hash_value = '^5';
PRO
PRO Values passed to sqltxtract2.sql:
PRO ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
PRO HASH_VALUE     : ^^opt_hash_value
PRO ADDRESS        : ^^opt_address
PRO CHILD_NUMBER   : ^^opt_child_number
PRO SQL_ID         : ^^opt_sql_id
PRO PLAN_HASH_VALUE: ^^opt_plan_hash_value
PRO
SET TERM OFF HEA ON LIN 2000 PAGES 1000 TRIMS ON TIM OFF;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
PRO
PRO NOTE:
PRO If you get an ORA-06550 followed by PLS-00302: component 'INITIALIZATION' must be declared,
PRO then review *.lis files created during installation and fix errors reported.
PRO
EXEC sqltxplain.sqlt$r.initialization;
DEF _SQLPLUS_RELEASE
COL connected_user NEW_V connected_user FOR A30;
SELECT user connected_user FROM DUAL;
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') current_time FROM DUAL;
SELECT * FROM v$version;
COL library FOR A64 HEA 'Libraries';
SELECT object_type||' '||object_name||' ('||status||')' library
  FROM all_objects
 WHERE owner = 'SQLTXPLAIN'
   AND object_type IN ('PACKAGE', 'PACKAGE BODY', 'PROCEDURE', 'FUNCTION')
 ORDER BY
       object_type, object_name;
COL tool_version FOR A16 HEA 'Tool Version';
SELECT sqltxplain.sqlt$d.get_param('tool_version', 'I') tool_version FROM DUAL;
COL install_date FOR A16 HEA 'Install Date';
SELECT sqltxplain.sqlt$d.get_param('install_date', 'I') install_date FROM DUAL;
COL host_name FOR A80 HEA 'Host Name';
SELECT sqltxplain.sqlt$d.get_param('host_name_short', 'I') host_name FROM DUAL;
COL column_value FOR A80 HEA 'Directories';
SELECT column_value FROM TABLE(sqltxplain.sqlt$d.directories);
COL column_value FOR A80 HEA 'Libraries';
SELECT column_value FROM TABLE(sqltxplain.sqlt$d.packages);
EXEC sqltxplain.sqlt$d.validate_tool_version('11.3.1.4');
SET TERM ON;
PRO
PRO
PRO NOTE:
PRO You connected as ^^connected_user
PRO If you get an error please verify the following:
PRO 1. That you connected as the application user that executed original SQL.
PRO 2. That your SQL does exists in V$SQL or AWR.
PRO 3. In case of a disconnect (ORA-03113, ORA-03114 or ORA-07445),
PRO    try re-executing SQLT since it detects BUG 6356566 and handles it.
PRO 4. To fix BUG 6356566, read ALERT log and provide to Support referenced trace.
PRO
PRO ... please wait
PRO
SET TERM OFF;
VAR v_statement_id VARCHAR2(256);
VAR v_stat_id VARCHAR2(256);
BEGIN
  sqltxplain.sqlt$i.sqltxtract2 (
    p_hash_value      => '^^opt_hash_value',
    p_address         => '^^opt_address',
    p_child_number    => '^^opt_child_number',
    p_sql_id          => '^^opt_sql_id',
    p_plan_hash_value => '^^opt_plan_hash_value',
    x_statement_id    => :v_statement_id,
    x_stat_id         => :v_stat_id );
END;
/
COL statement_id2 NEW_V statement_id2 FOR A16;
COL server_directory NOPRI NEW_V server_directory FOR A512;
COL copy_file_name NOPRI NEW_V copy_file_name FOR A256;
COL tc_script_file_name NOPRI NEW_V tc_script_file_name FOR A256;
COL tc_builder_script_file_name NOPRI NEW_V tc_builder_script_file_name FOR A256;
COL exp_params_file_name NOPRI NEW_V exp_params_file_name FOR A256;
SELECT :v_statement_id statement_id2, sqltxplain.sqlt$d.get_param('output_directory', 'I') server_directory FROM DUAL;
SET TERM ON;
PRO
PRO ... sqlt_s^^statement_id2._* files have been created into server directory:
PRO ... ^^server_directory
PRO ... copying now generated files into local directory
PRO
SET TERM OFF ECHO OFF FEED OFF FLU OFF HEA OFF LIN 2000 NEWP NONE PAGES 0 SHOW OFF SQLC MIX TAB OFF TRIMS ON VER OFF TIM OFF ARRAY 100 SQLP SQL> BLO . RECSEP OFF SERVEROUT ON SIZE 1000000 FOR TRU;
COL column_value FOR A2000;
WHENEVER OSERROR CONTINUE;
WHENEVER SQLERROR CONTINUE;
PRO No fatal errors!
SPO OFF;

SELECT NVL(REPLACE(file_sqlt_main, '.', '_c.'), 'sqlt_s^^statement_id2._main.html') copy_file_name
FROM sqltxplain.sqlt$_statement WHERE statement_id = :v_statement_id;
SPO ^^copy_file_name.;
SELECT column_value FROM TABLE(sqltxplain.sqlt$r.display_file('MAIN', :v_statement_id));
SPO OFF;
EXEC sqltxplain.sqlt$r.store_file;

SELECT NVL(REPLACE(file_sqlt_frames, '.', '_c.'), 'sqlt_s^^statement_id2._frames.html') copy_file_name
FROM sqltxplain.sqlt$_statement WHERE statement_id = :v_statement_id;
SPO ^^copy_file_name.;
SELECT column_value FROM TABLE(sqltxplain.sqlt$r.display_file('FRAMES', :v_statement_id));
SPO OFF;
EXEC sqltxplain.sqlt$r.store_file;

SELECT NVL(REPLACE(file_sqlt_metadata, '.', '_c.'), 'sqlt_s^^statement_id2._metadata.sql') copy_file_name
FROM sqltxplain.sqlt$_statement WHERE statement_id = :v_statement_id;
SPO ^^copy_file_name.;
SELECT column_value FROM TABLE(sqltxplain.sqlt$r.display_file('METADATA', :v_statement_id));
SPO OFF;
EXEC sqltxplain.sqlt$r.store_file;

SELECT NVL(REPLACE(file_sqlt_setenv, '.', '_c.'), 'sqlt_s^^statement_id2._setenv.sql') copy_file_name
FROM sqltxplain.sqlt$_statement WHERE statement_id = :v_statement_id;
SPO ^^copy_file_name.;
SELECT column_value FROM TABLE(sqltxplain.sqlt$r.display_file('SETENV', :v_statement_id));
SPO OFF;
EXEC sqltxplain.sqlt$r.store_file;

SELECT NVL(REPLACE(file_sqlt_readme, '.', '_c.'), 'sqlt_s^^statement_id2._readme.txt') copy_file_name
FROM sqltxplain.sqlt$_statement WHERE statement_id = :v_statement_id;
SPO ^^copy_file_name.;
SELECT column_value FROM TABLE(sqltxplain.sqlt$r.display_file('README', :v_statement_id));
SPO OFF;
EXEC sqltxplain.sqlt$r.store_file;

SELECT NVL(REPLACE(file_sqlt_trace, '.', '_c.'), 'sqlt_s^^statement_id2._trace.trc') copy_file_name
FROM sqltxplain.sqlt$_statement WHERE statement_id = :v_statement_id;
SPO ^^copy_file_name.;
SELECT column_value FROM TABLE(sqltxplain.sqlt$r.display_file('TRACE', :v_statement_id));
SPO OFF;
EXEC sqltxplain.sqlt$r.store_file;

SELECT NVL(REPLACE(file_sqlt_lite, '.', '_c.'), 'sqlt_s^^statement_id2._lite.txt') copy_file_name
FROM sqltxplain.sqlt$_statement WHERE statement_id = :v_statement_id;
SPO ^^copy_file_name.;
SELECT column_value FROM TABLE(sqltxplain.sqlt$r.display_file('LITE', :v_statement_id));
SPO OFF;
EXEC sqltxplain.sqlt$r.store_file;

SELECT NVL(REPLACE(file_sqlt_profile, '.', '_c.'), 'sqlt_s^^statement_id2._profile.txt') copy_file_name
FROM sqltxplain.sqlt$_statement WHERE statement_id = :v_statement_id;
SPO ^^copy_file_name.;
SELECT column_value FROM TABLE(sqltxplain.sqlt$r.display_file('SQLPROF', :v_statement_id));
SPO OFF;
EXEC sqltxplain.sqlt$r.store_file;

SELECT NVL(REPLACE(file_sqlt_exp_params, '.', '_c.'), 'sqlt_s^^statement_id2._parfile.txt') exp_params_file_name
FROM sqltxplain.sqlt$_statement WHERE statement_id = :v_statement_id;
SPO ^^exp_params_file_name.;
SELECT column_value FROM TABLE(sqltxplain.sqlt$r.display_file('EXP_PARAMS', :v_statement_id));
SPO OFF;
EXEC sqltxplain.sqlt$r.store_file;

SELECT NVL(REPLACE(file_sqlt_tcscript, '.', '_c.'), 'sqlt_s^^statement_id2._tc_script.sql') tc_script_file_name
FROM sqltxplain.sqlt$_statement WHERE statement_id = :v_statement_id;
SPO ^^tc_script_file_name.;
SELECT column_value FROM TABLE(sqltxplain.sqlt$r.display_file('TCSCRIPT', :v_statement_id));
SPO OFF;
EXEC sqltxplain.sqlt$r.store_file;

SELECT NVL(REPLACE(file_sqlt_tcsql, '.', '_c.'), 'sqlt_s^^statement_id2._tc_sql.sql') copy_file_name
FROM sqltxplain.sqlt$_statement WHERE statement_id = :v_statement_id;
SPO ^^copy_file_name.;
SELECT column_value FROM TABLE(sqltxplain.sqlt$r.display_file('TCSQL', :v_statement_id));
SPO OFF;
EXEC sqltxplain.sqlt$r.store_file;

SELECT NVL(REPLACE(file_sqlt_tcbuilder, '.', '_c.'), 'sqlt_s^^statement_id2._tc_builder.sql') tc_builder_script_file_name
FROM sqltxplain.sqlt$_statement WHERE statement_id = :v_statement_id;
SPO ^^tc_builder_script_file_name.;
SELECT column_value FROM TABLE(sqltxplain.sqlt$r.display_file('TCBUILDER', :v_statement_id));
SPO OFF;
EXEC sqltxplain.sqlt$r.store_file;

@^^tc_builder_script_file_name.
SPO sqlt_s^^statement_id2._xtract.log;
GET sqltxtract.log
.
SET TERM ON
PRO
PRO ... exporting SQLT tables needed to create a test case
PRO
PRO ... if sqlt_s^^statement_id2..dmp is not created, please execute manually from server:
PRO ... # exp sqltxplain parfile=^^exp_params_file_name.
PRO
ACC sqltxplain_password PROMPT '...please enter password for SQLTXPLAIN: ' hide;
HO exp sqltxplain/^^sqltxplain_password. parfile=^^exp_params_file_name.
UNDEFINE SQLTXPLAIN_PASSWORD
PRO
PRO ... generating now a zip with all generated files
PRO
PRO ... if sqlt_s^^statement_id2..zip is not created, please execute manually:
PRO ... # zip -mT sqlt_s^^statement_id2. sqlt_s^^statement_id2.* sqltxtract.log
PRO ... # zip -d sqlt_s^^statement_id2. sqltxtract.log
PRO
SPO OFF;
HO zip -mT sqlt_s^^statement_id2. sqlt_s^^statement_id2.* sqltxtract.log
HO zip -d sqlt_s^^statement_id2. sqltxtract.log
CL COL;
UNDEFINE 1 2 3 4 5 opt_hash_value opt_address opt_child_number opt_sql_id opt_plan_hash_value server_directory copy_file_name;
UNDEFINE exp_params_file_name;
SET DEF ON
PRO SQLTXTRACT2 completed.
