SET ECHO ON TERM ON;
SPOOL sqltcdirs.lis;
REM
REM $Header: 215187.1 sqltcdirs.sql 11.3.1.4 2010/04/11 csierra $
REM
REM Copyright (c) 2000-2010, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   carlos.sierra@oracle.com
REM
REM SCRIPT
REM   sqltcdirs.sql
REM
REM DESCRIPTION
REM   This script creates a pointer to the server directory that
REM   contains all SQLTXPLAIN output reports before being copied to
REM   the local SQL*Plus directory
REM
REM PRE-REQUISITES
REM   1. This script must be executed connected INTERNAL (SYS) as
REM      SYSDBA
REM   2. SQLTXPLAIN must have read/write access to directory
REM      specified
REM
REM PARAMETERS
REM   1. Full path of existing staging directory (required)
REM      This value is case sensitive, and actual directory must
REM      exists in server prior to the execution of this script
REM
REM EXECUTION
REM   1. Navigate to sqlt/utl directory
REM   2. Start SQL*Plus connecting INTERNAL (SYS) as SYSDBA
REM   3. Execute script sqltcdirs.sql
REM
REM EXAMPLE
REM   # cd sqlt/utl
REM   # sqlplus /nolog
REM   SQL> connect / as sysdba
REM   SQL> start sqltcdirs.sql [full stage directory path]
REM   SQL> start sqltcdirs.sql /home/csierra
REM
REM NOTES
REM   1. For possible errors see sqltcdirs.lis file
REM
WHENEVER SQLERROR EXIT SQL.SQLCODE;
BEGIN
  IF USER != 'SYS' THEN
    RAISE_APPLICATION_ERROR(-20100, 'Directory alias should be created connected as SYS, not as '||USER);
  END IF;
END;
/

/* ---------------------------------------------------------------------- */

PRO ... Creating SQLT$ Stage Directory

DEF directory_path = '&1';

BEGIN
  IF '&&directory_path' LIKE '%?%' OR '&&directory_path' LIKE '%*%' OR '&&directory_path' LIKE '%$%' THEN
    RAISE_APPLICATION_ERROR(-20101, 'Directory &&directory_path cannot contain "?", "*" or "$" symbols');
  END IF;
  IF SUBSTR('&&directory_path', LENGTH('&&directory_path'), 1) IN (' ', '/', '\') THEN
    RAISE_APPLICATION_ERROR(-20102, 'Directory &&directory_path cannot end with " ", "/" or "\" symbols');
  END IF;
END;
/

CREATE OR REPLACE DIRECTORY SQLT$STAGE AS '&&directory_path';

GRANT READ,WRITE ON DIRECTORY SQLT$STAGE TO sqltxplain;

WHENEVER SQLERROR CONTINUE;
SPOOL OFF;
UNDEFINE 1 DIRECTORY_PATH
