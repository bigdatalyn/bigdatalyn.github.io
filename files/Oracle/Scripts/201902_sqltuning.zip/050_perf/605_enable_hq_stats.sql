set pages 10000 lines 180
set trims on trimo on tab off
col table_name format a10
col partition_name format a20
connect sys/oracle@localhost/pdb1 as sysdba

BEGIN
  DBMS_STATS.SET_GLOBAL_PREFS('AUTO_TASK_STATUS','ON');
  DBMS_STATS.SET_GLOBAL_PREFS('AUTO_TASK_MAX_RUN_TIME','180');
  DBMS_STATS.SET_GLOBAL_PREFS('AUTO_TASK_INTERVAL','240');
END;
/

exit;
