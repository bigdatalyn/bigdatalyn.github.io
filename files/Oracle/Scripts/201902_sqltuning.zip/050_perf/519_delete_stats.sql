connect system/oracle@localhost/pdb1

BEGIN
  DBMS_STATS.DELETE_TABLE_STATS (
    ownname => 'SH',
    tabname => 'SALES',
    stat_category => 'REALTIME_STATS'
);
END;
/

exit;
