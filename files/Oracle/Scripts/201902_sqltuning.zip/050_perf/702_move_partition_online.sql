connect sh/oracle@localhost/pdb1

alter table sales move partition SALES_Q1_1998 tablespace users online;

exit;
