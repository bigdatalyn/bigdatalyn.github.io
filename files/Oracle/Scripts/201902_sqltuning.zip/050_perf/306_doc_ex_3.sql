connect sh/oracle@localhost/pdb1

select count(*)
  from products p, sales s 
 where p.prod_id = s.prod_id
   and p.prod_status = 'obsolete';

VARIABLE v_rep clob;

BEGIN
  :v_rep := DBMS_XPLAN.COMPARE_PLANS(
    reference_plan    => cursor_cache_object('45ns3tzutg0ds'),
    compare_plan_list => plan_object_list(spm_object('SQL_aec814b0d452da8a')),
    TYPE              => 'TEXT',
    level             => 'TYPICAL',
    section           => 'ALL');
END;
/

SET LONG 1000000
SET PAGESIZE 50000
SET LINESIZE 200
SELECT :v_rep rep FROM DUAL;

exit;
