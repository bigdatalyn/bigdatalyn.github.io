connect sys/oracle@localhost/pdb1 as sysdba

alter system flush shared_pool;

exit;
