set pages 10000 lines 180
set trimo on trims on tab off
connect oe/oracle@localhost/pdb1

SELECT COUNT(*), manager_id
FROM   departments
WHERE  manager_id IN (SELECT /*+ UNNEST SEMIJOIN */ manager_id FROM employees)
AND    ROWNUM <= 2
GROUP BY manager_id;
select * from table(dbms_xplan.display_cursor(format => 'ALL'));
exit;
