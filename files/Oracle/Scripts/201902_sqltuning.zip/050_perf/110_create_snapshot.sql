connect system/oracle@localhost/pdb1

exec dbms_workload_repository.create_snapshot();

exit;
