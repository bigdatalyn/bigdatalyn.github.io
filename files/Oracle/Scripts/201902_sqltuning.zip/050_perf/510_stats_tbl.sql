connect system/oracle@localhost/pdb1

BEGIN
  DBMS_STATS.CREATE_STAT_TABLE ( 
    ownname => 'SH'
,   stattab => 'OPT_STATS'
);
END;
/

exit;
