connect sh/oracle@localhost/pdb1

drop index newprodidx;

EXPLAIN PLAN 
  SET STATEMENT_ID='TST1' FOR 
  SELECT COUNT(*) FROM products WHERE prod_min_price>100;

CREATE INDEX newprodidx ON products(prod_min_price); 

EXPLAIN PLAN 
  SET STATEMENT_ID='TST2' FOR 
  SELECT COUNT(*) FROM products WHERE prod_min_price>100;

VARIABLE v_rep clob;

BEGIN
  :v_rep := DBMS_XPLAN.COMPARE_PLANS(
    reference_plan    => plan_table_object('SH', 'PLAN_TABLE', 'TST1', NULL),
    compare_plan_list => plan_object_list(plan_table_object('SH', 'PLAN_TABLE', 'TST2', NULL)),
    TYPE              => 'TEXT', 
    level             => 'TYPICAL', 
    section           => 'ALL');
END;
/

SET LONG 1000000
SET PAGESIZE 50000
SET LINESIZE 200
SELECT :v_rep rep FROM DUAL;

exit;
