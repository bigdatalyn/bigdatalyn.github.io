connect sys/oracle@localhost/pdb1 as sysdba

BEGIN
 DBMS_STATS.GATHER_TABLE_STATS('SH', 'SALES_NON_PART', METHOD_OPT=>'FOR ALL COLUMNS SIZE 2');
END;
/

exit;
