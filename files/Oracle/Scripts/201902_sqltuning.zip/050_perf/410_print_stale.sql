connect sys/oracle@localhost/pdb1 as sysdba

SET SERVEROUTPUT ON
DECLARE
  obj_list DBMS_STATS.ObjectTab := DBMS_STATS.ObjectTab() ;
BEGIN
  DBMS_STATS.GATHER_SCHEMA_STATS(ownname=>'SH', objlist=> obj_list, options=>'LIST STALE') ;
  dbms_output.put_line('Count: ' || obj_list.count);
  if obj_list.count > 0 then
    FOR i in obj_list.FIRST .. obj_list.LAST LOOP
      dbms_output.put_line(obj_list(i).objtype || ' ' || obj_list(i).ownname || '.' || obj_list(i).objname || ' ' || nvl(obj_list(i).partname, 'NonPartition') || ' – ' || nvl(obj_list(i).subpartname, '*'));
    END LOOP;
  end if;
END;
/
exit;
