set pages 10000 lines 180
set trims on trimo on tab off
connect sh/oracle@localhost/pdb1

SELECT COUNT(*) FROM sales WHERE quantity_sold > 50;
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_CURSOR(format=>'TYPICAL'));

exit;
