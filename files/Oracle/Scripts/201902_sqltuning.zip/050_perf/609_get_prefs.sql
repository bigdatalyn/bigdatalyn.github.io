set pages 10000 lines 180
set trims on trimo on tab off
col table_name format a10
col partition_name format a20
connect sys/oracle@localhost/pdb1 as sysdba
set serveroutput on

declare
  l_pv varchar2(200);
BEGIN
  l_pv := dbms_stats.get_prefs('AUTO_TASK_STATUS');
  dbms_output.put_line('AUTO_TASK_STATUS ' || l_pv);
  l_pv := dbms_stats.get_prefs('AUTO_TASK_MAX_RUN_TIME');
  dbms_output.put_line('AUTO_TASK_MAX_RUN_TIME ' || l_pv);
  l_pv := dbms_stats.get_prefs('AUTO_TASK_INTERVAL');
  dbms_output.put_line('AUTO_TASK_INTERVAL ' || l_pv);
END;
/

exit;
