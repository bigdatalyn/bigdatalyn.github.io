Sample Schema
https://github.com/oracle/db-sample-schemas/releases
