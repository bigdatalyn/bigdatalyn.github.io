set pages 1000 lines 180
set trims on trimo on tab off
col parameter_name  format a30
col parameter_value format a30
col description format a180

connect sys/oracle@localhost/pdb1 as sysdba

select parameter_name, parameter_value, parameter_type, is_default, is_output, is_modifiable_anytime, description from DBA_ADVISOR_PARAMETERS
where task_name = 'SYS_AUTO_SPM_EVOLVE_TASK'
order by parameter_name;

exit;
