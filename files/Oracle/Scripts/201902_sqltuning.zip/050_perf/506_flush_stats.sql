connect sys/oracle@localhost/pdb1 as sysdba

EXEC DBMS_STATS.FLUSH_DATABASE_MONITORING_INFO;

exit;
