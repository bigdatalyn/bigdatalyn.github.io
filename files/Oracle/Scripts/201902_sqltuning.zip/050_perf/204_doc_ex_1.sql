set pages 10000 lines 180
set trimo on trims on tab off
connect oe/oracle@localhost/pdb1

SELECT /*+ INDEX(e emp_emp_id_pk) */ COUNT(*) 
FROM   employees e 
WHERE  e.employee_id = 5;
select * from table(dbms_xplan.display_cursor(format => 'ALL'));
exit;
