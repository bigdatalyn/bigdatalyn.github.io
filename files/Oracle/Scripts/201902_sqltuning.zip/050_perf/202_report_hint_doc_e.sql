set pages 10000 lines 180
set trimo on trims on tab off
connect oe/oracle@localhost/pdb1

SELECT /*+ FIRST_ROWS(t1) */ COUNT(*)
FROM   jobs t1
WHERE t1.job_id IN (SELECT /*+ FULL(t1) */ job_id FROM employees t1);
select * from table(dbms_xplan.display_cursor(format => 'HINT_REPORT'));
exit;
