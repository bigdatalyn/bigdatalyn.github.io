set pages 10000 lines 180
set trimo on trims on tab off
connect oe/oracle@localhost/pdb1

SELECT /*+ ORDERED USE_NL(t1, t2) INDEX(t2) NLJ_PREFETCH(t2) */ COUNT(*)
FROM   jobs t1, employees t2
WHERE  t1.job_id = t2.employee_id;
select * from table(dbms_xplan.display_cursor(format => 'ALL'));
exit;
