connect system/oracle@localhost/pdb1

BEGIN
  DBMS_STATS.EXPORT_TABLE_STATS (
    ownname => 'SH',
    tabname => 'SALES',
    stattab => 'OPT_STATS',
    stat_category => 'OBJECT_STATS,REALTIME_STATS'
);
END;
/

exit;
