connect sh/oracle@localhost/pdb1

drop table sales_non_part;
create table sales_non_part as select * from sales where rownum = 0;

exit;
