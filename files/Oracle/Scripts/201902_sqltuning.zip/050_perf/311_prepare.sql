connect hr/oracle@localhost/pdb1

CREATE TABLE staff AS (SELECT * FROM employees);
CREATE UNIQUE INDEX staff_employee_id ON staff (employee_id);

exit;
