connect system/oracle@localhost/pdb1

exec dbms_stats.gather_table_stats('SH','SALES', estimate_percent => 100, method_opt => 'FOR ALL COLUMNS SIZE 2');

exit;
