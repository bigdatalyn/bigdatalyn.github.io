set pages 10000 lines 180
set trims on trimo on tab off
connect sh/oracle@localhost/pdb1

INSERT /*+ NO_GATHER_OPTIMIZER_STATISTICS */ 
  INTO sales(prod_id, cust_id, time_id, channel_id, promo_id, 
                  quantity_sold, amount_sold)
  SELECT prod_id, cust_id, time_id, channel_id, promo_id, 
         quantity_sold * 2, amount_sold * 2 
  FROM   sales;
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_CURSOR(format=>'TYPICAL'));
COMMIT;

exit;
