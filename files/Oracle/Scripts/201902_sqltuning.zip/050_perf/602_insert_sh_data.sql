connect sh/oracle@localhost/pdb1

-- insert 918K rows in sales
INSERT INTO sh.sales SELECT * FROM sh.sales;
-- update around 15% of sales rows 
UPDATE sh.sales SET amount_sold = amount_sold + 1 WHERE amount_sold > 100;
-- insert 1 row into customers
INSERT INTO sh.customers(cust_id, cust_first_name, cust_last_name, 
    cust_gender, cust_year_of_birth, cust_main_phone_number,  
    cust_street_address, cust_postal_code, cust_city_id, 
    cust_city, cust_state_province_id, cust_state_province, 
    country_id, cust_total, cust_total_id) 
  VALUES(188710, 'Jenny', 'Smith', 'F', '1966', '555-111-2222', 
    '400 oracle parkway','94065',51402, 'Redwood Shores', 
    52564, 'CA', 52790, 'Customer total', '52772');
COMMIT;

exit;
