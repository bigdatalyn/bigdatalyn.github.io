connect sys/oracle@localhost/catdb as sysdba
@?/rdbms/admin/dbmsrmanvpc.sql -vpd rco;
exit;

