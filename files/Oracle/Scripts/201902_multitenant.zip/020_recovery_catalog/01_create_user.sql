connect sys/oracle@localhost/catdb as sysdba

CREATE USER rco IDENTIFIED BY oracle
  TEMPORARY TABLESPACE temp
  DEFAULT TABLESPACE tools 
  QUOTA UNLIMITED ON tools;

GRANT RECOVERY_CATALOG_OWNER TO rco;

exit;
