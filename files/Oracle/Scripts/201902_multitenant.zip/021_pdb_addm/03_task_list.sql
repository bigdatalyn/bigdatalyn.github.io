connect sys/oracle@localhost/salespdb as sysdba
select task_name, to_char(created, 'YYYY-MM-DD HH24:MI:SS') created from dba_advisor_tasks order by created;
exit;
