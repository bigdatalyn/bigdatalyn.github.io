connect sys/oracle@localhost/salespdb as sysdba
set serveroutput on
SET LONG 1000000 PAGESIZE 0;
SELECT DBMS_ADDM.GET_REPORT('ADDM:1094922411_1_6') FROM DUAL;
exit;
