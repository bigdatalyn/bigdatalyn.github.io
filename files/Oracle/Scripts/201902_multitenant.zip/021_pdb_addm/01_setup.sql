connect sys/oracle@localhost/salespdb as sysdba

ALTER SYSTEM SET AWR_PDB_AUTOFLUSH_ENABLED=TRUE;
EXEC dbms_workload_repository.modify_snapshot_settings(interval=>10);

exit;

