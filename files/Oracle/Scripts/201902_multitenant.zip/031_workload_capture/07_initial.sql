connect sys/oracle@localhost/pdb1 as sysdba

BEGIN
  DBMS_WORKLOAD_REPLAY.INITIALIZE_REPLAY (replay_name => 'db19c_cap',
                           replay_dir => 'CAPDIR',
                           plsql_mode => 'top_level');
END;
/
exit;
