connect sys/oracle@localhost/pdb1 as sysdba

BEGIN
  DBMS_WORKLOAD_REPLAY.PREPARE_REPLAY (synchronization => 'SCN',
                           capture_sts => TRUE,
                           sts_cap_interval => 300);
END;
/
exit;
