connect sys/oracle@localhost/pdb1 as sysdba

BEGIN
  DBMS_WORKLOAD_REPLAY.REMAP_CONNECTION (connection_id => 1,
                           replay_connection => 'localhost/pdb1');
END;
/
exit;
