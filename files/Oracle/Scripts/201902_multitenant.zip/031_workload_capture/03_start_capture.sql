connect sys/oracle@localhost/pdb1 as sysdba

BEGIN
  DBMS_WORKLOAD_CAPTURE.START_CAPTURE (name => 'db19c_cap', 
                           dir => 'CAPDIR',
                           duration => 600,
                           capture_sts => TRUE,
                           sts_cap_interval => 300,
                           plsql_mode => 'extended');
END;
/
exit;
