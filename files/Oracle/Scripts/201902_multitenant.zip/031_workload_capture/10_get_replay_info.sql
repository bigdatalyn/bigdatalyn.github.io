connect sys/oracle@localhost/pdb1 as sysdba
set serveroutput on

DECLARE
  cap_id         NUMBER;
  l_cap_id       number;
BEGIN
  cap_id := DBMS_WORKLOAD_REPLAY.GET_REPLAY_INFO(replay_dir => 'CAPDIR');
  SELECT capture_id into l_cap_id
    FROM dba_workload_replays
   WHERE capture_id = cap_id;
  dbms_output.put_line('capture_id:' || cap_id || ',' || l_cap_id);
END;
/
exit;
