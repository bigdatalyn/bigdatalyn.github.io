connect sys/oracle@localhost/pdb1 as sysdba

BEGIN
  DBMS_WORKLOAD_CAPTURE.FINISH_CAPTURE (); 
END;
/
exit;
