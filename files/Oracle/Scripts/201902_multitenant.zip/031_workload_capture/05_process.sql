connect sys/oracle@localhost/pdb1 as sysdba
BEGIN
  DBMS_WORKLOAD_REPLAY.PROCESS_CAPTURE (capture_dir => 'CAPDIR');
END;
/
exit;
