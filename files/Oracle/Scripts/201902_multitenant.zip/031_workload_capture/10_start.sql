connect sys/oracle@localhost/pdb1 as sysdba

BEGIN
  DBMS_WORKLOAD_REPLAY.START_REPLAY ();
END;
/
exit;
