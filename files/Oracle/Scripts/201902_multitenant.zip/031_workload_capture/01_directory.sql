connect sys/oracle@localhost/pdb1 as sysdba

create directory capdir as '/u01/app/oracle/product/19.2.0/dbhome_1/rdbms/capture';

exit;

