connect sys/oracle@localhost/pdb1 as sysdba
set serveroutput on

DECLARE
  rep_id         NUMBER;
  l_status       dba_workload_replays.divergence_load_status%type;
BEGIN
  rep_id := DBMS_WORKLOAD_REPLAY.LOAD_DIVERGENCE (replay_id => 1);
  SELECT divergence_load_status into l_status
    FROM dba_workload_replays
   WHERE capture_id = rep_id;
   dbms_output.put_line('Status: ' || l_status);
END;
/
exit;
