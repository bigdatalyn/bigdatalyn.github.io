#!/bin/bash


while [ 1 -eq 1 ]
do


last_date=`sqlite3 exadataviewer.db "select max(oper_date) from host_stat"`

echo ""> os_stat.data
echo "=========================================== ExadataViewer Realtime OS Stat Monitor: " $last_date " ===========================================">> os_stat.data

echo "" >> os_stat.data

# db section
sqlite3 -header -column exadataviewer.db "
select
  hostname,
--  round(cpu_user,1) cpu_user,
--  round(cpu_system,1) cpu_system,
--  round(cpu_iow,1) cpu_iow,
--  round(cpu_idle,1) cpu_idle,
  round(100-cpu_idle,1) 'cpu_used%',
  CAST(runq AS INTEGER) runq, CAST(mem_kbswpused AS INTEGER) mem_kb_swp,
  CAST(round(ib_rx_kbps/1024) AS INTEGER) ib_rx_mbps,
  CAST(round(ib_tx_kbps/1024) AS INTEGER) ib_tx_mbps,
  CAST(round(eth_rx_kbps/1024) AS INTEGER) eth_rx_mbps,
  CAST(round(eth_tx_kbps/1024) AS INTEGER) eth_tx_mbps
from host_stat
where oper_date=datetime('$last_date') and type='db'
order by type,hostname;
" >> os_stat.data

echo "            ----------">> os_stat.data

sqlite3 -column exadataviewer.db "
select
  '   avg: ',round(100-avg(cpu_idle),1) cpu_used
from host_stat
where oper_date=datetime('$last_date') and type='db';

select '';
select '';
" >> os_stat.data

# cell section
sqlite3 -header -column exadataviewer.db "
select
  hostname,
--  round(cpu_user,1) cpu_user,
--  round(cpu_system,1) cpu_system,
--  round(cpu_iow,1) cpu_iow,
--  round(cpu_idle,1) cpu_idle,
  round(100-cpu_idle,1) 'cpu_used%',
  CAST(runq AS INTEGER) runq, CAST(mem_kbswpused AS INTEGER) mem_kb_swp, 
  CAST(round(ib_rx_kbps/1024) AS INTEGER)       ib_rx_mbps,
  CAST(round(ib_tx_kbps/1024) AS INTEGER)       ib_tx_mbps,
  CAST(round(disk_read_kbps/1024) AS INTEGER)   disk_r_mbps,
  CAST(round(disk_write_kbps/1024) AS INTEGER)  disk_w_mbps,
  CAST(round(flash_read_kbps/1024) AS INTEGER)  flash_r_mbps,
  CAST(round(flash_write_kbps/1024) AS INTEGER) flash_w_mbps,
  CAST(round(disk_iops) AS INTEGER)             disk_iops,
  CAST(round(flash_iops) AS INTEGER)            flash_iops  
from host_stat
where oper_date=datetime('$last_date') and type='cell'
order by type,hostname;
" >> os_stat.data

echo "            ----------                                                  -----------  -----------  ------------  ------------  ----------  ----------">> os_stat.data

sqlite3 -column exadataviewer.db "
select 
  '   avg: ',round(100-avg(cpu_idle),1) cpu_used,'','','',
  '   sum: ', 
  sum(CAST(round(disk_read_kbps/1024) AS INTEGER))   disk_r_mbps,
  sum(CAST(round(disk_write_kbps/1024) AS INTEGER))  disk_w_mbps,
  sum(CAST(round(flash_read_kbps/1024) AS INTEGER))  flash_r_mbps,
  sum(CAST(round(flash_write_kbps/1024) AS INTEGER)) flash_w_mbps,
  sum(CAST(round(disk_iops) AS INTEGER))             disk_iops,
  sum(CAST(round(flash_iops) AS INTEGER))            flash_iops
from host_stat
where oper_date=datetime('$last_date') and type='cell';
" >> os_stat.data 


echo "" >> os_stat.data
echo "Sleep 5s..." >> os_stat.data
clear
cat os_stat.data
sleep 5

done


