#!/bin/bash

export JAVA_HOME=$ORACLE_HOME/jdk
export PATH=$PATH:$JAVA_HOME/bin

# startup tomcat
rm -rf tomcat/work/Catalina/localhost/ExadataViewer.last
mv -f tomcat/work/Catalina/localhost/ExadataViewer tomcat/work/Catalina/localhost/ExadataViewer.last
mv -f tomcat/logs/catalina.out tomcat/logs/catalina.out.last

chmod u+x tomcat/bin/*.sh
tomcat/bin/startup.sh

echo "----------------------------------------"
echo "ExadataViewer started!"
echo "Acess Method:"
echo "  Admin Network     : http://`/sbin/ifconfig eth0       | grep "inet addr" | awk -F: '{print $2}' | awk '{print $1}'`:8080/ExadataViewer"
echo "  Client Network    : http://`/sbin/ifconfig bondeth0   | grep "inet addr" | awk -F: '{print $2}' | awk '{print $1}'`:8080/ExadataViewer"
echo "  Client VIP Network: http://`/sbin/ifconfig bondeth0:1 | grep "inet addr" | awk -F: '{print $2}' | awk '{print $1}'`:8080/ExadataViewer"
echo "Support: qingli.song"
echo "----------------------------------------"
echo ""
