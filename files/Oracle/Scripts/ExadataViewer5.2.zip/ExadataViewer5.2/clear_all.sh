#!/bin/bash


echo "clear all data."
sqlite3 exadataviewer.db "delete from host_stat"
sqlite3 exadataviewer.db "delete from host_cell_io"
sqlite3 exadataviewer.db "delete from host_cpu_used"

sqlite3 exadataviewer.db "delete from db_dataflow"
sqlite3 exadataviewer.db "delete from db_sql_monitor"


echo "shrink space."
sqlite3 exadataviewer.db "vacuum;"

