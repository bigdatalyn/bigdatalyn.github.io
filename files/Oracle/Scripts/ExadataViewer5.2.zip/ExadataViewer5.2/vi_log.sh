#!/bin/bash

vi tomcat/logs/catalina.out
