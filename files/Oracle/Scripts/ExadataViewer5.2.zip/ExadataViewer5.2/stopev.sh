#!/bin/bash

export JAVA_HOME=$ORACLE_HOME/jdk
export PATH=$PATH:$JAVA_HOME/bin

./tomcat/bin/shutdown.sh

echo "----------------------------------------"
echo "ExadataViewer stoped!"
echo "Support: qingli.song"
echo "----------------------------------------"
