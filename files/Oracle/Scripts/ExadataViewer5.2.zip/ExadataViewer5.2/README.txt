
How to use ExadataViewer:

--------------------------------------------------------------------------
Author: qingli.song@gmail.com
--------------------------------------------------------------------------

1.About 
ExadataViewer is an Exadata performance monitor software. 

Through a set of realtime graphical views, you can observe:
1) Exadata internal architecture
2) Physical I/O dataflow in the cells
3) Exadata new features' offloading efficiency (smart scan, storage index, ehcc, flash cache, writeback)
4) Db & cell hosts' CPU usage & I/O throughtput
5) Top SQLs
6) The relationship between top SQLs, CPU and I/O


2.Install (step by step) 
ExadataViewer can be installed in Exadata db node or in your personal pc (The pc need connect to the db instance via sqlnet).


2.1 Upload and unzip
Upload ExadataViewer*.zip to /home/oracle of Exadata db node and unzip it. (If you want to install ExadataViewer in your personal pc, please put the .zip file in a suitable directory and unzip it)
unzip exadataviewer*.zip 


2.2 Prepare database user 
ExadataViewer needs to connect to database and queries some v$ views, so you must provide a user which has 'connect' and 'select any dictionary' privilege, or you can use flowing sqls to prepare the database user.
create user exadataviewer identified by oracle; 
grant connect,select any dictionary to exadataviewer; 


2.3 Edit config.ini
Edit config.ini, and input databases & hosts' connection information

3. start & stop 
3.1 startup command 
./startev.sh (If you install ExadataViewer in your personal pc, please set the env parameter JAVA_HOME to jdk1.5 directory, and run startev.bat��

3.2 stop command 
./stopev.sh 

3.3 view the log 
./tail_log.sh
or
./vi_log.sh


4.begin to use ExadataViewer 
Open webpage http://<ip>:8080/Exadataviewer



