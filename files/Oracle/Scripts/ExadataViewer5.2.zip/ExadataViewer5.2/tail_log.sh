#!/bin/bash

tail -f tomcat/logs/catalina.out
