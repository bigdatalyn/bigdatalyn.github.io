#!/bin/bash

remain_time_range=24

echo "clear history data (> ${remain_time_range} hours)."
sqlite3 exadataviewer.db "delete from host_stat where datetime(oper_date,'localtime')<datetime('now','-${remain_time_range} hours','localtime')"
sqlite3 exadataviewer.db "delete from host_cell_io where datetime(oper_date,'localtime')<datetime('now','-${remain_time_range} hours','localtime')"
sqlite3 exadataviewer.db "delete from host_cpu_used where datetime(oper_date,'localtime')<datetime('now','-${remain_time_range} hours','localtime')"

sqlite3 exadataviewer.db "delete from db_dataflow where datetime(oper_date,'localtime')<datetime('now','-${remain_time_range} hours','localtime')"
sqlite3 exadataviewer.db "delete from db_sql_monitor where datetime(oper_date,'localtime')<datetime('now','-${remain_time_range} hours','localtime')"


echo "shrink space."
sqlite3 exadataviewer.db "vacuum;"

