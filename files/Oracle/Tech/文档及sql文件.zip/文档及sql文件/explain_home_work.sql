SELECT 
    s_name, s_address
FROM
    supplier,
    nation
WHERE
    s_suppkey IN (SELECT DISTINCT
            (ps_suppkey)
        FROM
            partsupp,
            part
        WHERE
            ps_partkey = p_partkey
                AND p_name LIKE 'orchid%'
                AND ps_availqty > (SELECT 
                    0.5 * SUM(l_quantity)
                FROM
                    lineitem
                WHERE
                    l_partkey = ps_partkey
                        AND l_suppkey = ps_suppkey
                        AND l_shipdate >= '1996-01-01'
                        AND l_shipdate < DATE_ADD('1996-01-01', INTERVAL 1 YEAR)))
        AND s_nationkey = n_nationkey
        AND n_name = 'ALGERIA'
ORDER BY s_name;