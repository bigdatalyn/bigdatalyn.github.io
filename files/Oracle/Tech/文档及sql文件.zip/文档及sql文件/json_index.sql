SELECT * FROM UserJson;

ALTER TABLE UserJson ADD COLUMN name VARCHAR(128) 
generated always as (json_extract(data,"$.name")) virtual;

ALTER TABLE UserJson ADD COLUMN name VARCHAR(128) 
 as (json_extract(data,"$.name")) ;

ALTER TABLE UserJson ADD INDEX idx_name (name);


SELECT * FROM UserJson;


SELECT * FROM UserJson WHERE name='"David"';


SELECT JSON_EXTRACT(data,"$.address") FROM UserJson;

INSERT INTO UserJson VALUES (NULL,'{"name":"Jim"}','Jim');

INSERT INTO UserJson(uid,data) VALUES (NULL,'{"name":"Jim"}');

ALTER TABLE UserJson ADD FULLTEXT INDEX idx_fulltex_name (name);

ALTER TABLE UserJson ADD COLUMN name_store VARCHAR(128) 
generated always as (json_extract(data,"$.name")) stored; 

ALTER TABLE UserJson ADD FULLTEXT INDEX idx_fulltex_name (name_store);

SHOW WARNINGS;

ALTER TABLE UserJson DROP COLUMN name;
ALTER TABLE UserJson DROP COLUMN name_store;
DELETE FROM UserJson WHERE uid>3;