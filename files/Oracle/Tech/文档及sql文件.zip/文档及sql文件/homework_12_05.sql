SELECT e.emp_no,CONCAT(last_name," ",first_name) AS name,
t.title,dp.dept_name,s.salary FROM employees e
LEFT JOIN dept_manager d ON e.emp_no = d.emp_no
LEFT JOIN titles t ON t.emp_no = e.emp_no
LEFT JOIN dept_emp de ON de.emp_no = e.emp_no
LEFT JOIN departments dp ON dp.dept_no = de.dept_no
LEFT JOIN salaries s ON s.emp_no = e.emp_no
WHERE d.emp_no IS NULL;

SELECT e.emp_no,CONCAT(last_name," ",first_name) AS name,t.title,dp.dept_name,s.salary FROM employees e
LEFT JOIN dept_manager d ON e.emp_no = d.emp_no
LEFT JOIN 
(SELECT emp_no,title,MAX(to_date) FROM titles GROUP BY emp_no) t ON t.emp_no = e.emp_no
LEFT JOIN 
(SELECT dept_no,emp_no,MAX(to_date) FROM dept_emp GROUP BY emp_no) de ON de.emp_no = e.emp_no
LEFT JOIN 
(SELECT emp_no,salary,MAX(to_date) FROM salaries GROUP BY emp_no) s ON s.emp_no = e.emp_no
LEFT JOIN departments dp ON dp.dept_no = de.dept_no
WHERE d.emp_no IS NULL;

SELECT o_custkey, 
ADDDATE('1970-01-05',INTERVAL FLOOR(DATEDIFF(o_orderdate,'1970-01-05')/7)*7 DAY) AS start, 
ADDDATE('1970-01-05',INTERVAL FLOOR(DATEDIFF(o_orderdate,'1970-01-05')/7)*7+6 DAY) AS end, 
COUNT(o_orderkey) AS total
FROM dbt3.orders GROUP BY o_custkey,start,end;

SELECT 
(SELECT COUNT(1) FROM employees b WHERE b.emp_no <= a.emp_no ) AS row_number,
emp_no,CONCAT(last_name," ",first_name) name,gender,hire_date
FROM employees a ORDER BY emp_no LIMIT 10;

SET @a:=0;
SELECT @a:=@a+1 AS row_number,emp_no,CONCAT(last_name," ",first_name) name,gender,hire_date
FROM employees,(SELECT @a:=0) AS a LIMIT 10;

