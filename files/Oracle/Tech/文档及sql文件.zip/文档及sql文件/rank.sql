SET @prev_value := NULL;
SET @rank_count := 0;
SELECT id, score, 
CASE
    WHEN @prev_value = score THEN @rank_count
    WHEN @prev_value := score THEN @rank_count := @rank_count + 1
END AS rank_column
FROM rank
ORDER BY score DESC;

SELECT
(SELECT COUNT(DISTINCT score) FROM rank e2 WHERE e2.score <= e.score ORDER BY score) AS rownum,
e.* 
FROM rank e  
ORDER BY score LIMIT 10