CREATE TABLE `stu` (
  `name` varchar(50) ,
  `course` varchar(50),
  `score` int(11),
  PRIMARY KEY (`name`)
) ENGINE=InnoDB ; 

delimiter //
CREATE TRIGGER trg_upd_score 
BEFORE UPDATE ON `stu`
FOR EACH ROW 
BEGIN 
IF NEW.score < 0 THEN 
	SET NEW.score = 0; 
ELSEIF NEW.score > 100 THEN 
	SET NEW.score = 100; 
END IF; 
END;
//
delimiter ;

INSERT INTO stu select 'David','Math',150;

UPDATE stu SET score = 120 where name = 'David';

SELECT * FROM stu;
