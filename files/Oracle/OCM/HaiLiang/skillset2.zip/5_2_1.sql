insert into sales_history_2014 values(101,to_date('2005-02-03','yyyy-mm-dd'),'x1',1001,1,20000,880     01,88002); 
insert into sales_history_2014 values(102,to_date('2005-05-15','yyyy-mm-dd'),'x1',1002,1,30000,880     02,88002); 
insert into sales_history_2014 values(103,to_date('2005-09-22','yyyy-mm-dd'),'x1',1003,1,40000,880     03,88002); 
insert into sales_history_2014 values(104,to_date('2005-12-30','yyyy-mm-dd'),'x1',1004,1,10000,880     04,88002); 
insert into sales_history_2014 values(101,801,200001,200,100);                                        
insert into sales_history_2014 values(102,802,200002,300,100);                                        
insert into sales_history_2014 values(103,803,200003,400,100);                                        
insert into sales_history_2014 values(104,804,200004,100,100);                                        
commit;