SELECT /*LOAD_CC*/ * FROM   sh.sales WHERE  quantity_sold > 40
ORDER BY prod_id;