# passwordless Cookbook

This cookbook is used to set that Node's user can login on public server like ftpserver with the No password.

the commands like these as below.
 
    /usr/bin/ssh-keygen -e -f /home/james/.ssh/id_rsa

    /usr/bin/ssh-copy-id -i /home/james/.ssh/id_rsa -o StrictHostKeyChecking=no ftpuser@192.168.1.102

## Requirements

TODO: List your cookbook requirements. Be sure to include any requirements this cookbook has on platforms, libraries, other cookbooks, packages, operating systems, etc.

### Package

- expect

### Platforms

- CentOS

### Chef

- Chef 12.0 or later

### Cookbooks


###

$ tree

    .
    |-- attributes
    |   `-- default.rb
    |-- CHANGELOG.md
    |-- definitions
    |-- files
    |   `-- default
    |       |-- auto_pwdless.sh
    |       `-- pwdless.exp
    |-- libraries
    |-- metadata.rb
    |-- providers
    |-- README.md
    |-- recipes
    |   `-- default.rb
    |-- release.sh
    |-- resources
    `-- templates
        `-- default


10 directories, 8 files
$


## Attributes

TODO: List your cookbook attributes here.

### passwordless::default

<table>
  <tr>
    <th>Key</th>
    <th>Type</th>
    <th>Description</th>
    <th>Default</th>
  </tr>
  <tr>
    <td><tt>['passwordless']['target_host']</tt></td>
    <td>Strings</td>
    <td>The public servers's hostname or ip address</td>
    <td><tt>chef</tt></td>
  </tr>
  <tr>
    <td><tt>['passwordless']['target_login_user']</tt></td>
    <td>Strings</td>
    <td>the public server's user name</td>
    <td><tt>ftpuser</tt></td>
  </tr>
  <tr>
    <td><tt>['passwordless']['target_login_pwd']</tt></td>
    <td>Strings</td>
    <td>the user's password</td>
    <td><tt>zaq12wsx</tt></td>
  </tr>
  <tr>
    <td><tt>['passwordless']['user']</tt></td>
    <td>Strings</td>
    <td>the node server's user name</td>
    <td><tt>root</tt></td>
  </tr>

</table>

## Usage

### passwordless::default

TODO: Write usage instructions for each cookbook.

e.g.
Just include `passwordless` in your node's `run_list`:

```json
{
  "name":"my_node",
  "run_list": [
    "recipe[passwordless]"
  ]
}
```

## Contributing

TODO: (optional) If this is a public cookbook, detail the process for contributing. If this is a private cookbook, remove this section.

e.g.
1. Fork the repository on Github
2. Create a named feature branch (like `add_component_x`)
3. Write your change
4. Write tests for your change (if applicable)
5. Run the tests, ensuring they all pass
6. Submit a Pull Request using Github

## License and Authors

Authors: Hong Lin
