#default['passwordless']['target_host'] = '192.168.122.116'

default['passwordless']['target_host'] = 'chef'
default['passwordless']['target_login_user'] = 'ftpuser'
default['passwordless']['target_login_pwd'] = 'zaq12wsx'
default['passwordless']['user'] = 'james'

#default['passwordless']['user_password'] = 'zaq12wsx'
#default['passwordless']['user_label'] = 'my_scp_passwordless'
#default['passwordless']['renew_keyfile'] = 'true'
