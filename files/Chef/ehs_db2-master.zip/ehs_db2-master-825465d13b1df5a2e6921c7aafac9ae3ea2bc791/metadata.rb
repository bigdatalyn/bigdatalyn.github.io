name             'ehs_db2'
maintainer       'IBM'
maintainer_email 'honglh@cn.ibm.com'
license          'All rights reserved'
description      'Installs/Configures db2 production'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.1'
depends 	 'selinux'
