# ftp's attributes

default['ehs_db2']['ftphost']					= '192.168.122.116'
default['ehs_db2']['ftpuser']					= 'ftpuser'
default['ehs_db2']['ftppath']					= '/sftp'


# default attributes
# 
default['ehs_db2']['package_dir']                 		= ::File.join(Chef::Config[:file_cache_path], 'ehs_db2')
default['ehs_db2']['version']                     		= '10.5'
default['ehs_db2']['db2install_file']                		= 'v' + node['ehs_db2']['version']  + '_linuxx64_expc.tar.gz'
default['ehs_db2']['db2install_file_sha256sum']             	= 'cf4149fcba61aa6d952671e83fa8f669aebde41fc1e80749849d5b934be98064'
default['ehs_db2']['db2install_nlpack_file']                	= 'v' + node['ehs_db2']['version']  + '_linuxx64_nlpack.tar.gz'
default['ehs_db2']['db2install_nlpack_file_sha256sum']         	= 'c51040d14c4acb564c28525f9f9b36dc6512e40991d3ab59d60f2f9e5906697d'
default['ehs_db2']['db2installer_log']               		= '/tmp/V10.5_db2setup.log'
default['ehs_db2']['db2install_home']                		= '/opt/IBM/db2/v' + node['ehs_db2']['version']
default['ehs_db2']['language']                    		= 'EN'
default['ehs_db2']['install_type']                		= 'CUSTOM'
##############################
#############DB2############## 
##############################


#############BASE CFG######################

default[:mkdb2][:instance_id] = "db2inst2"
default[:mkdb2][:fence_id] = "db2fenc2"
default[:mkdb2][:acess_id] = "p300002"
default[:mkdb2][:m_id] = "m300002"
default[:mkdb2][:db_id] = "UCDDB1"

default[:mkdb2][:SYSADM_GROUP] = "db2sysa"
default[:mkdb2][:fecnce_group] = "db2fadm"
default[:mkdb2][:instance_group] = "#{node[:mkdb2][:instance_id]}"
default[:mkdb2][:acess_group] = "s300002"
default[:mkdb2][:MAINT_GROUP] = "db2maint"


################AVD CFG####################

default[:mkdbdir][:instance_dir] = "/dbhome/#{node[:mkdb2][:instance_id]}"
default[:mkdbdir][:fence_dir] = "/home/#{node[:mkdb2][:fence_id]}"
default[:mkdb2][:acess_dir] = "/home/#{node[:mkdb2][:acess_id]}"
default[:mkdb2][:m_dir] = "/home/#{node[:mkdb2][:m_id]}"

default[:mkdbdir][:dir_mod_1] = "755"
default[:mkdbdir][:dir_mod_2] = "770"
default[:mkdbdir][:dir_mod_3] = "750"
default[:mkdbdir][:dir_mod_4] = "700"
default[:mkdbdir][:db_dir] = "/db"
default[:mkdbdir][:dbhome] = "/dbhome"
default[:mkdbdir][:dbbackup] = "/dbbackup"
default[:mkdbdir][:dblogs] = "/dblogs"

default[:mkdbdir][:db2audit_main] = "/dblogs/db2audit"
default[:mkdbdir][:dblogs_logs] = ["/dblogs/active/","/dblogs/mirror/","/dblogs/archive/","/dblogs/dump/"]
default[:mkdbdir][:dbbackup_mod] = ["/dbbackup/daily","/dbbackup/weekly/","/dbbackup/daily/on","/dbbackup/daily/off","/dbbackup/weekly/on","/dbbackup/weekly/off"]


default[:mkdbdir][:db2audit_instance] = ["/dblogs/db2audit/#{node[:mkdb2][:instance_id]}","/dblogs/db2audit/#{node[:mkdb2][:instance_id]}/archive"]
default[:mkdbdir][:db_dir_instance] = "/db/#{node[:mkdb2][:instance_id]}"
default[:mkdbdir][:dblogs_diag] = "/dblogs/dump/#{node[:mkdb2][:instance_id]}"
default[:mkdbdir][:dblogs_logs_archive]  = "/dblogs/archive/db2inst1"
default[:mkdbdir][:dblogs_logs_db] = ["/dblogs/active/#{node[:mkdb2][:db_id]}","/dblogs/active/#{node[:mkdb2][:db_id]}/NODE0000","/dblogs/mirror/#{node[:mkdb2][:db_id]}","/dblogs/mirror/#{node[:mkdb2][:db_id]}/NODE0000"]
default[:mkdbdir][:dbbackup_mod_db] = ["/dbbackup/daily/on/#{node[:mkdb2][:db_id]}","/dbbackup/daily/off/#{node[:mkdb2][:db_id]}","/dbbackup/weekly/on/#{node[:mkdb2][:db_id]}","/dbbackup/weekly/off/#{node[:mkdb2][:db_id]}"]




##############CMD CFG########################

default[:mkdb][:dbsetting] = "su - #{node[:mkdb2][:instance_id]} -c 'db2 connect to #{node[:mkdb2][:db_id]};db2 update db cfg for #{node[:mkdb2][:db_id]} using LOGBUFSZ 256;
db2 update db cfg for #{node[:mkdb2][:db_id]} using LOGBUFSZ 256;
db2 update db cfg for #{node[:mkdb2][:db_id]} using LOCKTIMEOUT 30;
db2 update db cfg for #{node[:mkdb2][:db_id]} using LOGARCHMETH1 DISK:/dblogs/archive;
db2 update db cfg for #{node[:mkdb2][:db_id]} using NEWLOGPATH /dblogs/active/#{node[:mkdb2][:db_id]};
db2 update db cfg for #{node[:mkdb2][:db_id]} using MIRRORLOGPATH /dblogs/mirror/#{node[:mkdb2][:db_id]};
db2 update db cfg for #{node[:mkdb2][:db_id]} using LOGFILSIZ 10000;
db2 update db cfg for #{node[:mkdb2][:db_id]} using AUTO_MAINT OFF;
db2 update db cfg for #{node[:mkdb2][:db_id]} using AUTO_TBL_MAINT OFF;
db2 update db cfg for #{node[:mkdb2][:db_id]} using AUTO_RUNSTATS OFF;
db2 update db cfg for #{node[:mkdb2][:db_id]} using AUTO_STMT_STATS OFF;
db2 update db cfg for #{node[:mkdb2][:db_id]} using SELF_TUNING_MEM ON;
db2 update db cfg for #{node[:mkdb2][:db_id]} using DFT_PREFETCH_SZ AUTOMATIC;
db2 update db cfg for #{node[:mkdb2][:db_id]} using LOCKLIST AUTOMATIC;
db2 update db cfg for #{node[:mkdb2][:db_id]} using MAXLOCKS AUTOMATIC;
db2 update db cfg for #{node[:mkdb2][:db_id]} using MAXAPPLS AUTOMATIC;
db2 update db cfg for #{node[:mkdb2][:db_id]} using PCKCACHESZ AUTOMATIC;
db2 update db cfg for #{node[:mkdb2][:db_id]} using SORTHEAP AUTOMATIC;
db2 update db cfg for #{node[:mkdb2][:db_id]} using SHEAPTHRES_SHR AUTOMATIC;
db2 grant dbadm on database to user #{node[:mkdb2][:acess_id]};db2 grant dbadm on database to user #{node[:mkdb2][:m_id]};db2 create schema #{node[:mkdb2][:instance_id]};
' > /tmp/setdb.log"

default[:mkdb][:db_bind] = "su - #{node[:mkdb2][:instance_id]} -c 'db2 connect to #{node[:mkdb2][:db_id]};cd sqllib/bnd;pwd;db2 bind @db2ubind.lst blocking all grant public;db2 bind @db2cli.lst blocking all grant public;db2 bind db2schema.bnd blocking all grant public sqlerror continue;' > /tmp/setdbbind.log"


default[:mkdb][:INSTsetting] = "su - #{node[:mkdb2][:instance_id]} -c 'db2start;db2set DB2COMM=tcpip;db2set DB2_PARALLEL_IO=*;
db2 update dbm cfg using SYSADM_GROUP db2sysa;
db2 update dbm cfg using SYSCTRL_GROUP db2cntl;
db2 update dbm cfg using SYSMAINT_GROUP db2maint;
db2 update dbm cfg using SYSMON_GROUP db2mon;
db2 update dbm cfg using SVCENAME DB2_db2inst1;
db2 update dbm cfg using INSTANCE_MEMORY 524288G
db2 update dbm cfg using SPM_NAME null;
db2 update dbm cfg using HEALTH_MON OFF;
db2 update dbm cfg using DIAGPATH /dblogs/dump/#{node[:mkdb2][:instance_id]};
db2 update dbm cfg using AUTHENTICATION server_encrypt;
db2 update dbm cfg using UTIL_IMPACT_LIM 10;
db2 update dbm cfg using SHEAPTHRES 0;
db2 update dbm cfg using AUDIT_BUF_SZ 512;
db2set -all;
' > /tmp/setinst.log"

default[:mkdb][:AUDIT_file_1] = "/dbhome/#{node[:mkdb2][:instance_id]}/sqllib/security/auditdata/db2audit.db.#{node[:mkdb2][:db_id]}.log.0"
default[:mkdb][:AUDIT_file_2] = "/dbhome/#{node[:mkdb2][:instance_id]}/sqllib/security/auditdata/db2audit.instance.log.0"
default[:mkdb][:AUDIT_SET_1] = "su - #{node[:mkdb2][:instance_id]} -c 'ls -l /dbhome/#{node[:mkdb2][:instance_id]}/sqllib/security/auditdata;rm #{node[:mkdb][:AUDIT_file_1]};ls -l /dbhome/#{node[:mkdb2][:instance_id]}/sqllib/security/auditdata;' > /tmp/auditset.log"
default[:mkdb][:AUDIT_SET_2] = "su - #{node[:mkdb2][:instance_id]} -c 'ls -l /dbhome/#{node[:mkdb2][:instance_id]}/sqllib/security/auditdata;rm #{node[:mkdb][:AUDIT_file_2]};ls -l /dbhome/#{node[:mkdb2][:instance_id]}/sqllib/security/auditdata;' >> /tmp/auditset.log"

default[:mkdb][:Set_inst_audit] = "su - #{node[:mkdb2][:instance_id]} -c 'db2audit configure scope audit status both,checking status both,objmaint status both,secmaint status both,sysadmin status both;
db2audit configure scope validate status none;
db2audit configure datapath /dblogs/db2audit/#{node[:mkdb2][:instance_id]};
db2audit configure archivepath /dblogs/db2audit/#{node[:mkdb2][:instance_id]}/archive;
db2audit start;
db2audit describe;
' > /tmp/set_inst_audit.log"

default[:mkdb][:Set_db_audit] = "su - #{node[:mkdb2][:instance_id]} -c 'db2 connect to #{node[:mkdb2][:db_id]};
db2 create audit policy hc categories all status both error type audit;
db2 audit database using policy hc;
db2 ALTER AUDIT POLICY HC CATEGORIES EXECUTE WITH DATA STATUS BOTH;
db2 commit;
db2 terminate;
db2audit stop;
db2audit start;
' > /tmp/set_db_audit.log"
