# Copyright (c) 2016-present, xxxxx.
# All rights reserved.
#
# This source code is licensed under the BSD-style license found in the
# LICENSE file in the root directory of this source tree. An additional grant
# of patent rights can be found in the PATENTS file in the same directory.
#

class Chef
  # the node object
  class Node
    def centos?
      return self['platform'] == 'centos'
    end

    def centos7?
      return self.centos? && self['platform_version'].start_with?('7')
    end

    def centos6?
      return self.centos? && self['platform_version'].start_with?('6')
    end

    def centos5?
      return self.centos? && self['platform_version'].start_with?('5')
    end

    def debian?
      return self['platform'] == 'debian'
    end

    def ubuntu?
      return self['platform'] == 'ubuntu'
    end

    def linux?
      return self['os'] == 'linux'
    end

    def macosx?
      return self['platform'] == 'mac_os_x'
    end
  end
end
