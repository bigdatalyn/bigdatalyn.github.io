log "##### uninstall DB2's product in #{node['platform_family']}." do
  level :info
end
  
db2install_home = node['ehs_db2']['db2install_home']

##### /opt/IBM/db2/v10.5/install/db2_deinstall -a

log "##### uninstall DB2's product by #{db2install_home}/install/db2_deinstall." do
  level :info
end

execute 'Uninstall db2 product' do
  action :run
  command "#{db2install_home}/install/db2_deinstall -a"
  only_if { ::File.exist?(node['ehs_db2']['db2install_home']) }
end
