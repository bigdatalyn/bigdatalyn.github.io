##################MASTER#####################################
directory node[:mkdbdir][:db_dir] do

 mode node[:mkdbdir][:dir_mod_1]
 action:create
end

directory node[:mkdbdir][:dbhome] do

 mode node[:mkdbdir][:dir_mod_1]
 action:create
end

directory node[:mkdbdir][:dbbackup] do

 mode node[:mkdbdir][:dir_mod_1]
 action:create
end

directory node[:mkdbdir][:dblogs] do

 mode node[:mkdbdir][:dir_mod_1]
 action:create
end

#############
#Creat Group#
#############

group node[:mkdb2][:SYSADM_GROUP] do

action:create
end

group node[:mkdb2][:fecnce_group] do

action:create
end

group node[:mkdb2][:instance_group] do

 action:create
end

group node[:mkdb2][:acess_group] do

 action:create
end

group node[:mkdb2][:MAINT_GROUP] do

 action:create
end

#######################
#CreatID and add group#
#######################

user node[:mkdb2][:instance_id] do

 group node[:mkdb2][:instance_group]
 home node[:mkdbdir][:instance_dir]
 shell "/bin/bash"
 action:create
end

group node[:mkdb2][:SYSADM_GROUP] do

  append true
  members node[:mkdb2][:instance_id]
  action:modify
end

user node[:mkdb2][:fence_id] do

group node[:mkdb2][:fecnce_group]
 home node[:mkdbdir][:fence_dir]
 shell "/bin/bash"
 action:create
end

group node[:mkdb2][:instance_group] do

  append true
  members node[:mkdb2][:fence_id]
  action:modify
end

user node[:mkdb2][:acess_id] do

group node[:mkdb2][:instance_group]
 home node[:mkdbdir][:acess_dir]
 shell "/bin/bash"
 action:create
end

group node[:mkdb2][:acess_group] do

  append true
  members node[:mkdb2][:acess_id]
  action:modify
end

user node[:mkdb2][:m_id] do

group node[:mkdb2][:instance_group]
 home node[:mkdbdir][:m_dir]
 shell "/bin/bash"
 action:create
end

group node[:mkdb2][:MAINT_GROUP] do

  append true
  members node[:mkdb2][:m_id]
  action:modify
end


#################
#Creat directory#
#################



###################SUB######################################

directory node[:mkdbdir][:db2audit_main] do
 group node[:mkdb2][:SYSADM_GROUP]
 mode node[:mkdbdir][:dir_mod_1]
 action:create
end

 node[:mkdbdir][:dblogs_logs].each do |dblogs_logs|
 directory dblogs_logs do
 group node[:mkdb2][:SYSADM_GROUP]
 mode node[:mkdbdir][:dir_mod_1]
 action:create
end
end

node[:mkdbdir][:dbbackup_mod].each do |dbbackup_mod|
 directory dbbackup_mod do
 group node[:mkdb2][:SYSADM_GROUP]
 mode node[:mkdbdir][:dir_mod_1]
 action:create
end
end



###########################INSTANCE#########################

directory node[:mkdbdir][:db_dir_instance] do

 owner node[:mkdb2][:instance_id]
 group node[:mkdb2][:instance_group]
 mode node[:mkdbdir][:dir_mod_2]
 action:create
end

node[:mkdbdir][:db2audit_instance].each do |db2audit_instance|
 directory db2audit_instance do
 owner node[:mkdb2][:instance_id]
 group node[:mkdb2][:SYSADM_GROUP]
 mode node[:mkdbdir][:dir_mod_4]
 action:create
end
end

node[:mkdbdir][:dblogs_logs_db].each do |dblogs_logs_db|
 directory dblogs_logs_db do
 owner node[:mkdb2][:instance_id]
 group node[:mkdb2][:MAINT_GROUP]
 mode node[:mkdbdir][:dir_mod_3]
 action:create
end
end

node[:mkdbdir][:dbbackup_mod_db].each do |dbbackup_mod_db|
 directory dbbackup_mod_db do
 owner node[:mkdb2][:instance_id]
 group node[:mkdb2][:MAINT_GROUP]
 mode node[:mkdbdir][:dir_mod_3]
 action:create
end
end

 directory node[:mkdbdir][:dblogs_diag] do
 owner node[:mkdb2][:instance_id]
 group node[:mkdb2][:instance_group]
 mode node[:mkdbdir][:dir_mod_1]
 action:create
end

directory node[:mkdbdir][:dblogs_logs_archive] do
 owner node[:mkdb2][:instance_id]
 group node[:mkdb2][:instance_group]
 mode node[:mkdbdir][:dir_mod_3]
 action:create
end


########################
#Creat and SET INSTANCE#
########################

execute 'creatinstance' do
 command "cp -ip /etc/services /etc/services`date +%Y%m%d%H%M`;/opt/IBM/db2/V10.5/instance/db2icrt -p DB2_db2inst2 -u db2fenc2 db2inst2 >> /tmp/log.log"
 action :run
end

execute 'setinst' do
 command node[:mkdb][:INSTsetting]
 action :run
end

execute 'restaristance' do
 command "su - db2inst2 -c 'db2stop force;db2start;'"
 action :run
end

execute 'db2port' do
 command "cp -ip /etc/services /etc/services`date +%Y%m%d%H%M`;echo 'DB2_db2inst2    49001/tcp               # DB2' >> /etc/services;"
 action :run
end


##################
#Creat and SET DB#
##################

execute 'creatdb' do
 command "su - db2inst2 -c 'db2 create db UCDDB1 AUTOMATIC STORAGE NO on /db/db2inst2 using codeset IBM-943 territory JP AUTOCONFIGURE APPLY NONE;'"
 action :run
end

execute 'setdb' do
 command node[:mkdb][:dbsetting]
 action :run
end

execute 'binddb' do
 command node[:mkdb][:db_bind]
 action :run
end

execute 'backupdb' do
 command "su - #{node[:mkdb2][:instance_id]} -c 'db2 backup db #{node[:mkdb2][:db_id]} to /dbbackup/weekly/off/#{node[:mkdb2][:db_id]}'"
 action :run                                                                                                                                   
end


################
####AUDIT SET###
################

execute 'setAUDIT1' do
 command node[:mkdb][:AUDIT_SET_1]
 only_if { File.exist?("#{node[:mkdb][:AUDIT_file_1]}")}
end
execute 'setAUDIT2' do
 command node[:mkdb][:AUDIT_SET_2]
 only_if { File.exist?("#{node[:mkdb][:AUDIT_file_2]}")}
end
execute 'setAUDIT3' do
 command node[:mkdb][:Set_inst_audit]
end
execute 'setAUDIT4' do
 command node[:mkdb][:Set_db_audit]
end

