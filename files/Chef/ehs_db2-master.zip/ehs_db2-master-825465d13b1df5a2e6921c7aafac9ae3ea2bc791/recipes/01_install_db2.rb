########################################################
# Cookbook Name:: ehs_db2
# Recipe:: 01_install_db2.rb 
#
# Copyright 2016, Hong Lin
#
# All rights reserved - Do Not Redistribute
#
########################################################

db2install_file = node['ehs_db2']['db2install_file']
db2install_file_sha256sum = node['ehs_db2']['db2install_file_sha256sum']
db2install_nlpack_file = node['ehs_db2']['db2install_nlpack_file']
db2install_nlpack_file_sha256sum = node['ehs_db2']['db2install_nlpack_file_sha256sum']
db2install_home = node['ehs_db2']['db2install_home']

package_dir = node['ehs_db2']['package_dir']

ftphost = node['ehs_db2']['ftphost']
ftpuser = node['ehs_db2']['ftpuser']
ftppath = node['ehs_db2']['ftppath'] 

# create the installfile's directory [/var/chef/cache/ehs_db2] 
directory package_dir do
	owner 'root'
	group 'root'
	mode '0755'
	action :create
	recursive true
end

# create the DB2's install directory [/opt/IBM/db2]
directory db2install_home do
        owner 'root'
        group 'root'
        mode '0755'
        action :create
	recursive true
end

installfiles = [ "#{db2install_file}","#{db2install_nlpack_file}" ] 
validatefiles = [ "#{db2install_file_sha256sum}","#{db2install_nlpack_file_sha256sum}" ]

cnt  = 0

####################################################################################################################
# scp install files(include nlpack file) from ftpserver 
# compare the sha256sum's results between with target code.
# extract the install files.
####################################################################################################################
log "###### This will take a while to copy file from #{ftphost}, validate the sha256sum result for installfiles and then extract them." do
  level :info
end

installfiles.each { | package_name |

#### 01. scp file from ftp server.

  execute 'Copy File From Remoteserver by SCP' do
    cwd package_dir
    command "scp #{ftpuser}@#{ftphost}:#{ftppath}/#{package_name} #{package_dir}"
    #not_if "File::exists?('#{package_dir}/#{package_name}')"
  end

#### 02. sha256sum check the installfiles

  validateCode = ""
  validateTargetCode = ""
  validateTargetCode = "#{validatefiles[cnt]}"
 
  ruby_block "Validate Installfiles sha256sum" do
    
#Chef::Log.info "This will take a while to check file's sha256sum."

    action :run
    block do
      require 'digest'
      validateCode = Digest::SHA256.file("#{package_dir}/#{package_name}").hexdigest
      if validateCode != validateTargetCode 
        raise "[Error] #{package_name}'s code: #{validateCode}  from #{ftpuser} #{ftphost} #{ftppath} does NOT match known sha256sum #{validateTargetCode}! "
      end
    end
  end

#### 03. tar -xzvf installfiles and language package of db2.

  execute 'untar db2 installfiles' do
    cwd package_dir
    action :run
      command "tar -xvzf #{package_dir}/#{package_name}"
  end

  cnt += 1

}


####################################################################################################################
# set SELinux disabled. 
# Package for x86_64 prepare for DB2's product. 
# Package for i686(32bit) prepare for DB2's product. 
####################################################################################################################
log "##### package install for #{node['platform_family'] + ' / ' + node[:platform]}." do
  level :info
end


case node['platform_family']
when 'rhel'

  ####### platform is rhel/centos,redhat

  ### 01. Validating "SELinux status " --> SELinux is "disabled ". 
  include_recipe 'selinux::disabled'
  
  ### 02. DBT3507E  The db2prereqcheck utility failed to find the following package or file:~
  package ["libstdc++", "libaio", "pam", "cpp", "gcc", "gcc-c++", "kernel-devel", "sg3_utils", "ksh", "patch"] do
    arch 'x86_64'
  end

  ### 03.1. DBT3514W  The db2prereqcheck utility failed to find the following 32-bit library file: "/lib/libpam.so*". 
  ### 03.2. DBT3514W  The db2prereqcheck utility failed to find the following 32-bit library file: "libstdc++.so.6". 
  package ["libstdc++", "libaio", "pam"]  do
    arch 'i686'
  end

end


####################################################################################################################
# Install the DB2's product.
####################################################################################################################

db2install_home = node['ehs_db2']['db2install_home']
package_dir = node['ehs_db2']['package_dir']

log "execute #{package_dir}/expc/db2_install -b #{db2install_home} -c #{package_dir}/nlpack" do
  level :info
end

execute 'db2_install db2 product' do
  cwd package_dir
  action :run
  command "#{package_dir}/expc/db2_install -b #{db2install_home} -c #{package_dir}/nlpack"
end

