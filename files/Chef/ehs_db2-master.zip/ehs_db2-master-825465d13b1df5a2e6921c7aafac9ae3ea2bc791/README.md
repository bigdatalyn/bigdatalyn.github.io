# ehs_db2 Cookbook

IBM DB2 for Linux, UNIX and Windows 's install cookbook. 

This cookbook installs DB2, and creates a instance. 


## Requirements
------------

### Platforms

- CentOS7 64bit 

### Chef

- Chef 12.0 or later

### Cookbooks

- `toaster` - ehs_db2 needs toaster to brown your bagel.

## Attributes

### ehs_db2::default


#### db2::ftp's attributes
| Key | Type | Description | Default |
| --- | ---- | ----------- | ------- |
| ['ehs_db2']['ftphost']  | String | sftp server | '192.168.122.116' |
| ['ehs_db2']['ftpuser']  | String | ftp user | 'ftpuser' |
| ['ehs_db2']['ftppath']  | String | ftp's directory | '/sftp' |


#### db2::default attributes
| Key | Type | Description | Default |
| --- | ---- | ----------- | ------- |
| ['ehs_db2']['package_dir'] | String | the path of installfile '/var/chef/cache/ehs_db2'| ::File.join(Chef::Config[:file_cache_path], 'ehs_db2') |
| ['ehs_db2']['version'] | String | DB2 product's version | '10.5' |
| ['ehs_db2']['db2install_file'] | String | DB2 product) | 'v' + node['ehs_db2']['version']  + '_linuxx64_expc.tar.gz' |
| ['ehs_db2']['db2install_file_sha256sum']      | String | sha256sum's result|'cf4149fcba61aa6d952671e83fa8f669aebde41fc1e80749849d5b934be98064' |
| ['ehs_db2']['db2install_nlpack_file']   | String | DB2 product language file | 'v' + node['ehs_db2']['version']  + '_linuxx64_nlpack.tar.gz') |
| ['ehs_db2']['db2install_nlpack_file_sha256sum']   | String | sha256sum's result | 'c51040d14c4acb564c28525f9f9b36dc6512e40991d3ab59d60f2f9e5906697d' |
| ['ehs_db2']['db2installer_log']   | String | Log path | /tmp/V10.5_db2setup.log |
| ['ehs_db2']['db2install_home']   | String | DB2's product install directory | '/opt/IBM/db2/v' + node['ehs_db2']['version'] |


## Usage

### ehs_db2::default

TODO: Write usage instructions for each cookbook.

e.g.
Just include `ehs_db2` in your node's `run_list`:

```json
{
  "name":"my_node",
  "run_list": [
    "recipe[ehs_db2]"
  ]
}
```

## Contributing

01. Init Version 2016/07/14 honglh@cn.ibm.com

## License and Authors

Authors: 
honglh@cn.ibm.com 

IGA-J Cloud&Automation Study
https://w3-connections.ibm.com/communities/service/html/communitystart?communityUuid=78fb9afc-0435-463e-b295-4d8bce20c298



